from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List


from dataBase.db import get_db
from dataBase.models import Vacancy, User
from models.schemas import VacancyCreate, VacancyResponse, ThisVacancyResponse
from dependencies import get_current_user
from sqlalchemy.orm import joinedload


router = APIRouter(prefix="/api/vacancies", tags=["vacancies"])

@router.post("/create", response_model=VacancyResponse, status_code=status.HTTP_201_CREATED)
async def create_vacancy(vacancy_data: VacancyCreate, current_user: User = Depends(get_current_user),db: Session = Depends(get_db)):
    new_vacancy = Vacancy(
    title=vacancy_data.title,
    formatl=vacancy_data.formatl,
    user_id=current_user.id,
    description=vacancy_data.description,
    price=vacancy_data.price,
    type=vacancy_data.type
    )
    
    db.add(new_vacancy)
    db.commit()
    db.refresh(new_vacancy)
    return new_vacancy


@router.get("/mycards_learn", response_model=List[VacancyResponse])
async def get_my_learn_vacancies(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    vacancies = db.query(Vacancy).filter(
        Vacancy.user_id == current_user.id,
        Vacancy.type == "learn"
    ).all()
    
    return vacancies

@router.get("/mycards_teach", response_model=List[VacancyResponse])
async def get_my_teach_vacancies(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    vacancies = db.query(Vacancy).filter(
        Vacancy.user_id == current_user.id,
        Vacancy.type == "teach"
    ).all()
    
    return vacancies


@router.get("/catalog_cards", response_model= List[VacancyResponse])
async def get_all_vacancies_for_catalog(
    db: Session = Depends(get_db)
):
    vacancies = db.query(Vacancy).options(joinedload(Vacancy.author)).all()
    return vacancies



import os
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from typing import Optional

from dotenv import load_dotenv
load_dotenv() 

SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 1
REFRESH_TOKEN_EXPIRE_DAYS = 1

def create_token(data: dict, expires_delta: timedelta) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + expires_delta
    to_encode.update({
        "exp": expire,
        "iat": datetime.now(timezone.utc)
    })
    
    encode_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encode_jwt


def create_access_token(user_id: int, email: str) ->str:
    data = {
        "sub" : str(user_id),
        "email" : email,
        "type" : "access"
    }
    return create_token(data, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))

def create_refresh_token(user_id: int) -> str:
    data = {
        "sub" : str(user_id),
        "type" : "refresh"
    }
    return create_token(data, timedelta(days= REFRESH_TOKEN_EXPIRE_DAYS))

def verify_token(token:str, token_type: str = "access") -> Optional[dict]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != token_type:
            return None
        if payload.get("sub") is None:
            return None
        return payload
    except JWTError:
        return None
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from dataBase.db import get_db
from dataBase.models import User
from models.schemas import UserRegister, UserResponse, UserLogin
from security.security import hash_password, verify_password, needs_rehash
from security.jwt_handler import create_access_token, create_refresh_token, verify_token
from dependencies import is_user_logged_in

router = APIRouter(prefix="/auth", tags=["Аутентификация"])

@router.post("/register", response_model= UserResponse, status_code=status.HTTP_201_CREATED)
async def register(user_data : UserRegister, db : Session = Depends(get_db)):
    existing_email = db.query(User).filter(User.email == user_data.email).first()
    if existing_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email уже зарегистрирован"
        )

    hashed_pass = hash_password(user_data.password)
    
    new_user  = User(
        username = user_data.username,
        email = user_data.email,
        password_hash = hashed_pass 
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    return new_user


@router.post("/login")
async def login(login_data: UserLogin, db : Session = Depends(get_db)):
    
    user = db.query(User).filter(User.email == login_data.email).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверная почта или пароль1",
            headers={"WWW-Authenticate": "Bearer"}
        )
        
    if not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверная почта или пароль2",
            headers={"WWW-Authenticate": "Bearer"}
        )
        
    if needs_rehash(user.password_hash):
        new_hash = hash_password(login_data.password)
        user.password_hash = new_hash
        db.commit()
        print(f"Rehash выполнен для пользователя {user.username}")
        
    access_token = create_access_token(
        user_id= user.id,
        email = user.email
    )
    refresh_token = create_refresh_token(user_id=user.id)
    return{
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }
    
    
from pydantic import BaseModel

class RefreshTokenRequest(BaseModel):
    refresh_token: str
    
@router.post("/refresh")
def refresh(request: RefreshTokenRequest, db: Session = Depends(get_db)):
    refresh_token = request.refresh_token
    payload = verify_token(refresh_token, token_type="refresh")
    
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Невалидный или истёкший refresh токен"
        )
        
    user_id = int(payload.get("sub"))
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Пользователь не найден"
        )
        
    new_access_token = create_access_token(
        user_id=user.id,
        email=user.email
    )
    
    return {
        "access_token": new_access_token,
        "token_type": "bearer"
    }
    

    
@router.get("/check-auth")
async def check_auth(current_user = Depends(is_user_logged_in)):
    if current_user:
        return {"is_logged_in": True}
    return {"is_logged_in": False}
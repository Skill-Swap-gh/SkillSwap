// Чат для занятий с новой структурой
import { getCurrentUser } from './user-context.js';

class ChatSystem {
    constructor() {
        this.messages = [];
        this.attachments = [];
        this.files = []; // Для списка файлов в сайдбаре
        this.lessonId = this.getLessonIdFromURL();
        this.peerId = null;
        this.lessonInfo = null;
        this.init();
    }

    getLessonIdFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('lessonId');
    }

    async init() {
        await this.loadLessonInfo();
        await this.loadMessages();
        this.setupEventListeners();
        this.renderMessages();
        this.updateFilesList();
        this.startPolling();
    }

    async loadLessonInfo() {
        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch(`http://localhost:8000/api/lessons/${this.lessonId}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.lessonInfo = data;
                this.peerId = data.peer_id || data.other_participant_id;
                this.updateLessonInfo(data);
            } else {
                console.error('Ошибка загрузки информации о занятии:', response.status);
            }
        } catch (error) {
            console.error('Ошибка загрузки информации о занятии:', error);
        }
    }

    updateLessonInfo(lesson) {
        if (!lesson) return;
        
        document.getElementById('chatTitle').textContent = `Чат: ${lesson.title || 'Занятие'}`;
        document.getElementById('chatSubtitle').textContent = lesson.peer_name ? `С ${lesson.peer_name}` : 'Обсуждение деталей';
        
        document.getElementById('lessonTitle').textContent = lesson.title || 'Название не указано';
        document.getElementById('lessonStatus').textContent = this.getStatusText(lesson.status);
        document.getElementById('lessonStatus').className = `lesson-status ${this.getStatusClass(lesson.status)}`;
        document.getElementById('lessonPeer').textContent = lesson.peer_name || 'Не указан';
        document.getElementById('lessonDate').textContent = lesson.scheduled_time ? this.formatDate(lesson.scheduled_time) : 'Не назначена';
        document.getElementById('lessonPrice').textContent = `${lesson.price || 0} XP`;
    }

    getStatusText(status) {
        const statusMap = {
            'planned': 'Запланировано',
            'in_progress': 'В процессе',
            'completed': 'Завершено',
            'cancelled': 'Отменено'
        };
        return statusMap[status] || status;
    }

    getStatusClass(status) {
        const classMap = {
            'planned': 'status-planned',
            'in_progress': 'status-in-progress',
            'completed': 'status-completed',
            'cancelled': 'status-cancelled'
        };
        return classMap[status] || 'status-planned';
    }

    async loadMessages() {
        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch(`http://localhost:8000/api/chat/${this.lessonId}/messages`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.messages = data.messages || [];
                this.extractFilesFromMessages();
            }
        } catch (error) {
            console.error('Ошибка загрузки сообщений:', error);
        }
    }

    extractFilesFromMessages() {
        this.files = [];
        this.messages.forEach(message => {
            if (message.attachments && message.attachments.length > 0) {
                message.attachments.forEach(attachment => {
                    this.files.push({
                        id: attachment.id || `file_${Date.now()}`,
                        name: attachment.name,
                        size: attachment.size,
                        type: attachment.type,
                        url: attachment.url,
                        uploaded_by: message.sender_name,
                        uploaded_at: message.timestamp
                    });
                });
            }
        });
    }

    setupEventListeners() {
        // Отправка сообщения
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('btnSend');
        const attachButton = document.getElementById('btnAttach');
        const fileInput = document.getElementById('fileInput');

        messageInput.addEventListener('input', () => {
            this.autoResizeTextarea(messageInput);
        });

        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        sendButton.addEventListener('click', () => this.sendMessage());
        attachButton.addEventListener('click', () => this.showAttachModal());
        
        fileInput.addEventListener('change', (e) => this.handleFileSelect(e));

        // Кнопки в сайдбаре
        const detailsBtn = document.getElementById('btnDetails');
        const cancelBtn = document.getElementById('btnCancelLesson');
        
        if (detailsBtn) detailsBtn.addEventListener('click', () => this.openLessonDetails());
        if (cancelBtn) cancelBtn.addEventListener('click', () => this.cancelLesson());

        // Модальное окно прикрепления
        const attachModal = document.getElementById('attachModal');
        const attachOptions = document.querySelectorAll('.attach-option');
        const closeModal = attachModal.querySelector('.close');

        attachOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                const type = e.currentTarget.dataset.type;
                this.handleAttachOption(type);
            });
        });

        closeModal.addEventListener('click', () => {
            attachModal.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === attachModal) {
                attachModal.style.display = 'none';
            }
        });
    }

    autoResizeTextarea(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    showAttachModal() {
        const attachModal = document.getElementById('attachModal');
        attachModal.style.display = 'block';
    }

    async sendMessage() {
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        
        if (!message && this.attachments.length === 0) return;

        const newMessage = {
            lesson_id: this.lessonId,
            text: message,
            attachments: [],
            sender_id: this.getCurrentUserId(),
            is_my_message: true,
            timestamp: new Date().toISOString(),
            status: 'sending'
        };

        // Если есть вложения, загружаем их
        if (this.attachments.length > 0) {
            const uploadedAttachments = await this.uploadAttachments();
            newMessage.attachments = uploadedAttachments;
        }

        // Добавляем сообщение в интерфейс
        this.addMessageToUI(newMessage);
        messageInput.value = '';
        messageInput.style.height = 'auto';
        
        // Очищаем вложения
        this.clearAttachments();

        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch('http://localhost:8000/api/chat/send', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    lesson_id: this.lessonId,
                    text: message,
                    attachments: newMessage.attachments
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.updateMessageStatus(newMessage.id, 'delivered');
                
                // Добавляем файлы в список
                newMessage.attachments.forEach(attachment => {
                    this.addFileToList({
                        name: attachment.name,
                        size: attachment.size,
                        type: attachment.type,
                        url: attachment.url,
                        uploaded_by: 'Вы',
                        uploaded_at: new Date().toISOString()
                    });
                });
                
                // Обновляем сообщение с сервера
                this.updateMessageFromServer(newMessage.id, data.message);
            } else {
                this.updateMessageStatus(newMessage.id, 'error');
            }
        } catch (error) {
            console.error('Ошибка отправки сообщения:', error);
            this.updateMessageStatus(newMessage.id, 'error');
        }
    }

    async uploadAttachments() {
        const uploadedAttachments = [];
        
        for (const attachment of this.attachments) {
            if (attachment.file) {
                const formData = new FormData();
                formData.append('file', attachment.file);
                formData.append('lesson_id', this.lessonId);
                formData.append('type', attachment.type);

                try {
                    const token = localStorage.getItem('access_token');
                    const response = await fetch('http://localhost:8000/api/chat/upload', {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        },
                        body: formData
                    });

                    if (response.ok) {
                        const data = await response.json();
                        uploadedAttachments.push({
                            id: data.id,
                            name: attachment.name,
                            type: attachment.type,
                            size: attachment.size,
                            url: data.url
                        });
                    }
                } catch (error) {
                    console.error('Ошибка загрузки файла:', error);
                }
            }
        }
        
        return uploadedAttachments;
    }

    addMessageToUI(message) {
        const messagesList = document.getElementById('messagesList');
        const messageElement = this.createMessageElement(message);
        
        // Проверяем, нужно ли добавить дату
        const lastMessage = this.messages[this.messages.length - 1];
        if (lastMessage) {
            const lastDate = new Date(lastMessage.timestamp);
            const currentDate = new Date(message.timestamp);
            
            if (lastDate.toDateString() !== currentDate.toDateString()) {
                const dateElement = document.createElement('div');
                dateElement.className = 'message-date';
                dateElement.innerHTML = `<span>${this.formatDateKey(currentDate)}</span>`;
                messagesList.appendChild(dateElement);
            }
        } else {
            // Первое сообщение
            const dateElement = document.createElement('div');
            dateElement.className = 'message-date';
            dateElement.innerHTML = `<span>${this.formatDateKey(new Date(message.timestamp))}</span>`;
            messagesList.appendChild(dateElement);
        }
        
        // Добавляем сообщение
        const container = document.createElement('div');
        container.innerHTML = messageElement;
        messagesList.appendChild(container.firstElementChild);
        
        // Прокручиваем вниз
        this.scrollToBottom();
        
        // Добавляем в массив сообщений
        this.messages.push(message);
    }

    createMessageElement(message) {
        const isMyMessage = message.is_my_message || message.sender_id === this.getCurrentUserId();
        const time = this.formatTime(message.timestamp);
        const statusIcon = this.getStatusIcon(message.status);
        const senderName = message.sender_name || (isMyMessage ? 'Вы' : 'Собеседник');

        let attachmentsHTML = '';
        if (message.attachments && message.attachments.length > 0) {
            attachmentsHTML = `
                <div class="message-attachments">
                    ${message.attachments.map(attachment => 
                        this.createAttachmentElement(attachment, isMyMessage)
                    ).join('')}
                </div>
            `;
        }

        const messageClass = isMyMessage ? 'outgoing' : 'incoming';
        const sendingClass = message.status === 'sending' ? ' sending-message' : '';

        return `
            <div class="message ${messageClass}${sendingClass}" 
                 data-message-id="${message.id || `temp_${Date.now()}`}">
                ${!isMyMessage ? `<div class="message-sender">${senderName}</div>` : ''}
                <div class="message-content">
                    ${message.text ? `<div class="message-text">${this.escapeHtml(message.text)}</div>` : ''}
                    ${attachmentsHTML}
                    <div class="message-meta">
                        <span class="message-time">${time}</span>
                        ${isMyMessage ? `<span class="message-status">${statusIcon}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    createAttachmentElement(attachment, isMyMessage) {
        if (attachment.type === 'image') {
            return `
                <div class="message-attachment">
                    <img src="${attachment.url || '/static/images/placeholder.jpg'}" 
                         alt="${attachment.name || 'Изображение'}"
                         class="attachment-image"
                         onclick="chatSystem.viewAttachment('${attachment.url || '#'}')">
                </div>
            `;
        } else {
            const fileIcon = this.getFileIcon(attachment.name);
            return `
                <a href="${attachment.url || '#'}" 
                   target="_blank" 
                   class="attachment-file"
                   onclick="event.stopPropagation();">
                    <span class="file-icon">${fileIcon}</span>
                    <div class="file-info">
                        <div class="file-name">${attachment.name || 'Файл'}</div>
                        <div class="file-size">${this.formatFileSize(attachment.size)}</div>
                    </div>
                </a>
            `;
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    getFileIcon(filename) {
        const extension = filename.split('.').pop().toLowerCase();
        const icons = {
            'pdf': '📕',
            'doc': '📘',
            'docx': '📘',
            'txt': '📄',
            'jpg': '🖼️',
            'jpeg': '🖼️',
            'png': '🖼️',
            'gif': '🖼️',
            'zip': '🗜️',
            'rar': '🗜️'
        };
        return icons[extension] || '📎';
    }

    async handleFileSelect(event) {
        const files = Array.from(event.target.files);
        
        for (const file of files) {
            await this.processFile(file);
        }
        
        event.target.value = '';
        this.renderAttachmentsPreview();
        
        // Закрываем модальное окно если оно открыто
        const attachModal = document.getElementById('attachModal');
        attachModal.style.display = 'none';
    }

    async processFile(file) {
        const attachment = {
            id: `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: file.name,
            type: file.type.startsWith('image/') ? 'image' : 'document',
            size: file.size,
            file: file
        };

        // Создаем preview для изображений
        if (attachment.type === 'image') {
            attachment.preview = await this.readFileAsDataURL(file);
        }

        this.attachments.push(attachment);
    }

    readFileAsDataURL(file) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.readAsDataURL(file);
        });
    }

    renderAttachmentsPreview() {
        const previewContainer = document.getElementById('attachmentsPreview');
        
        if (this.attachments.length === 0) {
            previewContainer.innerHTML = '';
            return;
        }
        
        previewContainer.innerHTML = this.attachments.map(attachment => `
            <div class="attachment-preview-item" data-attachment-id="${attachment.id}">
                ${attachment.type === 'image' ? 
                    `<img src="${attachment.preview}" alt="${attachment.name}" class="preview-image">` :
                    `<div class="preview-file">
                        <span class="file-preview-icon">${this.getFileIcon(attachment.name)}</span>
                        <div class="file-preview-name">${attachment.name}</div>
                    </div>`
                }
                <button class="btn-remove-attachment" onclick="chatSystem.removeAttachment('${attachment.id}')">
                    &times;
                </button>
            </div>
        `).join('');
    }

    removeAttachment(attachmentId) {
        this.attachments = this.attachments.filter(att => att.id !== attachmentId);
        this.renderAttachmentsPreview();
    }

    clearAttachments() {
        this.attachments = [];
        this.renderAttachmentsPreview();
    }

    renderMessages() {
        const messagesList = document.getElementById('messagesList');
        messagesList.innerHTML = '';
        
        if (this.messages.length === 0) return;
        
        // Группируем сообщения по датам
        const groupedMessages = this.groupMessagesByDate(this.messages);
        
        for (const [date, messages] of Object.entries(groupedMessages)) {
            messagesList.innerHTML += `<div class="message-date"><span>${date}</span></div>`;
            messagesList.innerHTML += messages.map(msg => 
                this.createMessageElement(msg)
            ).join('');
        }
        
        this.scrollToBottom();
    }

    groupMessagesByDate(messages) {
        const groups = {};
        
        messages.forEach(message => {
            const date = new Date(message.timestamp);
            const dateKey = this.formatDateKey(date);
            
            if (!groups[dateKey]) {
                groups[dateKey] = [];
            }
            groups[dateKey].push(message);
        });
        
        return groups;
    }

    updateMessageStatus(messageId, status) {
        const messageElement = document.querySelector(`[data-message-id="${messageId}"]`);
        if (messageElement) {
            const statusElement = messageElement.querySelector('.message-status');
            if (statusElement) {
                statusElement.textContent = this.getStatusIcon(status);
                messageElement.classList.remove('sending-message');
            }
        }
    }

    updateMessageFromServer(tempId, serverMessage) {
        const messageElement = document.querySelector(`[data-message-id="${tempId}"]`);
        if (messageElement && serverMessage) {
            messageElement.dataset.messageId = serverMessage.id;
        }
    }

    scrollToBottom() {
        const container = document.getElementById('messagesContainer');
        setTimeout(() => {
            container.scrollTop = container.scrollHeight;
        }, 100);
    }

    startPolling() {
        // Опрос новых сообщений каждые 5 секунд
        this.pollInterval = setInterval(async () => {
            await this.checkNewMessages();
        }, 5000);
    }

    async checkNewMessages() {
        try {
            const token = localStorage.getItem('access_token');
            const lastMessageId = this.messages.length > 0 ? this.messages[this.messages.length - 1].id : null;
            
            const response = await fetch(`http://localhost:8000/api/chat/${this.lessonId}/updates?last_id=${lastMessageId || ''}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.new_messages && data.new_messages.length > 0) {
                    this.messages.push(...data.new_messages);
                    this.extractFilesFromMessages();
                    this.renderMessages();
                }
                
                if (data.typing && data.typing.user_id !== this.getCurrentUserId()) {
                    this.showTypingIndicator(data.typing.user_name);
                } else {
                    this.hideTypingIndicator();
                }
            }
        } catch (error) {
            console.error('Ошибка проверки новых сообщений:', error);
        }
    }

    updateFilesList() {
        const filesList = document.getElementById('filesList');
        if (!filesList) return;
        
        if (this.files.length === 0) {
            filesList.innerHTML = '<p class="no-files">Файлов пока нет</p>';
            return;
        }
        
        filesList.innerHTML = this.files.map(file => `
            <a href="${file.url}" target="_blank" class="file-item" download="${file.name}">
                <span class="file-icon">${this.getFileIcon(file.name)}</span>
                <div class="file-info">
                    <div class="file-name">${file.name}</div>
                    <div class="file-size">${this.formatFileSize(file.size)} • ${file.uploaded_by}</div>
                </div>
            </a>
        `).join('');
    }

    addFileToList(file) {
        this.files.push(file);
        this.updateFilesList();
    }

    handleAttachOption(type) {
        const fileInput = document.getElementById('fileInput');
        
        switch(type) {
            case 'image':
                fileInput.accept = 'image/*';
                break;
            case 'document':
                fileInput.accept = '.pdf,.doc,.docx,.txt,.xls,.xlsx,.zip,.rar';
                break;
            default:
                fileInput.accept = '';
        }
        
        fileInput.click();
    }

    showTypingIndicator(userName) {
        const indicator = document.getElementById('typingIndicator');
        const typingText = document.getElementById('typingText');
        
        if (indicator && typingText) {
            typingText.textContent = `${userName || 'Собеседник'} печатает...`;
            indicator.style.display = 'flex';
            this.scrollToBottom();
        }
    }

    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'none';
        }
    }

    openLessonDetails() {
        if (this.lessonId) {
            window.open(`/lesson.html?id=${this.lessonId}`, '_blank');
        }
    }

    async cancelLesson() {
        if (!confirm('Вы уверены, что хотите отменить занятие?')) return;

        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch(`http://localhost:8000/api/lessons/${this.lessonId}/cancel`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                alert('Занятие отменено');
                window.location.href = '/profile.html';
            } else {
                const error = await response.json();
                alert(error.message || 'Ошибка при отмене занятия');
            }
        } catch (error) {
            console.error('Ошибка отмены:', error);
            alert('Не удалось отменить занятие');
        }
    }

    viewAttachment(url) {
        if (url && url !== '#') {
            window.open(url, '_blank');
        }
    }

    getCurrentUserId() {
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        return user.id || 'unknown';
    }

    getStatusIcon(status) {
        const icons = {
            'sending': '🔄',
            'delivered': '✓',
            'read': '👁️',
            'error': '❌'
        };
        return icons[status] || '';
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('ru-RU', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatDateKey(date) {
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (date.toDateString() === today.toDateString()) {
            return 'Сегодня';
        } else if (date.toDateString() === yesterday.toDateString()) {
            return 'Вчера';
        } else {
            return date.toLocaleDateString('ru-RU', {
                day: 'numeric',
                month: 'long'
            });
        }
    }

    formatDate(dateString) {
        if (!dateString) return 'Не назначена';
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatFileSize(bytes) {
        if (!bytes) return '0 Б';
        const k = 1024;
        const sizes = ['Б', 'КБ', 'МБ', 'ГБ'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
}

// Инициализация чата только если есть lessonId
document.addEventListener('DOMContentLoaded', async function() {
    const urlParams = new URLSearchParams(window.location.search);
    const lessonId = urlParams.get('lessonId');
    
    if (lessonId) {
        window.chatSystem = new ChatSystem();
    } else {
        alert('ID занятия не указан');
        window.location.href = '/';
    }
});

// Экспорт для использования в других модулях
export { ChatSystem };
// Система уведомлений
import { getCurrentUser } from './user-context.js';

class NotificationSystem {
    constructor() {
        this.notifications = [];
        this.unreadCount = 0;
        this.init();
    }

    async init() {
        await this.loadNotifications();
        this.setupEventListeners();
        this.renderBell();
    }

    async loadNotifications() {
        try {
            const token = localStorage.getItem('access_token');
            if (!token) return;

            const response = await fetch('http://localhost:8000/api/notifications', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.notifications = data.notifications || [];
                this.unreadCount = data.unread_count || 0;
                this.renderNotifications();
            }
        } catch (error) {
            console.error('Ошибка загрузки уведомлений:', error);
        }
    }

    setupEventListeners() {
        const bellBtn = document.querySelector('.notification-bell');
        const closeBtn = document.querySelector('.notification-close');
        const modal = document.getElementById('notificationModal');

        if (bellBtn) {
            bellBtn.addEventListener('click', () => this.toggleModal());
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }

        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });
        }

        // Обработка нажатий на кнопки в уведомлениях
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-accept')) {
                this.handleAccept(e.target.closest('.notification-item'));
            } else if (e.target.classList.contains('btn-reject')) {
                this.handleReject(e.target.closest('.notification-item'));
            } else if (e.target.classList.contains('btn-view')) {
                this.handleView(e.target.closest('.notification-item'));
            }
        });
    }

    toggleModal() {
        const modal = document.getElementById('notificationModal');
        if (!modal) return;

        if (modal.style.display === 'block') {
            this.closeModal();
        } else {
            this.openModal();
        }
    }

    openModal() {
        const modal = document.getElementById('notificationModal');
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            this.markAllAsRead();
        }
    }

    closeModal() {
        const modal = document.getElementById('notificationModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    renderBell() {
        const headerActions = document.getElementById('header-actions-id');
        if (!headerActions) return;

        // Находим существующую кнопку колокольчика или создаем новую
        let bellBtn = headerActions.querySelector('.notification-bell');
        if (!bellBtn) {
            bellBtn = document.createElement('button');
            bellBtn.className = 'notification-bell icon-btn';
            bellBtn.innerHTML = '🔔';
            
            // Вставляем перед кнопкой профиля
            const profileBtn = headerActions.querySelector('.profile-btn');
            if (profileBtn) {
                profileBtn.parentNode.insertBefore(bellBtn, profileBtn);
            } else {
                headerActions.appendChild(bellBtn);
            }
        }

        // Добавляем бейдж
        let badge = bellBtn.querySelector('.notification-badge');
        if (!badge) {
            badge = document.createElement('span');
            badge.className = 'notification-badge';
            bellBtn.appendChild(badge);
        }

        if (this.unreadCount > 0) {
            badge.classList.add('has-notifications');
            badge.textContent = this.unreadCount > 9 ? '9+' : this.unreadCount;
        } else {
            badge.classList.remove('has-notifications');
            badge.textContent = '';
        }
    }

    renderNotifications() {
        const container = document.getElementById('notificationsList');
        if (!container) return;

        if (this.notifications.length === 0) {
            container.innerHTML = `
                <div class="no-notifications">
                    <p>У вас нет новых уведомлений</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.notifications.map(notification => `
            <div class="notification-item ${notification.read ? '' : 'unread'}" 
                 data-notification-id="${notification.id}"
                 data-type="${notification.type}"
                 data-skill-id="${notification.skill_id || ''}"
                 data-from-user-id="${notification.from_user_id || ''}">
                
                <div class="notification-content">
                    <span class="notification-type type-${notification.type}">
                        ${this.getTypeLabel(notification.type)}
                    </span>
                    <p class="notification-message">${notification.message}</p>
                    
                    ${notification.skill_title ? 
                        `<div class="skill-info">
                            <strong>Навык:</strong> ${notification.skill_title}
                        </div>` : ''}
                </div>
                
                <div class="notification-meta">
                    <span class="notification-time">
                        ${this.formatTime(notification.created_at)}
                    </span>
                    <span class="notification-status">
                        ${notification.read ? 'Прочитано' : 'Новое'}
                    </span>
                </div>
                
                ${this.renderNotificationActions(notification)}
            </div>
        `).join('');
    }

    renderNotificationActions(notification) {
        if (!notification.buttons || notification.buttons.length === 0) {
            return '';
        }

        const buttons = notification.buttons.map(button => {
            switch(button) {
                case 'accept':
                    return '<button class="notification-btn btn-accept">Принять</button>';
                case 'reject':
                    return '<button class="notification-btn btn-reject">Отклонить</button>';
                case 'view':
                    return '<button class="notification-btn btn-view">Посмотреть</button>';
                default:
                    return '';
            }
        }).join('');

        return `<div class="notification-actions">${buttons}</div>`;
    }

    async handleAccept(notificationElement) {
        const notificationId = notificationElement.dataset.notificationId;
        const skillId = notificationElement.dataset.skillId;
        
        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch('http://localhost:8000/api/purchase/respond', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    notification_id: notificationId,
                    status: 'accepted'
                })
            });

            if (response.ok) {
                // Удаляем уведомление
                notificationElement.remove();
                
                // Обновляем счетчик
                this.unreadCount = Math.max(0, this.unreadCount - 1);
                this.renderBell();
                
                // Добавляем в занятия
                const skillTitle = notificationElement.querySelector('.skill-info strong')?.nextSibling?.textContent.trim();
                if (skillTitle) {
                    this.addToMyLessons(skillId, skillTitle, 'Запланировано', true);
                }
                
                alert('Заявка принята!');
            }
        } catch (error) {
            console.error('Ошибка принятия заявки:', error);
            alert('Ошибка при принятии заявки');
        }
    }

    async handleReject(notificationElement) {
        const notificationId = notificationElement.dataset.notificationId;
        const skillId = notificationElement.dataset.skillId;
        
        try {
            const token = localStorage.getItem('access_token');
            const response = await fetch('http://localhost:8000/api/purchase/respond', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    notification_id: notificationId,
                    status: 'rejected'
                })
            });

            if (response.ok) {
                // Удаляем уведомление
                notificationElement.remove();
                
                // Обновляем счетчик
                this.unreadCount = Math.max(0, this.unreadCount - 1);
                this.renderBell();
                
                // Добавляем в занятия (отмененное)
                const skillTitle = notificationElement.querySelector('.skill-info strong')?.nextSibling?.textContent.trim();
                if (skillTitle) {
                    this.addToMyLessons(skillId, skillTitle, 'Отменено', false);
                }
                
                alert('Заявка отклонена');
            }
        } catch (error) {
            console.error('Ошибка отклонения заявки:', error);
            alert('Ошибка при отклонении заявки');
        }
    }

    handleView(notificationElement) {
        const skillId = notificationElement.dataset.skillId;
        if (skillId) {
            window.location.href = `/catalog.html?skill=${skillId}`;
        }
    }

    async markAllAsRead() {
        try {
            const token = localStorage.getItem('access_token');
            await fetch('http://localhost:8000/api/notifications/mark-read', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            this.unreadCount = 0;
            this.renderBell();
        } catch (error) {
            console.error('Ошибка пометки уведомлений как прочитанных:', error);
        }
    }

    addToMyLessons(skillId, title, status, withChatButton) {
        // Вызываем функцию из lessons.js
        if (typeof window.addToMyLessons === 'function') {
            window.addToMyLessons(skillId, title, 'Описание навыка', status, withChatButton);
        }
    }

    getTypeLabel(type) {
        const labels = {
            'purchase_request': 'Запрос покупки',
            'purchase_accepted': 'Покупка принята',
            'purchase_rejected': 'Покупка отклонена',
            'info': 'Информация',
            'system': 'Системное'
        };
        return labels[type] || type;
    }

    formatTime(timestamp) {
        if (!timestamp) return '';
        
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'только что';
        if (diffMins < 60) return `${diffMins} мин назад`;
        if (diffHours < 24) return `${diffHours} ч назад`;
        if (diffDays < 7) return `${diffDays} дн назад`;
        
        return date.toLocaleDateString('ru-RU');
    }

    // Метод для добавления тестового уведомления (для демо)
    addTestNotification(notificationData) {
        this.notifications.unshift({
            ...notificationData,
            id: Date.now(),
            read: false,
            created_at: new Date().toISOString()
        });
        this.unreadCount++;
        this.renderNotifications();
        this.renderBell();
        
        // Открываем модальное окно, если оно не открыто
        if (this.unreadCount === 1) {
            this.openModal();
        }
    }
}

// Создаем глобальный экземпляр
window.notificationSystem = new NotificationSystem();

// Экспорт для использования в других модулях
export { NotificationSystem };
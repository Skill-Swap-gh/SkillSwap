import { performLogout } from "./scripts.js";

document.addEventListener('DOMContentLoaded', function() {
    const defaultUserData = {
        name: "",
        class: "",
        letter: "",
        school: "",
        email: "",
        phone: "",
        about: "",
        points: "0"
    };

    let userData = { ...defaultUserData };

    const navTabs = document.querySelectorAll('.nav-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const settingsForm = document.getElementById('settingsForm');
    const fileInput = document.getElementById('userAvatar');
    const fileStatus = document.querySelector('.file-status');
    function transformProfileData(profileData) {
        return {
            name: profileData.username || "",
            class: profileData.ClassRoom || "",
            letter: profileData.ClassRoomChar || "",
            school: profileData.School || "",
            email: profileData.email || "",
            phone: profileData.phone || "",
            about: profileData.about_me || "",
            points: profileData.points?.toString() || "0"
        };
    }

    async function initializeUserData() {
        try {
            const token = localStorage.getItem('access_token');
            if (!token) {
                console.error('Токен не найден');
                return;
            }
            const response = await fetch('http://127.0.0.1:8000/ProfileLoad/profile', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const profileData = await response.json();
            userData = transformProfileData(profileData);
            populateSettingsForm();

        } catch (error) {
            console.error('Ошибка при загрузке данных профиля:', error);
            populateSettingsForm();
        }
    }

    function populateSettingsForm() {
        document.getElementById('userName').textContent = userData.name;
        document.getElementById('userNameInput').value = userData.name;
        document.getElementById('userClass').value = userData.class;
        document.getElementById('userLetter').value = userData.letter;
        document.getElementById('userSchool').value = userData.school;
        document.getElementById('userEmail').value = userData.email;
        document.getElementById('userPhone').value = userData.phone;
        document.getElementById('userAbout').value = userData.about;
    }
    navTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            navTabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            document.getElementById(`${targetTab}-tab`).classList.add('active');
        });
    });

    fileInput.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            fileStatus.textContent = this.files[0].name;
        } else {
            fileStatus.textContent = 'Файл не выбран';
        }
    });
    settingsForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = {
            username: document.getElementById('userNameInput').value,
            ClassRoom: document.getElementById('userClass').value,
            ClassRoomChar: document.getElementById('userLetter').value,
            School: document.getElementById('userSchool').value,
            email: document.getElementById('userEmail').value,
            phone: document.getElementById('userPhone').value,
            about_me: document.getElementById('userAbout').value
        };

        const token = localStorage.getItem('access_token');

        try {
            const response = await fetch("http://127.0.0.1:8000/ProfileLoad/profileUpdate", {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                throw new Error('Ошибка при обновлении профиля: ' + response.status);
            }

            const updatedData = await response.json();
            userData = transformProfileData(updatedData);
            populateSettingsForm();
            alert('Настройки сохранены!');

        } catch (error) {
            console.error('Ошибка при отправке данных профиля:', error);
            alert('Не удалось сохранить настройки');
        }
    });
    const filterBtns = document.querySelectorAll('.lessons-filters .filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    initializeUserData();


    const exit = document.querySelector(".btn-exit");

    exit.addEventListener("click", (e)=>{
        performLogout()
    })
});

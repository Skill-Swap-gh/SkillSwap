import { learnCards } from "./scripts.js";
import { teachCards } from "./scripts.js";

// Инициализация функционала навыков профиля
document.addEventListener('DOMContentLoaded', function() {
    fetch('/profile-skills-modals.html')
        .then(response => response.text())
        .then(data => {
            const modalContainer = document.createElement('div');
            modalContainer.innerHTML = data;
            document.body.appendChild(modalContainer);
            
            initSkillsModals();
            initSkillFilters();
        })
        .catch(error => console.error('Ошибка выгрузки окна', error));
});

// Инициализация модальных окон
function initSkillsModals() {
    const teachModal = document.getElementById('teachModal');
    const learnModal = document.getElementById('learnModal');
    const closeButtons = document.querySelectorAll('.skills-close');
    const addTeachBtn = document.getElementById('addTeachBtn');
    const addLearnBtn = document.getElementById('addLearnBtn');

    // Открытие модальных окон
    if (addTeachBtn && teachModal) {
        addTeachBtn.addEventListener('click', () => {
            teachModal.style.display = 'block';
            resetForm('teachForm');
        });
    }

    if (addLearnBtn && learnModal) {
        addLearnBtn.addEventListener('click', () => {
            learnModal.style.display = 'block';
            resetForm('learnForm');
        });
    }

    // Закрытие модальных окон
    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.skills-modal');
            if (modal) modal.style.display = 'none';
        });
    });

    // Закрытие по клику вне окна
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('skills-modal')) {
            event.target.style.display = 'none';
        }
    });

    // Обработка форм
    const teachForm = document.getElementById('teachForm');
    const learnForm = document.getElementById('learnForm');

    if (teachForm) {
        teachForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSkillSubmit(this, 'teach');
        });
    }

    if (learnForm) {
        learnForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSkillSubmit(this, 'learn');
        });
    }

}

// Инициализация фильтров навыков
function initSkillFilters() {
    const filterButtons = document.querySelectorAll('.skill-filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Снимаем активный класс со всех кнопок в этой группе
            const parent = this.closest('.skills-filter-buttons');
            parent.querySelectorAll('.skill-filter-btn').forEach(b => {
                b.classList.remove('active');
            });
            // Добавляем активный класс текущей кнопке
            this.classList.add('active');
        });
    });
}

// Обработка отправки формы
async function handleSkillSubmit(form, type) {
    const formData = new FormData(form);
    const selectedSkill = form.querySelector('.skill-filter-btn.active');
    
    if (!selectedSkill) {
        alert('Пожалуйста, выберите предмет');
        return;
    }


    const skillData = {
        title: selectedSkill.textContent,
        formatl: formData.get('format'),
        description: formData.get('description'),
        price: parseInt(formData.get('price')) || 0,
        type: type // 'teach' или 'learn'
    };

    if (!skillData.description.trim()) {
        alert('Пожалуйста, добавьте описание навыка');
        return;
    }


    console.log('Данные для отправки на сервер:', skillData);
    try {
        const response = await fetch('http://localhost:8000/api/vacancies/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            "Authorization": "Bearer " + localStorage.getItem('access_token')
        },
        body: JSON.stringify(skillData)
        });
        if (response.ok) {
            const result = await response.json();
            console.log('Вакансия создана:', result);
            await learnCards();
            await teachCards()
            
            alert('Вакансия успешно создана!');
        } else {
            console.error('Ошибка:', await response.text());
        }
    } catch (error) {
        console.error('Ошибка запроса /refresh:', error);
        return false;
    }
    
    // Закрываем модальное окно
    const modal = form.closest('.skills-modal');
    if (modal) modal.style.display = 'none';
    
    form.reset();
    resetSkillFilters(form);
}

// Сброс фильтров навыков
function resetSkillFilters(form) {
    const filterButtons = form.querySelectorAll('.skill-filter-btn');
    filterButtons.forEach(btn => {
        btn.classList.remove('active');
    });
}

// Сброс формы
function resetForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.reset();
        resetSkillFilters(form);
    }
}

// Экранирование HTML для безопасности
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}



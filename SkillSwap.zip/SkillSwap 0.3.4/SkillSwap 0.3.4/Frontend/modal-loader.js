import { profile_activate } from './scripts.js';

// Загрузка модального окна уведомлений при инициализации
fetch('/notification-modal.html')
    .then(response => {
        if (response.ok) return response.text();
        throw new Error('Не удалось загрузить окно уведомлений');
    })
    .then(data => {
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = data;
        document.body.appendChild(modalContainer);
    })
    .catch(error => console.error('Ошибка загрузки окна уведомлений:', error));


fetch('/modals.html')
    .then(response => response.text())
    .then(data => {
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = data;
        document.body.appendChild(modalContainer);
        
        initModalHandlers();
        initRegisterForm();
        initloginForm();
        initButtonHandlers();
    })
    .catch(error => console.error('Ошибка выгрузки окна', error));

export function initModalHandlers() {
    const modal = document.getElementById('authModal');
    const modal3 = document.getElementById('authModal3');
    const modal2 = document.getElementById('authModal2');
    const closeBtn = document.querySelector('.close');
    const closeBtn2 = document.querySelector('.close2');
    const closeBtn3 = document.querySelector('.close3');
    const reqLink = document.getElementById('switchToRegister');
    const switchlog = document.getElementById('switchToLogin');
    
    const switchToLoginFromModal3 = document.querySelectorAll('#authModal3 .btn-primary')[0];
    const switchToRegisterFromModal3 = document.querySelectorAll('#authModal3 .btn-primary')[1];

    if (switchToLoginFromModal3 && modal3 && modal) {
        switchToLoginFromModal3.addEventListener('click', function(e) {
            e.preventDefault();
            modal3.style.display = 'none';
            modal.style.display = 'block';
        });
    }

    if (switchToRegisterFromModal3 && modal3 && modal2) {
        switchToRegisterFromModal3.addEventListener('click', function(e) {
            e.preventDefault();
            modal3.style.display = 'none';
            modal2.style.display = 'block';
        });
    }


    if (closeBtn && modal) {
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    }

    if (closeBtn2 && modal2) {
        closeBtn2.addEventListener('click', function() {
            modal2.style.display = 'none';
        });
    }

    if (closeBtn3 && modal3) {
        closeBtn3.addEventListener('click', function() {
            modal3.style.display = 'none';
        });
    }

    window.addEventListener('click', function(event) {
        if (modal && event.target === modal) {
            modal.style.display = 'none';
        }
        if (modal2 && event.target === modal2) {
            modal2.style.display = 'none';
        }
        if (modal3 && event.target === modal3) {
            modal3.style.display = 'none';
        }
    });

    if (reqLink && modal && modal2) {
        reqLink.addEventListener('click', function(e) {
            e.preventDefault();
            modal.style.display = 'none';
            modal2.style.display = 'block';
        });
    }

    if (switchlog && modal && modal2) {
        switchlog.addEventListener('click', function(e) {
            e.preventDefault();
            modal2.style.display = 'none';
            modal.style.display = 'block';
        });
    }
}

function initButtonHandlers() {
    const modal = document.getElementById('authModal');
    const modal3 = document.getElementById('authModal3');
    const modal2 = document.getElementById('authModal2');
    const loginBtnLinAll = document.querySelectorAll('.btn-login-mod');

    if (loginBtnLinAll.length > 0 && modal3) {
        loginBtnLinAll.forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                modal3.style.display = 'block';
            });
        });
    }


    const btnReqProf = document.getElementById('req-in-header-actions');
    const btnlogProf = document.getElementById('log-in-header-actions');

    if (btnReqProf && modal2) {
        btnReqProf.addEventListener('click', function(e) {
            e.preventDefault();
            modal2.style.display = 'block';
        });
    }

    if (btnlogProf && modal) {
        btnlogProf.addEventListener('click', function(e) {
            e.preventDefault();
            modal.style.display = 'block';
        });
    }
}

function initRegisterForm() {
    const form = document.getElementById('registerForm');
    
    if (!form) {
        console.log('Форма registerForm не найдена');
        return;
    }

    form.addEventListener("submit", async function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const data = {
            username: formData.get("username"),
            email: formData.get("email"),
            password: formData.get("password")
        };

        if (data.password.length < 8) {
            alert('Пароль должен быть не менее 8 символов');
            return;
        }

        try {
            const response = await fetch("http://127.0.0.1:8000/auth/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                const responseData = await response.json();
                console.log('Регистрация успешна!', responseData);
                alert(`Регистрация успешна! Ваш аккаунт добавлен, ${responseData.username}!`);
                form.reset();
                document.getElementById('authModal2').style.display = 'none';
            } else {
                const error = await response.json();
                console.error('Ошибка:', error);
                alert(error.detail);
            }
        } catch (error) {
            console.error('Ошибка сети:', error);
            alert('Не удалось подключиться к серверу');
        }
    });
}


function initloginForm() {
    
    const loginForm = document.getElementById("loginForm")
    if (!loginForm) {
        console.log('Форма registerForm не найдена');
        return;
    }
    loginForm.addEventListener("submit", async function(event) {
        event.preventDefault();
        const formData = new FormData(loginForm);
        const data = {
        email: formData.get("email"),
        password: formData.get("password")
    };
    
    if (data.password.length < 8) {
        alert('Пароль должен быть не менее 8 символов');
        return;
    }
    try{
    const response = await fetch("http://127.0.0.1:8000/auth/login", {
        method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
    })
    if (response.ok) {
        const responseData = await response.json();
        console.log('Вход успешен!', responseData); 
        localStorage.setItem('access_token', responseData.access_token);
        localStorage.setItem('refresh_token', responseData.refresh_token);      
        alert(`Добро пожаловать!`); 
        profile_activate()
        loginForm.reset();
        document.getElementById('authModal').style.display = 'none';
    } else {
    const error = await response.json();
    alert(error.detail || 'Неверная почта или пароль');
    }
    }catch (error) {
            console.error('Ошибка сети:', error);
            alert('Не удалось подключиться к серверу');
        }
    })
}



from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from dataBase.db import get_db
from dataBase.models import User
from security.jwt_handler import verify_token

security = HTTPBearer(auto_error=False)

def is_user_logged_in(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)) -> bool:

    if credentials is None:
        return False
    
    token = credentials.credentials
    
    payload = verify_token(token, token_type="access")
    if payload is None:
        return False

    user_id = payload.get("sub")
    if user_id is None:
        return False
    
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        return False
    
    return True

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)) -> User:
    if credentials is None:
        raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED, detail="Требуется авторизация"
        )
    token = credentials.credentials
    payload = verify_token(token, token_type="access")
    if payload is None:
        raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Невалидный токен"
        )
    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Невалидный токен"
        )
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Пользователь не найден"
        )
    return user
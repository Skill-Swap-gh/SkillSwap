from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session, joinedload
from typing import List, Optional

from dataBase.db import get_db
from dataBase.models import User, Vacancy, PurchasedLesson
from dependencies import get_current_user
from pydantic import BaseModel
from notifications import create_notification

router = APIRouter(prefix="/api/purchases", tags=["purchases"])


class PurchasedLessonResponse(BaseModel):
    id: int
    title: str
    subject: str
    teacher: str
    teacherInitials: str
    student: Optional[str] = None
    studentInitials: Optional[str] = None
    description: str
    status: str
    statusText: str
    date: str
    duration: str = "60 минут"
    format: str
    price: int
    rating: float = 4.8
    lessonsCount: int = 0
    vacancy_id: int
    teacher_id: int
    student_id: Optional[int] = None

    class Config:
        from_attributes = True


def _initials(name: str) -> str:
    initials = "".join(word[0].upper() for word in name.split()[:2] if word)
    return initials or name[:2].upper() or "?"


def _status_text(status_value: str) -> str:
    return {
        "pending": "Ожидает подтверждения",
        "planned": "Запланировано",
        "completed": "Завершено",
        "cancelled": "Отменено",
    }.get(status_value, "Запланировано")


@router.post("/buy/{vacancy_id}")
async def buy_vacancy(
    vacancy_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    vacancy = db.query(Vacancy).options(joinedload(Vacancy.author)).filter(Vacancy.id == vacancy_id).first()

    if not vacancy:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Вакансия не найдена")

    if vacancy.user_id == current_user.id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Нельзя купить собственное предложение")

    if current_user.points < vacancy.price:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Недостаточно XP. Нужно {vacancy.price}, у вас {current_user.points}",
        )

    active_purchase = db.query(PurchasedLesson).filter(
        PurchasedLesson.user_id == current_user.id,
        PurchasedLesson.vacancy_id == vacancy_id,
        PurchasedLesson.status != "cancelled",
    ).first()

    if active_purchase:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Вы уже отправляли запрос на это занятие")

    teacher = vacancy.author or db.query(User).filter(User.id == vacancy.user_id).first()
    if not teacher:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Автор навыка не найден")

    current_user.points -= vacancy.price

    purchase = PurchasedLesson(
        user_id=current_user.id,
        vacancy_id=vacancy.id,
        status="pending",
    )
    db.add(purchase)
    db.flush()

    create_notification(
        db,
        recipient_id=teacher.id,
        sender_id=current_user.id,
        purchase_id=purchase.id,
        type="purchase_request",
        title=f"Запрос на покупку навыка",
        message=f"Пользователь {current_user.username} хочет купить у вас ваш {vacancy.title}",
        payload={
            "purchase_id": purchase.id,
            "requester_id": current_user.id,
            "requester_name": current_user.username,
            "skill_title": vacancy.title,
            "skill_description": vacancy.description,
            "price": vacancy.price,
        },
    )

    db.commit()
    db.refresh(purchase)

    return {
        "success": True,
        "message": "Успешно",
        "remaining_points": current_user.points,
        "purchase_id": purchase.id,
        "status": purchase.status,
    }


@router.get("/my-lessons", response_model=List[PurchasedLessonResponse])
async def get_my_lessons(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    purchases = (
        db.query(PurchasedLesson)
        .options(joinedload(PurchasedLesson.vacancy).joinedload(Vacancy.author))
        .filter(PurchasedLesson.user_id == current_user.id, PurchasedLesson.status != "pending")
        .all()
    )

    result = []
    for purchase in purchases:
        vacancy = purchase.vacancy
        author = vacancy.author
        result.append(
            PurchasedLessonResponse(
                id=purchase.id,
                title=vacancy.title,
                subject=vacancy.title,
                teacher=author.username,
                teacherInitials=_initials(author.username),
                description=vacancy.description,
                status=purchase.status,
                statusText=_status_text(purchase.status),
                date=purchase.lesson_date.strftime("%d %B %Y, %H:%M") if purchase.lesson_date else "Дата не назначена",
                format="Онлайн" if vacancy.formatl == "online" else "Офлайн",
                price=vacancy.price,
                rating=4.8,
                lessonsCount=0,
                vacancy_id=vacancy.id,
                teacher_id=author.id,
            )
        )

    return result


@router.put("/lesson/{purchase_id}/status")
async def update_lesson_status(
    purchase_id: int,
    status_value: str = Query(..., alias="status"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if status_value not in ["planned", "completed", "cancelled"]:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Недопустимый статус")

    purchase = db.query(PurchasedLesson).filter(
        PurchasedLesson.id == purchase_id,
        PurchasedLesson.user_id == current_user.id,
    ).first()

    if not purchase:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Занятие не найдено")

    purchase.status = status_value
    db.commit()

    return {"success": True, "message": f"Статус изменен на {status_value}"}


@router.get("/my-taught-lessons", response_model=List[PurchasedLessonResponse])
async def get_my_taught_lessons(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    purchases = (
        db.query(PurchasedLesson)
        .options(joinedload(PurchasedLesson.vacancy), joinedload(PurchasedLesson.user))
        .join(Vacancy, PurchasedLesson.vacancy_id == Vacancy.id)
        .filter(Vacancy.user_id == current_user.id, PurchasedLesson.status != "pending")
        .all()
    )

    result = []
    for purchase in purchases:
        vacancy = purchase.vacancy
        buyer = purchase.user
        result.append(
            PurchasedLessonResponse(
                id=purchase.id,
                title=vacancy.title,
                subject=vacancy.title,
                teacher=current_user.username,
                teacherInitials=_initials(current_user.username),
                student=buyer.username,
                studentInitials=_initials(buyer.username),
                description=vacancy.description,
                status=purchase.status,
                statusText=_status_text(purchase.status),
                date=purchase.lesson_date.strftime("%d %B %Y, %H:%M") if purchase.lesson_date else "Дата не назначена",
                format="Онлайн" if vacancy.formatl == "online" else "Офлайн",
                price=vacancy.price,
                rating=4.8,
                lessonsCount=0,
                vacancy_id=vacancy.id,
                teacher_id=current_user.id,
                student_id=buyer.id,
            )
        )

    return result

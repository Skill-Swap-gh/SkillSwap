
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from dataBase.db import get_db
from dataBase.models import User
from models.schemas import ProfileDataResponse, ProfileDataUpdate
from security.jwt_handler import verify_token


router = APIRouter(prefix="/ProfileLoad", tags=["Загрузка данных"])
security = HTTPBearer()

BASE_DIR = Path(__file__).resolve().parent
UPLOADS_DIR = BASE_DIR / "uploads" / "avatars"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)


def _serialize_user(user: User) -> ProfileDataResponse:
    return ProfileDataResponse(
        username=user.username,
        email=user.email,
        ClassRoom=user.ClassRoom,
        ClassRoomChar=user.ClassRoomChar,
        School=user.School,
        phone=user.phone,
        about_me=user.about_me,
        avatar_url=user.avatar_url,
        points=user.points,
    )


@router.get("/profile", response_model=ProfileDataResponse)
async def get_user_profile(creditials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    token = creditials.credentials
    payload = verify_token(token, token_type="access")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Пользователь не найден"
        )
    return _serialize_user(user)


@router.post("/profileUpdate", response_model=ProfileDataResponse)
async def update_user_profile(
    data: ProfileDataUpdate,
    creditials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    token = creditials.credentials
    payload = verify_token(token, token_type="access")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()

    if user is None:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    for field, value in data.dict(exclude_unset=True).items():
        if value is not None and value != "":
            setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return _serialize_user(user)


@router.post("/avatar", response_model=ProfileDataResponse)
async def upload_user_avatar(
    avatar: UploadFile = File(...),
    creditials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    token = creditials.credentials
    payload = verify_token(token, token_type="access")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()

    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Пользователь не найден")

    if not avatar.content_type or not avatar.content_type.startswith("image/"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Можно загрузить только изображение")

    content = await avatar.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, detail="Файл должен быть не больше 15 МБ")

    ext = Path(avatar.filename or "").suffix.lower()
    if not ext:
        ext = ".png"

    filename = f"user_{user.id}_{user_id}{ext}"
    file_path = UPLOADS_DIR / filename
    with open(file_path, "wb") as buffer:
        buffer.write(content)

    user.avatar_url = f"/uploads/avatars/{filename}"
    db.commit()
    db.refresh(user)
    return _serialize_user(user)

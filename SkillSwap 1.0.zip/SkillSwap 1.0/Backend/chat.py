from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List, Optional
from uuid import uuid4
import mimetypes
import re

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session, joinedload

from dataBase.db import get_db
from dataBase.models import User, Vacancy, PurchasedLesson, ChatMessage, ChatAttachment
from dependencies import get_current_user

router = APIRouter(prefix="/api/chats", tags=["chats"])

BASE_DIR = Path(__file__).resolve().parent
UPLOADS_DIR = BASE_DIR / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

MAX_FILE_SIZE = 15 * 1024 * 1024
ALLOWED_MIME_PREFIXES = ("image/",)
ALLOWED_MIME_TYPES = {
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
}
ALLOWED_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
    ".pdf", ".doc", ".docx", ".txt"
}


class ChatAttachmentResponse(BaseModel):
    id: int
    file_name: str
    file_url: str
    file_size: int
    mime_type: str
    file_kind: str

    model_config = ConfigDict(from_attributes=True)


class ChatMessageResponse(BaseModel):
    id: int
    sender_id: int
    sender_name: str
    is_current_user: bool
    text: Optional[str] = None
    created_at: str
    attachments: List[ChatAttachmentResponse] = []

    model_config = ConfigDict(from_attributes=True)


class ChatPeerResponse(BaseModel):
    id: int
    username: str
    initials: str


class ChatLessonContextResponse(BaseModel):
    purchase_id: int
    role: str
    lesson: dict
    peer: ChatPeerResponse
    current_user: dict
    can_write: bool


def _status_text(status_value: str) -> str:
    return {
        "planned": "Запланировано",
        "completed": "Завершено",
        "cancelled": "Отменено",
    }.get(status_value, "Запланировано")


def _initials(name: str) -> str:
    parts = [part for part in (name or "").split() if part]
    initials = "".join(part[0].upper() for part in parts[:2])
    return initials or (name[:2].upper() if name else "?")


def _normalize_filename(filename: str) -> str:
    stem = Path(filename).stem or "file"
    suffix = Path(filename).suffix.lower()
    stem = re.sub(r"[^0-9A-Za-zА-Яа-я._-]+", "_", stem).strip("._ ") or "file"
    suffix = re.sub(r"[^0-9A-Za-z.]+", "", suffix)
    return f"{stem}{suffix}"


def _get_purchase_or_404(db: Session, purchase_id: int) -> PurchasedLesson:
    purchase = (
        db.query(PurchasedLesson)
        .options(joinedload(PurchasedLesson.vacancy).joinedload(Vacancy.author), joinedload(PurchasedLesson.user))
        .filter(PurchasedLesson.id == purchase_id)
        .first()
    )
    if not purchase:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Занятие не найдено")
    return purchase


def _ensure_chat_access(purchase: PurchasedLesson, current_user: User) -> str:
    if purchase.status not in {"planned", "completed"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Чат доступен только для подтвержденных занятий")
    if current_user.id == purchase.user_id:
        return "student"
    if purchase.vacancy and purchase.vacancy.user_id == current_user.id:
        return "teacher"
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="У вас нет доступа к этому чату")


def _build_lesson_context(purchase: PurchasedLesson, role: str, current_user: User) -> dict:
    vacancy = purchase.vacancy
    teacher = vacancy.author
    student = purchase.user
    peer = teacher if role == "student" else student
    peer_role = "Преподаватель" if role == "student" else "Ученик"

    date_str = purchase.lesson_date.strftime("%d %B %Y, %H:%M") if purchase.lesson_date else "Не назначена"
    lesson = {
        "id": purchase.id,
        "title": vacancy.title,
        "subject": vacancy.title,
        "description": vacancy.description,
        "status": purchase.status,
        "statusText": _status_text(purchase.status),
        "date": date_str,
        "duration": "60 минут",
        "format": "Онлайн" if vacancy.formatl == "online" else "Офлайн",
        "price": vacancy.price,
        "teacher": teacher.username,
        "teacherInitials": _initials(teacher.username),
        "student": student.username,
        "studentInitials": _initials(student.username),
        "vacancy_id": vacancy.id,
        "teacher_id": teacher.id,
        "student_id": student.id,
    }

    return {
        "purchase_id": purchase.id,
        "role": role,
        "lesson": lesson,
        "peer": {
            "id": peer.id,
            "username": peer.username,
            "initials": _initials(peer.username),
            "role": peer_role,
        },
        "current_user": {
            "id": current_user.id,
            "username": current_user.username,
            "initials": _initials(current_user.username),
        },
        "can_write": purchase.status != "cancelled",
    }


def _attachment_to_response(attachment: ChatAttachment) -> dict:
    return {
        "id": attachment.id,
        "file_name": attachment.file_name,
        "file_url": attachment.file_url,
        "file_size": attachment.file_size,
        "mime_type": attachment.mime_type,
        "file_kind": attachment.file_kind,
    }


@router.get("/{purchase_id}/context")
def get_chat_context(
    purchase_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    purchase = _get_purchase_or_404(db, purchase_id)
    role = _ensure_chat_access(purchase, current_user)
    return _build_lesson_context(purchase, role, current_user)


@router.get("/{purchase_id}/messages")
def get_chat_messages(
    purchase_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    purchase = _get_purchase_or_404(db, purchase_id)
    role = _ensure_chat_access(purchase, current_user)

    messages = (
        db.query(ChatMessage)
        .options(joinedload(ChatMessage.sender), joinedload(ChatMessage.attachments))
        .filter(ChatMessage.purchase_id == purchase.id)
        .order_by(ChatMessage.created_at.asc(), ChatMessage.id.asc())
        .all()
    )

    items = []
    for message in messages:
        items.append({
            "id": message.id,
            "sender_id": message.sender_id,
            "sender_name": message.sender.username if message.sender else "Пользователь",
            "is_current_user": message.sender_id == current_user.id,
            "text": message.text,
            "created_at": message.created_at.strftime("%Y-%m-%dT%H:%M:%S") if message.created_at else datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "attachments": [_attachment_to_response(att) for att in message.attachments],
        })

    return {
        "context": _build_lesson_context(purchase, role, current_user),
        "messages": items,
    }


@router.post("/{purchase_id}/messages")
async def send_chat_message(
    purchase_id: int,
    text: Optional[str] = Form(default=""),
    files: Optional[List[UploadFile]] = File(default=None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    purchase = _get_purchase_or_404(db, purchase_id)
    role = _ensure_chat_access(purchase, current_user)

    cleaned_text = (text or "").strip()
    incoming_files = [file for file in (files or []) if file and file.filename]

    if not cleaned_text and not incoming_files:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Сообщение пустое")

    saved_paths: list[Path] = []
    try:
        message = ChatMessage(
            purchase_id=purchase.id,
            sender_id=current_user.id,
            text=cleaned_text or None,
            created_at=datetime.now(),
        )
        db.add(message)
        db.flush()

        attachments = []
        message_dir = UPLOADS_DIR / "chat" / str(purchase.id) / str(message.id)
        message_dir.mkdir(parents=True, exist_ok=True)

        for upload in incoming_files:
            content = await upload.read()
            size = len(content)
            if size == 0:
                continue
            if size > MAX_FILE_SIZE:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"Файл {upload.filename} больше 15 МБ",
                )

            original_name = _normalize_filename(upload.filename)
            extension = Path(original_name).suffix.lower()
            mime_type = upload.content_type or mimetypes.guess_type(original_name)[0] or "application/octet-stream"

            if extension not in ALLOWED_EXTENSIONS:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Формат файла {upload.filename} не поддерживается",
                )
            if not (mime_type.startswith(ALLOWED_MIME_PREFIXES) or mime_type in ALLOWED_MIME_TYPES):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Формат файла {upload.filename} не поддерживается",
                )

            unique_name = f"{uuid4().hex}_{original_name}"
            file_path = message_dir / unique_name
            with file_path.open("wb") as buffer:
                buffer.write(content)
            saved_paths.append(file_path)

            file_kind = "image" if mime_type.startswith("image/") else "document"
            relative_url = f"/uploads/chat/{purchase.id}/{message.id}/{unique_name}"
            attachments.append(ChatAttachment(
                message_id=message.id,
                file_name=original_name,
                file_url=relative_url,
                file_size=size,
                mime_type=mime_type,
                file_kind=file_kind,
            ))

        for attachment in attachments:
            db.add(attachment)

        db.commit()
        db.refresh(message)

        return {
            "success": True,
            "message": {
                "id": message.id,
                "sender_id": current_user.id,
                "sender_name": current_user.username,
                "is_current_user": True,
                "text": message.text,
                "created_at": message.created_at.strftime("%Y-%m-%dT%H:%M:%S"),
                "attachments": [_attachment_to_response(att) for att in message.attachments],
            },
            "role": role,
        }

    except HTTPException:
        db.rollback()
        for path in saved_paths:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
        raise
    except Exception as exc:
        db.rollback()
        for path in saved_paths:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Не удалось отправить сообщение: {exc}")


@router.get("/attachments/{attachment_id}")
def get_attachment_info(
    attachment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    attachment = (
        db.query(ChatAttachment)
        .options(joinedload(ChatAttachment.message).joinedload(ChatMessage.purchase).joinedload(PurchasedLesson.vacancy))
        .filter(ChatAttachment.id == attachment_id)
        .first()
    )
    if not attachment:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Файл не найден")

    purchase = attachment.message.purchase
    if current_user.id not in (purchase.user_id, purchase.vacancy.user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Нет доступа к файлу")

    return {
        "id": attachment.id,
        "file_name": attachment.file_name,
        "file_url": attachment.file_url,
        "file_size": attachment.file_size,
        "mime_type": attachment.mime_type,
        "file_kind": attachment.file_kind,
    }

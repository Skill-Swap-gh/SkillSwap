from __future__ import annotations

import json
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session, joinedload

from dataBase.db import get_db
from dataBase.models import Notification, PurchasedLesson, User, Vacancy
from dependencies import get_current_user

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


class NotificationActionResponse(BaseModel):
    success: bool
    message: str
    purchase_id: Optional[int] = None
    notification_id: Optional[int] = None
    current_points: Optional[int] = None


class NotificationReadResponse(BaseModel):
    success: bool


class NotificationItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    type: str
    title: str
    message: str
    is_read: bool
    created_at: str
    sender_id: Optional[int] = None
    sender_name: Optional[str] = None
    purchase_id: Optional[int] = None
    purchase_status: Optional[str] = None
    requester_name: Optional[str] = None
    requester_id: Optional[int] = None
    skill_title: Optional[str] = None
    skill_description: Optional[str] = None
    price: Optional[int] = None
    action_required: bool = False
    can_accept: bool = False
    can_reject: bool = False


SERVICE_TYPES = {"purchase_request", "purchase_approved", "purchase_rejected"}


def _serialize_notification(notification: Notification) -> dict:
    payload = {}
    if notification.payload:
        try:
            payload = json.loads(notification.payload)
        except Exception:
            payload = {}

    sender = notification.sender
    purchase = notification.purchase
    vacancy = purchase.vacancy if purchase and purchase.vacancy else None
    requester = purchase.user if purchase and purchase.user else None

    purchase_status = purchase.status if purchase else None
    request_type = notification.type == "purchase_request"

    return {
        "id": notification.id,
        "type": notification.type,
        "title": notification.title,
        "message": notification.message,
        "is_read": notification.is_read,
        "created_at": notification.created_at.strftime("%Y-%m-%dT%H:%M:%S") if notification.created_at else datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "sender_id": notification.sender_id,
        "sender_name": sender.username if sender else payload.get("sender_name"),
        "purchase_id": notification.purchase_id,
        "purchase_status": purchase_status,
        "requester_name": requester.username if requester else payload.get("requester_name"),
        "requester_id": requester.id if requester else payload.get("requester_id"),
        "skill_title": vacancy.title if vacancy else payload.get("skill_title"),
        "skill_description": vacancy.description if vacancy else payload.get("skill_description"),
        "price": vacancy.price if vacancy else payload.get("price"),
        "action_required": request_type and purchase_status == "pending",
        "can_accept": request_type and purchase_status == "pending",
        "can_reject": request_type and purchase_status == "pending",
    }


def create_notification(
    db: Session,
    *,
    recipient_id: int,
    type: str,
    title: str,
    message: str,
    sender_id: Optional[int] = None,
    purchase_id: Optional[int] = None,
    payload: Optional[dict] = None,
) -> Notification:
    if type not in SERVICE_TYPES:
        raise ValueError(f"Unsupported notification type: {type}")

    notification = Notification(
        recipient_id=recipient_id,
        sender_id=sender_id,
        purchase_id=purchase_id,
        type=type,
        title=title,
        message=message,
        payload=json.dumps(payload or {}, ensure_ascii=False),
        is_read=False,
        created_at=datetime.now(),
    )
    db.add(notification)
    db.flush()
    return notification


@router.get("")
def list_notifications(
    unread_only: bool = True,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = (
        db.query(Notification)
        .options(
            joinedload(Notification.sender),
            joinedload(Notification.purchase)
            .joinedload(PurchasedLesson.vacancy)
            .joinedload(Vacancy.author),
            joinedload(Notification.purchase).joinedload(PurchasedLesson.user),
        )
        .filter(Notification.recipient_id == current_user.id)
        .order_by(Notification.created_at.desc(), Notification.id.desc())
    )
    if unread_only:
        query = query.filter(Notification.is_read.is_(False))

    items = [_serialize_notification(item) for item in query.all()]
    return {"items": items}


@router.get("/count")
def notifications_count(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    count = (
        db.query(Notification)
        .filter(Notification.recipient_id == current_user.id, Notification.is_read.is_(False))
        .count()
    )
    return {"count": count}


@router.post("/{notification_id}/read")
def mark_notification_read(
    notification_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notification = (
        db.query(Notification)
        .filter(Notification.id == notification_id, Notification.recipient_id == current_user.id)
        .first()
    )
    if not notification:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Уведомление не найдено")

    notification.is_read = True
    db.commit()
    return {"success": True}


@router.post("/{notification_id}/accept", response_model=NotificationActionResponse)
def accept_purchase_request(
    notification_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notification = (
        db.query(Notification)
        .options(
            joinedload(Notification.purchase)
            .joinedload(PurchasedLesson.vacancy)
            .joinedload(Vacancy.author),
            joinedload(Notification.purchase).joinedload(PurchasedLesson.user),
        )
        .filter(Notification.id == notification_id, Notification.recipient_id == current_user.id)
        .first()
    )
    if not notification:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Уведомление не найдено")

    purchase = notification.purchase
    if not purchase or notification.type != "purchase_request":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Неверный тип уведомления")

    if purchase.status != "pending":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Заявка уже обработана")

    vacancy = purchase.vacancy
    buyer = purchase.user
    teacher = current_user

    if not vacancy or vacancy.user_id != teacher.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Нет доступа к этой заявке")

    teacher.points += vacancy.price
    purchase.status = "planned"
    notification.is_read = True

    create_notification(
        db,
        recipient_id=buyer.id,
        type="purchase_approved",
        title="Покупка одобрена",
        message="вашу покупку одобрили! загляните в ваши занятия!",
        sender_id=teacher.id,
        purchase_id=purchase.id,
        payload={
            "purchase_id": purchase.id,
            "skill_title": vacancy.title,
            "skill_description": vacancy.description,
            "price": vacancy.price,
            "teacher_name": teacher.username,
        },
    )

    db.commit()
    return NotificationActionResponse(success=True, message="Покупка одобрена", purchase_id=purchase.id, notification_id=notification.id, current_points=teacher.points)


@router.post("/{notification_id}/reject", response_model=NotificationActionResponse)
def reject_purchase_request(
    notification_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notification = (
        db.query(Notification)
        .options(
            joinedload(Notification.purchase)
            .joinedload(PurchasedLesson.vacancy)
            .joinedload(Vacancy.author),
            joinedload(Notification.purchase).joinedload(PurchasedLesson.user),
        )
        .filter(Notification.id == notification_id, Notification.recipient_id == current_user.id)
        .first()
    )
    if not notification:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Уведомление не найдено")

    purchase = notification.purchase
    if not purchase or notification.type != "purchase_request":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Неверный тип уведомления")

    if purchase.status != "pending":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Заявка уже обработана")

    vacancy = purchase.vacancy
    buyer = purchase.user
    teacher = current_user

    if not vacancy or vacancy.user_id != teacher.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Нет доступа к этой заявке")

    buyer.points += vacancy.price
    purchase.status = "cancelled"
    notification.is_read = True

    create_notification(
        db,
        recipient_id=buyer.id,
        type="purchase_rejected",
        title="Покупка отменена",
        message="вашу покупку отменили.",
        sender_id=teacher.id,
        purchase_id=purchase.id,
        payload={
            "purchase_id": purchase.id,
            "skill_title": vacancy.title,
            "skill_description": vacancy.description,
            "price": vacancy.price,
            "teacher_name": teacher.username,
        },
    )

    db.commit()
    return NotificationActionResponse(success=True, message="Покупка отклонена", purchase_id=purchase.id, notification_id=notification.id, current_points=teacher.points)

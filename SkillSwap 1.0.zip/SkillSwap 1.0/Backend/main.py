
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
import mimetypes

from auth import router as router_auth
from ProfileLoad import router as router_ProfLoad
from vacancies import router as router_vacancies
from xp_system import router as router_xp
from purchases import router as router_purchases
from notifications import router as router_notifications
from chat import router as router_chat

from dataBase.db import engine, Base, SessionLocal
from dataBase.models import User, Vacancy, PurchasedLesson, ChatMessage, ChatAttachment, Notification
from sqlalchemy import text

app = FastAPI()

mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')
mimetypes.add_type('text/html', '.html')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "Frontend"
UPLOADS_DIR = BASE_DIR / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

DEMO_VACANCIES = [
    {"title": "Алгебра", "formatl": "online", "description": "Разберу уравнения, неравенства, функции и подготовлю к контрольным по алгебре.", "price": 40},
    {"title": "Геометрия", "formatl": "offline", "description": "Объясню теоремы, построения, площади и объёмы на понятных примерах.", "price": 50},
    {"title": "Физика", "formatl": "online", "description": "Помогу с механикой, электричеством, задачами и подготовкой к проверочным.", "price": 60},
    {"title": "Химия", "formatl": "online", "description": "Разберём реакции, формулы, уравнения и типовые задачи по химии.", "price": 55},
    {"title": "Биология", "formatl": "offline", "description": "Поясню анатомию, генетику, ботанику и вопросы для экзамена.", "price": 45},
    {"title": "Английский язык", "formatl": "online", "description": "Практика грамматики, чтения, аудирования и разговорной речи.", "price": 50},
    {"title": "Русский язык", "formatl": "offline", "description": "Подготовка по орфографии, пунктуации и сочинениям.", "price": 35},
    {"title": "История", "formatl": "online", "description": "Кратко и понятно пройдём основные эпохи и события.", "price": 30},
    {"title": "География", "formatl": "online", "description": "Помогу с картами, странами, климатом и подготовкой к урокам.", "price": 30},
    {"title": "Обществознание", "formatl": "offline", "description": "Разберём право, экономику, политику и социальные темы.", "price": 40},
    {"title": "Литература", "formatl": "online", "description": "Разбор произведений, персонажей и подготовка к сочинениям.", "price": 25},
    {"title": "Музыка", "formatl": "offline", "description": "Развиваю слух, ритм, нотную грамоту и основы игры.", "price": 70},
    {"title": "Рисование", "formatl": "offline", "description": "Покажу основы композиции, перспективы и работы с цветом.", "price": 60},
    {"title": "Шахматы", "formatl": "online", "description": "Стратегии, дебюты, тактика и разбор партий.", "price": 45},
    {"title": "Экономика", "formatl": "online", "description": "Объясню базовые законы экономики, спрос, предложение и финансы.", "price": 65},
    {"title": "Информатика", "formatl": "online", "description": "Алгоритмы, логика, программы и основы цифровой грамотности.", "price": 55},
    {"title": "Python", "formatl": "online", "description": "Научу синтаксису Python, функциям, спискам и простым проектам.", "price": 80},
    {"title": "JavaScript", "formatl": "online", "description": "Научу основам JavaScript, DOM, событиям и интерактивным страницам.", "price": 75},
    {"title": "HTML/CSS", "formatl": "online", "description": "Объясню верстку, семантику, адаптивную сетку и стилизацию.", "price": 60},
]


def _ensure_sqlite_column(conn, table_name: str, column_name: str, column_sql: str) -> None:
    rows = conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()
    existing = {row[1] for row in rows}
    if column_name not in existing:
        conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_sql}"))


def _run_migrations():
    with engine.begin() as conn:
        _ensure_sqlite_column(conn, "users", "avatar_url", "avatar_url VARCHAR DEFAULT ''")


def _seed_demo_vacancies():
    db = SessionLocal()
    try:
        first_user = db.query(User).order_by(User.id.asc()).first()
        if not first_user:
            return
        existing_titles = {title for (title,) in db.query(Vacancy.title).all()}
        added = False
        for item in DEMO_VACANCIES:
            if item["title"] in existing_titles:
                continue
            db.add(Vacancy(
                title=item["title"],
                formatl=item["formatl"],
                user_id=first_user.id,
                description=item["description"],
                price=item["price"],
                type="teach",
            ))
            added = True
        if added:
            db.commit()
    finally:
        db.close()


Base.metadata.create_all(bind=engine)
_run_migrations()
_seed_demo_vacancies()

app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")
app.mount("/uploads", StaticFiles(directory=str(UPLOADS_DIR)), name="uploads")

app.include_router(router_auth)
app.include_router(router_ProfLoad)
app.include_router(router_vacancies)
app.include_router(router_xp)
app.include_router(router_purchases)
app.include_router(router_notifications)
app.include_router(router_chat)

@app.get("/")
async def root():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/catalog.html")
async def catalog_page():
    return FileResponse(FRONTEND_DIR / "catalog.html")

@app.get("/modals.html")
async def modals_page():
    return FileResponse(FRONTEND_DIR / "modals.html")

@app.get("/modal-purchase.html")
async def modal_purchase_page():
    return FileResponse(FRONTEND_DIR / "modal-purchase.html")

@app.get("/profile-skills-modals.html")
async def profile_skills_modals():
    return FileResponse(FRONTEND_DIR / "profile-skills-modals.html")

@app.get("/profile-skills-cards.html")
async def profile_skills_cards():
    return FileResponse(FRONTEND_DIR / "profile-skills-cards.html")

@app.get("/profile.html")
async def profile_page():
    return FileResponse(FRONTEND_DIR / "profile.html")

@app.get("/lesson.html")
async def lesson_page():
    return FileResponse(FRONTEND_DIR / "lesson.html")

@app.get("/chat.html")
async def chat_page():
    return FileResponse(FRONTEND_DIR / "chat.html")

@app.get("/favicon.ico")
async def favicon():
    favicon_path = FRONTEND_DIR / "images" / "favicon.ico"
    if favicon_path.exists():
        return FileResponse(favicon_path)
    else:
        return Response(status_code=204)

from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from dataBase.models import User
from fastapi import APIRouter, Depends, HTTPException, status
from dataBase.db import get_db
from dependencies import get_current_user

router = APIRouter(prefix="/api/xp", tags=["xp"])

def check_and_add_daily_xp(user: User, db: Session) -> bool:

    now = datetime.now()

    if not user.last_xp_claim:
        user.last_xp_claim = now
        db.commit()
        return False
    

    time_diff = now - user.last_xp_claim
    if time_diff >= timedelta(hours=24):

        user.points += 20
        user.last_xp_claim = now
        db.commit()
        return True
    
    return False

@router.get("/status")
async def get_xp_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    
    xp_added = check_and_add_daily_xp(current_user, db)
    
    now = datetime.now()
    if current_user.last_xp_claim:
        next_claim = current_user.last_xp_claim + timedelta(hours=24)
        seconds_until_next = max(0, (next_claim - now).total_seconds())
    else:
        seconds_until_next = 0
    
    return {
        "points": current_user.points,
        "last_claim": current_user.last_xp_claim.isoformat() if current_user.last_xp_claim else None,
        "next_claim_in_seconds": seconds_until_next,
        "xp_added_just_now": xp_added
    }

@router.post("/check-daily")
async def check_daily_xp(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    xp_added = check_and_add_daily_xp(current_user, db)
    
    next_claim = current_user.last_xp_claim + timedelta(hours=24)
    now = datetime.now()
    seconds_until_next = max(0, (next_claim - now).total_seconds())
    
    return {
        "points": current_user.points,
        "xp_added": xp_added,
        "next_claim_in_seconds": seconds_until_next
    }
@router.post("/migrate")
async def migrate_users_xp(db: Session = Depends(get_db)):
    users = db.query(User).all()
    updated_count = 0
    
    for user in users:
        if not user.last_xp_claim:
            user.last_xp_claim = datetime.now()
            updated_count += 1
    
    db.commit()
    
    return {
        "message": f"Обновлено {updated_count} пользователей",
        "total_users": len(users)
    }
from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Boolean
from dataBase.db import Base
from sqlalchemy.orm import relationship
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    
    ClassRoom = Column(String, default="Не указано")
    ClassRoomChar = Column(String, default="Не указано")
    School = Column(String, default="Не указано")
    phone = Column(String, default="Не указано")
    about_me = Column(String, default="Не указано")
    avatar_url = Column(String, default="")
    points = Column(Integer, default=100)
    last_xp_claim = Column(DateTime, default=datetime.now)

    vacancies = relationship("Vacancy", back_populates="author")
    purchased_lessons = relationship("PurchasedLesson", back_populates="user")
    sent_messages = relationship("ChatMessage", back_populates="sender")
    notifications_received = relationship("Notification", foreign_keys="Notification.recipient_id", back_populates="recipient")
    notifications_sent = relationship("Notification", foreign_keys="Notification.sender_id", back_populates="sender")


class Vacancy(Base):
    __tablename__ = "vacancies"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    formatl = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    description = Column(String(200), nullable=False)
    price = Column(Integer, nullable=False)
    type = Column(String, nullable=False)

    author = relationship("User", back_populates="vacancies")
    purchased_by = relationship("PurchasedLesson", back_populates="vacancy")


class PurchasedLesson(Base):
    __tablename__ = "purchased_lessons"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    vacancy_id = Column(Integer, ForeignKey("vacancies.id"), nullable=False)
    purchase_date = Column(DateTime, default=datetime.now)
    lesson_date = Column(DateTime, nullable=True)
    status = Column(String, default="pending")
    notes = Column(String, default="")

    user = relationship("User", back_populates="purchased_lessons")
    vacancy = relationship("Vacancy", back_populates="purchased_by")
    chat_messages = relationship("ChatMessage", back_populates="purchase", cascade="all, delete-orphan")


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    purchase_id = Column(Integer, ForeignKey("purchased_lessons.id"), nullable=False, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    text = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now, index=True)

    purchase = relationship("PurchasedLesson", back_populates="chat_messages")
    sender = relationship("User", back_populates="sent_messages")
    attachments = relationship("ChatAttachment", back_populates="message", cascade="all, delete-orphan")


class ChatAttachment(Base):
    __tablename__ = "chat_attachments"

    id = Column(Integer, primary_key=True, index=True)
    message_id = Column(Integer, ForeignKey("chat_messages.id"), nullable=False, index=True)
    file_name = Column(String, nullable=False)
    file_url = Column(String, nullable=False)
    file_size = Column(Integer, nullable=False)
    mime_type = Column(String, nullable=False)
    file_kind = Column(String, nullable=False, default="file")

    message = relationship("ChatMessage", back_populates="attachments")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    recipient_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    purchase_id = Column(Integer, ForeignKey("purchased_lessons.id"), nullable=True, index=True)
    type = Column(String, nullable=False)
    title = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    payload = Column(Text, nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.now, index=True)

    recipient = relationship("User", foreign_keys=[recipient_id], back_populates="notifications_received")
    sender = relationship("User", foreign_keys=[sender_id], back_populates="notifications_sent")
    purchase = relationship("PurchasedLesson")

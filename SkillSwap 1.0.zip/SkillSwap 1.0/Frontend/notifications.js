const API_BASE = '';

function getToken() {
    return localStorage.getItem('access_token');
}

function ensureModal() {
    let modal = document.getElementById('notificationsModal');
    if (modal) return modal;

    modal = document.createElement('div');
    modal.id = 'notificationsModal';
    modal.className = 'notifications-modal';
    modal.innerHTML = `
        <div class="notifications-modal-content">
            <button type="button" class="notifications-close" aria-label="Закрыть">&times;</button>
            <div class="notifications-header">
                <div>
                    <h2 class="notifications-title">Уведомления</h2>
                    <p class="notifications-subtitle">Предложения обмена и ответы на покупки</p>
                </div>
                <span class="notifications-chip" id="notificationsCountChip">0</span>
            </div>
            <div class="notifications-list" id="notificationsList">
                <div class="notifications-empty">Загрузка...</div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeNotificationsModal();
        }
    });

    modal.querySelector('.notifications-close')?.addEventListener('click', closeNotificationsModal);
    return modal;
}

function closeNotificationsModal() {
    const modal = document.getElementById('notificationsModal');
    if (modal) modal.style.display = 'none';
    document.body.style.overflow = '';
}

function openAuthPrompt() {
    const authModal3 = document.getElementById('authModal3');
    if (authModal3) {
        authModal3.style.display = 'block';
    } else {
        alert('Необходимо авторизоваться');
    }
}

async function apiFetch(path, options = {}) {
    const token = getToken();
    if (!token) {
        throw new Error('Требуется авторизация');
    }

    const headers = { ...(options.headers || {}) };
    if (!(options.body instanceof FormData)) {
        headers['Content-Type'] = headers['Content-Type'] || 'application/json';
    }
    headers.Authorization = `Bearer ${token}`;

    const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
    if (response.status === 401) {
        openAuthPrompt();
        throw new Error('Unauthorized');
    }
    return response;
}

async function loadNotifications() {
    const response = await apiFetch('/api/notifications?unread_only=true');
    const data = await response.json();
    return Array.isArray(data.items) ? data.items : [];
}

async function loadNotificationCount() {
    const token = getToken();
    if (!token) return 0;
    try {
        const response = await apiFetch('/api/notifications/count');
        if (!response.ok) return 0;
        const data = await response.json();
        return Number(data.count || 0);
    } catch {
        return 0;
    }
}

function updateBadge(count) {
    const badge = document.getElementById('notificationsBadge');
    const chip = document.getElementById('notificationsCountChip');
    if (badge) {
        if (count > 0) {
            badge.hidden = false;
            badge.textContent = String(count > 99 ? '99+' : count);
        } else {
            badge.hidden = true;
            badge.textContent = '0';
        }
    }
    if (chip) {
        chip.textContent = String(count > 99 ? '99+' : count);
    }
}

function updatePointsDisplay(points) {
    document.querySelectorAll('.points, .points-value').forEach((el) => {
        if (el.classList.contains('points')) {
            el.textContent = `${points} XP`;
        } else if (el.classList.contains('points-value')) {
            el.textContent = String(points);
        }
    });
}

function formatAttachmentSummary(item) {
    const price = item.price ? `${item.price} XP` : '';
    const skill = item.skill_title ? `Навык: ${item.skill_title}` : '';
    const requester = item.requester_name ? `От: ${item.requester_name}` : '';
    return [skill, requester, price].filter(Boolean).join(' · ');
}

function createNotificationCard(item) {
    const card = document.createElement('div');
    card.className = `notification-card ${item.action_required ? 'notification-card-request' : 'notification-card-info'}`;
    card.dataset.notificationId = item.id;

    const meta = document.createElement('div');
    meta.className = 'notification-meta';

    const title = document.createElement('div');
    title.className = 'notification-title';
    title.textContent = item.title || 'Уведомление';

    const time = document.createElement('div');
    time.className = 'notification-time';
    try {
        time.textContent = new Intl.DateTimeFormat('ru-RU', {
            day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
        }).format(new Date(item.created_at));
    } catch {
        time.textContent = '';
    }

    meta.appendChild(title);
    meta.appendChild(time);

    const message = document.createElement('div');
    message.className = 'notification-message';
    message.textContent = item.message || '';

    const summary = document.createElement('div');
    summary.className = 'notification-summary';
    summary.textContent = formatAttachmentSummary(item);

    const actions = document.createElement('div');
    actions.className = 'notification-actions';

    if (item.action_required && item.can_accept && item.can_reject) {
        const acceptBtn = document.createElement('button');
        acceptBtn.type = 'button';
        acceptBtn.className = 'notification-btn notification-btn-accept';
        acceptBtn.textContent = 'Принять';
        acceptBtn.addEventListener('click', async () => {
            await handleNotificationAction(item.id, 'accept');
        });

        const rejectBtn = document.createElement('button');
        rejectBtn.type = 'button';
        rejectBtn.className = 'notification-btn notification-btn-reject';
        rejectBtn.textContent = 'Отклонить';
        rejectBtn.addEventListener('click', async () => {
            await handleNotificationAction(item.id, 'reject');
        });

        actions.appendChild(acceptBtn);
        actions.appendChild(rejectBtn);
    } else {
        const readBtn = document.createElement('button');
        readBtn.type = 'button';
        readBtn.className = 'notification-btn notification-btn-read';
        readBtn.textContent = 'Прочитано';
        readBtn.addEventListener('click', async () => {
            await handleNotificationAction(item.id, 'read');
        });
        actions.appendChild(readBtn);
    }

    card.appendChild(meta);
    card.appendChild(message);
    if (summary.textContent) card.appendChild(summary);
    card.appendChild(actions);
    return card;
}

async function renderNotifications() {
    const modal = ensureModal();
    const list = document.getElementById('notificationsList');
    if (!list) return;

    list.innerHTML = '<div class="notifications-empty">Загрузка...</div>';

    try {
        const items = await loadNotifications();
        const count = items.length;
        const chip = document.getElementById('notificationsCountChip');
        if (chip) chip.textContent = String(count > 99 ? '99+' : count);
        updateBadge(count);

        if (!count) {
            list.innerHTML = '<div class="notifications-empty">У вас нет новых уведомлений</div>';
            return;
        }

        list.innerHTML = '';
        items.forEach((item) => {
            list.appendChild(createNotificationCard(item));
        });
    } catch (error) {
        console.error('Ошибка загрузки уведомлений:', error);
        list.innerHTML = '<div class="notifications-empty">Не удалось загрузить уведомления</div>';
    }
}

async function handleNotificationAction(notificationId, action) {
    try {
        let path = `/api/notifications/${notificationId}/read`;
        let method = 'POST';
        if (action === 'accept') path = `/api/notifications/${notificationId}/accept`;
        if (action === 'reject') path = `/api/notifications/${notificationId}/reject`;

        const response = await apiFetch(path, { method });
        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(data.detail || 'Не удалось обработать уведомление');
        }

        if (data.current_points !== undefined && data.current_points !== null) {
            updatePointsDisplay(data.current_points);
        }
        await renderNotifications();
        await refreshNotificationBadge();
    } catch (error) {
        alert(error.message || 'Не удалось обработать уведомление');
    }
}

async function refreshNotificationBadge() {
    const count = await loadNotificationCount();
    updateBadge(count);
}

async function openNotificationsModal() {
    if (!getToken()) {
        openAuthPrompt();
        return;
    }

    const modal = ensureModal();
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    await renderNotifications();
}

function initNotificationSystem() {
    ensureModal();

    document.addEventListener('click', (event) => {
        const bellButton = event.target.closest('.bell-btn, #notificationsBtn');
        if (bellButton) {
            event.preventDefault();
            openNotificationsModal();
        }
    });

    if (window.__skillswapNotificationBadgeTimer) {
        clearInterval(window.__skillswapNotificationBadgeTimer);
    }
    window.__skillswapNotificationBadgeTimer = setInterval(refreshNotificationBadge, 15000);

    refreshNotificationBadge();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initNotificationSystem);
} else {
    initNotificationSystem();
}

export { initNotificationSystem, openNotificationsModal, refreshNotificationBadge };

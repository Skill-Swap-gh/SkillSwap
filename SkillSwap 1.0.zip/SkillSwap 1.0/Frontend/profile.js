import { performLogout } from "./scripts.js";
import { renderAllLessons, initLessonFilters } from "./lesson.js";

document.addEventListener('DOMContentLoaded', function() {
    const defaultUserData = {
        name: "",
        class: "",
        letter: "",
        school: "",
        email: "",
        phone: "",
        about: "",
        avatarUrl: "",
        points: "0"
    };

    let userData = { ...defaultUserData };

    const navTabs = document.querySelectorAll('.nav-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const settingsForm = document.getElementById('settingsForm');
    const fileInput = document.getElementById('userAvatar');
    const fileStatus = document.querySelector('.file-status');
    const avatarPlaceholder = document.getElementById('profileAvatarPlaceholder');
    const userInfo = document.getElementById('userInfo');

    function isMeaningful(value) {
        return value && value.trim() && value !== 'Не указано';
    }

    function transformProfileData(profileData) {
        return {
            name: profileData.username || "",
            class: profileData.ClassRoom || "",
            letter: profileData.ClassRoomChar || "",
            school: profileData.School || "",
            email: profileData.email || "",
            phone: profileData.phone || "",
            about: profileData.about_me || "",
            avatarUrl: profileData.avatar_url || "",
            points: profileData.points?.toString() || "0"
        };
    }

    function getFullClassLabel() {
        const classPartRaw = [userData.class, userData.letter].filter(isMeaningful).join('');
        const schoolPart = isMeaningful(userData.school) ? userData.school.trim() : '';
        if (classPartRaw && schoolPart) return `${classPartRaw} • ${schoolPart}`;
        if (classPartRaw) return classPartRaw;
        if (schoolPart) return schoolPart;
        return 'Класс и школа не указаны';
    }

    function getInitials(name) {
        if (!name) return 'S';
        const parts = name.trim().split(/\s+/).filter(Boolean);
        return parts.slice(0, 2).map(part => part[0]).join('').toUpperCase() || name.slice(0, 2).toUpperCase();
    }

    function updateAvatarPreview(avatarUrl = '') {
        if (!avatarPlaceholder) return;
        const initials = getInitials(userData.name || 'SkillSwap');
        if (avatarUrl) {
            avatarPlaceholder.style.backgroundImage = `url(${avatarUrl})`;
            avatarPlaceholder.classList.add('has-avatar');
            avatarPlaceholder.textContent = '';
            return;
        }
        avatarPlaceholder.style.backgroundImage = '';
        avatarPlaceholder.classList.remove('has-avatar');
        avatarPlaceholder.textContent = initials;
    }

    function populateSettingsForm() {
        document.getElementById('userName').textContent = userData.name || 'Пользователь';
        document.getElementById('userNameInput').value = userData.name;
        document.getElementById('userClass').value = userData.class;
        document.getElementById('userLetter').value = userData.letter;
        document.getElementById('userSchool').value = userData.school;
        document.getElementById('userEmail').value = userData.email;
        document.getElementById('userPhone').value = userData.phone;
        document.getElementById('userAbout').value = userData.about;
        if (userInfo) {
            userInfo.textContent = getFullClassLabel();
        }
        updateAvatarPreview(userData.avatarUrl);
    }

    async function initializeUserData() {
        try {
            const token = localStorage.getItem('access_token');
            if (!token) return;

            const response = await fetch('http://127.0.0.1:8000/ProfileLoad/profile', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const profileData = await response.json();
            userData = transformProfileData(profileData);
            populateSettingsForm();
            updateXPInProfile();
        } catch (error) {
            console.error('Ошибка при загрузке данных профиля:', error);
            populateSettingsForm();
        }
    }

    navTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');

            navTabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            this.classList.add('active');
            document.getElementById(`${targetTab}-tab`).classList.add('active');

            if (targetTab === 'lessons') {
                setTimeout(() => {
                    renderAllLessons();
                    initLessonFilters();
                }, 100);
            }
        });
    });

    if (fileInput) {
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                fileStatus.textContent = this.files[0].name;
                const file = this.files[0];
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = () => updateAvatarPreview(reader.result);
                    reader.readAsDataURL(file);
                }
            } else {
                fileStatus.textContent = 'Файл не выбран';
                updateAvatarPreview(userData.avatarUrl);
            }
        });
    }

    if (settingsForm) {
        settingsForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const formData = {
                username: document.getElementById('userNameInput').value,
                ClassRoom: document.getElementById('userClass').value,
                ClassRoomChar: document.getElementById('userLetter').value,
                School: document.getElementById('userSchool').value,
                email: document.getElementById('userEmail').value,
                phone: document.getElementById('userPhone').value,
                about_me: document.getElementById('userAbout').value
            };

            const token = localStorage.getItem('access_token');
            if (!token) {
                alert('Необходимо авторизоваться');
                return;
            }

            try {
                const response = await fetch('http://127.0.0.1:8000/ProfileLoad/profileUpdate', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                if (!response.ok) {
                    throw new Error('Ошибка при обновлении профиля: ' + response.status);
                }

                const updatedData = await response.json();
                userData = transformProfileData(updatedData);
                populateSettingsForm();

                const avatarFile = fileInput && fileInput.files && fileInput.files[0];
                if (avatarFile) {
                    if (avatarFile.size > 15 * 1024 * 1024) {
                        alert('Файл должен быть не больше 15 МБ');
                    } else {
                        const avatarFormData = new FormData();
                        avatarFormData.append('avatar', avatarFile);

                        const avatarResponse = await fetch('http://127.0.0.1:8000/ProfileLoad/avatar', {
                            method: 'POST',
                            headers: {
                                'Authorization': `Bearer ${token}`
                            },
                            body: avatarFormData
                        });

                        if (!avatarResponse.ok) {
                            throw new Error('Не удалось загрузить аватар');
                        }

                        const avatarData = await avatarResponse.json();
                        userData = transformProfileData(avatarData);
                        populateSettingsForm();
                    }
                    if (fileInput) fileInput.value = '';
                    if (fileStatus) fileStatus.textContent = 'Файл не выбран';
                }

                alert('Настройки сохранены!');
            } catch (error) {
                console.error('Ошибка при отправке данных профиля:', error);
                alert('Не удалось сохранить настройки');
            }
        });
    }

    initializeUserData();

    const exit = document.querySelector('.btn-exit');
    if (exit) {
        exit.addEventListener('click', () => {
            performLogout();
        });
    }

    const activeTab = document.querySelector('.nav-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'lessons') {
        setTimeout(() => {
            renderAllLessons();
            initLessonFilters();
        }, 500);
    }

    console.log('📄 Profile.js загружен');
});

async function updateXPInProfile() {
    const token = localStorage.getItem('access_token');
    if (!token) return;

    try {
        const response = await fetch('http://localhost:8000/api/xp/check-daily', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            const pointsValue = document.querySelector('.points-value');
            if (pointsValue) {
                pointsValue.textContent = data.points;
            }
        }
    } catch (error) {
        console.error('Ошибка при обновлении XP в профиле:', error);
    }
}

export { updateXPInProfile };

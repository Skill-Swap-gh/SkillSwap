const HEADER_SELECTOR = '.header';
const MENU_OPEN_CLASS = 'is-menu-open';
const BODY_OPEN_CLASS = 'menu-open';
const DESKTOP_BREAKPOINT = window.matchMedia('(min-width: 769px)');

function setHeaderState(header, open) {
    const burger = header.querySelector('[data-burger-button]');
    header.classList.toggle(MENU_OPEN_CLASS, open);
    document.body.classList.toggle(BODY_OPEN_CLASS, open);

    if (burger) {
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
}

function closeHeaderMenu(header) {
    setHeaderState(header, false);
}

function initHeaderMenu(header) {
    const burger = header.querySelector('[data-burger-button]');
    const overlay = header.querySelector('[data-header-overlay]');
    const closeBtn = header.querySelector('[data-menu-close]');
    const menu = header.querySelector('[data-header-menu]');

    if (!burger || !menu) {
        return;
    }

    burger.addEventListener('click', () => {
        const isOpen = header.classList.contains(MENU_OPEN_CLASS);
        setHeaderState(header, !isOpen);
    });

    overlay?.addEventListener('click', () => closeHeaderMenu(header));
    closeBtn?.addEventListener('click', () => closeHeaderMenu(header));

    menu.addEventListener('click', (event) => {
        const target = event.target.closest('a, button');
        if (!target) return;
        if (target.matches('[data-menu-close]')) return;
        if (target.closest('[data-header-menu]')) {
            closeHeaderMenu(header);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && header.classList.contains(MENU_OPEN_CLASS)) {
            closeHeaderMenu(header);
        }
    });

    const handleDesktopChange = (event) => {
        if (event.matches) {
            closeHeaderMenu(header);
        }
    };

    if (typeof DESKTOP_BREAKPOINT.addEventListener === 'function') {
        DESKTOP_BREAKPOINT.addEventListener('change', handleDesktopChange);
    } else if (typeof DESKTOP_BREAKPOINT.addListener === 'function') {
        DESKTOP_BREAKPOINT.addListener(handleDesktopChange);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll(HEADER_SELECTOR).forEach(initHeaderMenu);
});

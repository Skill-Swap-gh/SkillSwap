// Функция для загрузки занятий, где пользователь - ученик
async function loadMyLessons() {
    const token = localStorage.getItem('access_token');
    
    if (!token) {
        console.log('Пользователь не авторизован');
        return [];
    }
    
    try {
        const response = await fetch('http://localhost:8000/api/purchases/my-lessons', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const lessons = await response.json();
            console.log('📚 Мои занятия (я ученик):', lessons);
            return lessons;
        } else {
            console.error('Ошибка загрузки занятий:', response.status);
            return [];
        }
    } catch (error) {
        console.error('Ошибка при загрузке занятий:', error);
        return [];
    }
}

// Функция для загрузки занятий, где пользователь - учитель
async function loadMyTaughtLessons() {
    const token = localStorage.getItem('access_token');
    
    if (!token) {
        console.log('Пользователь не авторизован');
        return [];
    }
    
    try {
        const response = await fetch('http://localhost:8000/api/purchases/my-taught-lessons', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const lessons = await response.json();
            console.log('👨‍🏫 Мои занятия (я учитель):', lessons);
            return lessons;
        } else {
            console.error('Ошибка загрузки занятий учителя:', response.status);
            return [];
        }
    } catch (error) {
        console.error('Ошибка при загрузке занятий учителя:', error);
        return [];
    }
}

// Функция для отображения ВСЕХ занятий в одном списке
async function renderAllLessons() {
    const lessonsContent = document.querySelector('.lessons-content');
    if (!lessonsContent) {
        console.log('Элемент .lessons-content не найден');
        return;
    }

    lessonsContent.innerHTML = '<div class="empty-lessons">Загрузка занятий...</div>';
    
    // Загружаем оба типа занятий
    const [myLessons, taughtLessons] = await Promise.all([
        loadMyLessons(),
        loadMyTaughtLessons()
    ]);

    lessonsContent.innerHTML = '';

    // Объединяем все занятия в один массив
    const allLessons = [];

    // Добавляем занятия, где пользователь - ученик
    myLessons.forEach(lesson => {
        allLessons.push({
            ...lesson,
            role: 'student',
            displayText: `Преподаватель: ${lesson.teacher}`
        });
    });

    // Добавляем занятия, где пользователь - учитель
    taughtLessons.forEach(lesson => {
        allLessons.push({
            ...lesson,
            role: 'teacher',
            displayText: `Ученик: ${lesson.student || 'Неизвестно'}`
        });
    });

    // Сортируем по дате (самые новые сверху)
    allLessons.sort((a, b) => {
        return new Date(b.date) - new Date(a.date);
    });

    if (allLessons.length === 0) {
        lessonsContent.innerHTML = `
            <div class="empty-lessons">
                <p>У вас пока нет занятий</p>
                <p style="font-size: 14px; color: #999; margin-top: 8px;">
                    Купите навык в каталоге или продайте свой, чтобы они появились здесь
                </p>
            </div>
        `;
        return;
    }

    // Отображаем все занятия
    allLessons.forEach(lesson => {
        lessonsContent.appendChild(createLessonCard(lesson));
    });

    console.log(`✅ Отображено занятий: ${allLessons.length} (ученик: ${myLessons.length}, учитель: ${taughtLessons.length})`);
}

// Функция создания карточки занятия
function createLessonCard(lesson) {
    const statusClass = `status-${lesson.status}`;
    const lessonCard = document.createElement('div');
    lessonCard.className = 'lesson-card';
    lessonCard.dataset.lessonId = lesson.id;
    lessonCard.dataset.vacancyId = lesson.vacancy_id;
    lessonCard.dataset.role = lesson.role;
    
    // Определяем, с кем занятие
    let personInfo = '';
    if (lesson.role === 'student') {
        personInfo = `Преподаватель: <strong>${escapeHtml(lesson.teacher)}</strong>`;
    } else {
        personInfo = `Ученик: <strong>${escapeHtml(lesson.student || 'Неизвестно')}</strong>`;
    }
    
    // Инициалы для аватара
    const initials = lesson.role === 'student' ? lesson.teacherInitials : (lesson.studentInitials || '?');
    
    const lessonAction = (lesson.status === 'planned' || lesson.status === 'completed')
        ? `<a href="lesson.html?lesson=${lesson.id}&role=${lesson.role}" class="btn-go-to-lesson">Перейти к занятию</a>`
        : `<span class="btn-go-to-lesson btn-go-to-lesson-disabled">${lesson.status === 'pending' ? 'Ожидает подтверждения' : 'Недоступно'}</span>`;

    lessonCard.innerHTML = `
        <div class="lesson-card-header">
            <div>
                <h3 class="lesson-card-title">${escapeHtml(lesson.title)}</h3>
                <span class="lesson-card-subject">${escapeHtml(lesson.subject)}</span>
                <span class="lesson-card-role-badge ${lesson.role === 'student' ? 'role-student' : 'role-teacher'}">
                    ${lesson.role === 'student' ? '👨‍🎓 Учусь' : '👨‍🏫 Учу'}
                </span>
            </div>
            <span class="lesson-card-status ${statusClass}">${lesson.statusText}</span>
        </div>
        
        <div class="lesson-card-teacher">
            ${personInfo}
        </div>
        
        <p class="lesson-card-description">${escapeHtml(lesson.description)}</p>
        
        <div class="lesson-card-footer">
            <div>
                <div style="font-size: 12px; color: #666;">${lesson.date}</div>
                <div style="font-size: 14px; font-weight: 600; color: #7c3aed;">${lesson.price} XP</div>
            </div>
            ${lessonAction}
        </div>
    `;
    
    return lessonCard;
}

// Функция для фильтрации занятий по статусу
async function filterLessonsByStatus(filter) {
    const lessonsContent = document.querySelector('.lessons-content');
    if (!lessonsContent) return;
    
    lessonsContent.innerHTML = '<div class="empty-lessons">Загрузка...</div>';
    
    const [myLessons, taughtLessons] = await Promise.all([
        loadMyLessons(),
        loadMyTaughtLessons()
    ]);
    
    lessonsContent.innerHTML = '';
    
    const allLessons = [];
    
    // Фильтруем занятия ученика
    myLessons.forEach(lesson => {
        if (filter === 'Все' || lesson.statusText === filter || 
            (filter === 'Запланированные' && lesson.status === 'planned') ||
            (filter === 'Завершенные' && lesson.status === 'completed') ||
            (filter === 'Отмененные' && lesson.status === 'cancelled')) {
            allLessons.push({
                ...lesson,
                role: 'student',
                displayText: `Преподаватель: ${lesson.teacher}`
            });
        }
    });
    
    // Фильтруем занятия учителя
    taughtLessons.forEach(lesson => {
        if (filter === 'Все' || lesson.statusText === filter ||
            (filter === 'Запланированные' && lesson.status === 'planned') ||
            (filter === 'Завершенные' && lesson.status === 'completed') ||
            (filter === 'Отмененные' && lesson.status === 'cancelled')) {
            allLessons.push({
                ...lesson,
                role: 'teacher',
                displayText: `Ученик: ${lesson.student || 'Неизвестно'}`
            });
        }
    });
    
    // Сортируем по дате
    allLessons.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    if (allLessons.length === 0) {
        lessonsContent.innerHTML = `
            <div class="empty-lessons">
                <p>${getEmptyMessage(filter)}</p>
            </div>
        `;
        return;
    }
    
    allLessons.forEach(lesson => {
        lessonsContent.appendChild(createLessonCard(lesson));
    });
}

function getEmptyMessage(filter) {
    switch(filter) {
        case 'Запланированные':
            return 'У вас нет запланированных занятий';
        case 'Завершенные':
            return 'У вас нет завершенных занятий';
        case 'Отмененные':
            return 'У вас нет отмененных занятий';
        default:
            return 'У вас пока нет занятий';
    }
}

// Функция для загрузки деталей конкретного занятия
async function loadLessonDetails() {
    
    console.log('🔥 loadLessonDetails ВЫЗВАНА!');
    console.log('window.location:', window.location.href);
    console.log('search params:', window.location.search);
    
    const urlParams = new URLSearchParams(window.location.search);
    const purchaseId = urlParams.get('lesson');
    const role = urlParams.get('role') || 'student';
    
    console.log('📊 Параметры:', { purchaseId, role });
    
    if (!purchaseId) {
        console.error('❌ НЕТ ID ЗАНЯТИЯ!');
        return;
    }
    
    const token = localStorage.getItem('access_token');
    if (!token) {
        alert('Необходимо авторизоваться');
        window.location.href = '/';
        return;
    }
    
    try {
        console.log('📤 Запрос данных с сервера...');
        const [myLessons, taughtLessons] = await Promise.all([
            loadMyLessons(),
            loadMyTaughtLessons()
        ]);
        
        console.log('📦 Получены данные:', {
            myLessons: myLessons.length,
            taughtLessons: taughtLessons.length,
            myLessonsData: myLessons,
            taughtLessonsData: taughtLessons
        });
        
        let lesson = null;
        if (role === 'student') {
            lesson = myLessons.find(l => l.id === parseInt(purchaseId));
            console.log('🔍 Ищем в ученических занятиях, найдено:', lesson);
        } else {
            lesson = taughtLessons.find(l => l.id === parseInt(purchaseId));
            console.log('🔍 Ищем в учительских занятиях, найдено:', lesson);
        }
        
        if (!lesson) {
            console.error('❌ Занятие не найдено!');
            console.log('Доступные ID ученика:', myLessons.map(l => l.id));
            console.log('Доступные ID учителя:', taughtLessons.map(l => l.id));
            alert('Занятие не найдено');
            return;
        }
        
        console.log('✅ Занятие найдено:', lesson);
        
        // Обновляем заголовок страницы
        document.title = `${lesson.title} - SkillSwap`;
        
        // Заполняем данные на странице
        updateLessonPage(lesson, role);
        
    } catch (error) {
        console.error('❌ Ошибка загрузки деталей занятия:', error);
    }
}

function updateLessonPage(lesson, role) {
    console.log('📝 Обновление страницы занятия:', lesson);
    console.log('👤 Роль:', role);
    
    // Получаем элементы по ID из вашего HTML
    const lessonTitle = document.querySelector('.lesson-title');
    const statusBadge = document.querySelector('.lesson-status-badge');
    const lessonSubject = document.getElementById('lesson-subject');
    const teacherValue = document.getElementById('teacher-value');
    const studentValue = document.getElementById('student-value');
    const teacherLabel = document.getElementById('teacher-label');
    const studentLabel = document.getElementById('student-label');
    const lessonDate = document.getElementById('lesson-date');
    const lessonDuration = document.getElementById('lesson-duration');
    const lessonFormat = document.getElementById('lesson-format');
    const lessonPrice = document.getElementById('lesson-price');
    const lessonDescription = document.querySelector('.lesson-description');
    const teacherName = document.querySelector('.teacher-name');
    const teacherAvatar = document.querySelector('.teacher-avatar');
    const teacherRating = document.querySelector('.teacher-rating');
    const teacherLessons = document.querySelector('.teacher-lessons');
    const sidebarTitle = document.querySelector('.sidebar-title');
    const backLink = document.querySelector('.back-link');
    
    if (backLink) {
        backLink.href = '/profile.html';
    }
    
    // Обновляем заголовок
    if (lessonTitle) {
        lessonTitle.textContent = lesson.title || 'Занятие';
    }
    
    // Обновляем статус
    if (statusBadge) {
        statusBadge.textContent = lesson.statusText || 'Запланировано';
        statusBadge.className = `lesson-status-badge status-${lesson.status || 'planned'}`;
    }
    
    // Обновляем предмет
    if (lessonSubject) {
        lessonSubject.textContent = lesson.subject || 'Не указан';
    }
    
    // 🔥 ИСПРАВЛЕНО: Правильное отображение для учителя
    if (role === 'student') {
        // Я ученик - показываем преподавателя
        if (teacherLabel) teacherLabel.textContent = 'Преподаватель:';
        if (teacherValue) teacherValue.textContent = lesson.teacher || 'Неизвестно';
        if (studentLabel) studentLabel.textContent = 'Ученик:';
        if (studentValue) studentValue.textContent = 'Вы';
        if (sidebarTitle) sidebarTitle.textContent = 'Преподаватель';
    } else {
        // Я учитель - показываем, что Я преподаватель, а ученик - другой человек
        if (teacherLabel) teacherLabel.textContent = 'Вы:';
        if (teacherValue) teacherValue.textContent = 'Преподаватель'; // Здесь должно быть "Преподаватель", а не имя
        if (studentLabel) studentLabel.textContent = 'Ученик:';
        if (studentValue) studentValue.textContent = lesson.student || 'Неизвестно'; // Здесь имя ученика
        if (sidebarTitle) sidebarTitle.textContent = 'Ученик';
    }
    
    // Обновляем дату
    if (lessonDate) {
        lessonDate.textContent = lesson.date || 'Не назначена';
    }
    
    // Обновляем длительность
    if (lessonDuration) {
        lessonDuration.textContent = '60 минут';
    }
    
    // Обновляем формат
    if (lessonFormat) {
        lessonFormat.textContent = lesson.format || 'Онлайн';
    }
    
    // Обновляем цену
    if (lessonPrice) {
        lessonPrice.textContent = `${lesson.price || 0} XP`;
    }
    
    // Обновляем описание
    if (lessonDescription) {
        lessonDescription.textContent = lesson.description || 'Описание отсутствует';
    }
    
    // 🔥 ИСПРАВЛЕНО: Карточка в сайдбаре
    if (teacherName) {
        if (role === 'student') {
            teacherName.textContent = lesson.teacher || 'Преподаватель';
        } else {
            teacherName.textContent = lesson.student || 'Ученик'; // Показываем имя ученика
        }
    }
    
    if (teacherAvatar) {
        if (role === 'student') {
            teacherAvatar.textContent = lesson.teacherInitials || 
                (lesson.teacher ? lesson.teacher.substring(0, 2).toUpperCase() : 'П');
        } else {
            teacherAvatar.textContent = lesson.studentInitials || 
                (lesson.student ? lesson.student.substring(0, 2).toUpperCase() : 'У');
        }
    }
    
    if (teacherRating) {
        teacherRating.textContent = `Рейтинг: ★★★★☆ (${lesson.rating || 4.8})`;
    }
    
    if (teacherLessons) {
        teacherLessons.textContent = `Проведено занятий: ${lesson.lessonsCount || 0}`;
    }
    
    // Настраиваем кнопки
    const joinBtn = document.getElementById('joinLessonBtn');
    const cancelBtn = document.getElementById('cancelLessonBtn');
    const rescheduleBtn = document.getElementById('rescheduleBtn');
    const contactTeacherBtn = document.getElementById('contactTeacherBtn');
    
    if (lesson.status === 'pending') {
        if (joinBtn) {
            joinBtn.textContent = 'Ожидает подтверждения';
            joinBtn.disabled = true;
        }
        if (cancelBtn) cancelBtn.style.display = 'none';
        if (rescheduleBtn) rescheduleBtn.style.display = 'none';
    } else if (lesson.status === 'completed' || lesson.status === 'cancelled') {
        if (joinBtn) {
            joinBtn.textContent = lesson.status === 'completed' ? 'Занятие завершено' : 'Занятие отменено';
            joinBtn.disabled = true;
        }
        if (cancelBtn) cancelBtn.style.display = 'none';
        if (rescheduleBtn) rescheduleBtn.style.display = 'none';
    } else {
        if (joinBtn) {
            joinBtn.textContent = 'Присоединиться к занятию';
            joinBtn.disabled = false;
        }
        if (cancelBtn) {
            cancelBtn.style.display = 'block';
        }
        if (rescheduleBtn) {
            rescheduleBtn.style.display = 'block';
        }
    }
    
    if (contactTeacherBtn) {
        contactTeacherBtn.textContent = role === 'student' ? 'Написать преподавателю' : 'Написать ученику';
        contactTeacherBtn.style.display = (lesson.status === 'planned' || lesson.status === 'completed') ? 'block' : 'none';
    }
    
    console.log('✅ Страница занятия обновлена');
}

// Инициализация фильтров
function initLessonFilters() {
    const filterButtons = document.querySelectorAll('.lessons-filters .filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.textContent;
            
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            filterLessonsByStatus(filter);
        });
    });
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Функция для тестирования эндпоинта учителя
async function testTeacherLessons() {
    console.log('🧪 Тестирование эндпоинта учителя...');
    const token = localStorage.getItem('access_token');
    
    try {
        const response = await fetch('http://localhost:8000/api/purchases/my-taught-lessons', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        console.log('📊 Статус ответа:', response.status);
        
        if (response.ok) {
            const data = await response.json();
            console.log('📦 Данные с сервера:', data);
            
            if (data.length === 0) {
                console.log('ℹ️ У учителя пока нет купленных занятий');
            } else {
                console.log(`✅ Найдено ${data.length} занятий:`);
                data.forEach(lesson => {
                    console.log(`   - ${lesson.title} (ученик: ${lesson.student})`);
                });
            }
        } else {
            console.error('❌ Ошибка:', await response.text());
        }
    } catch (error) {
        console.error('❌ Ошибка соединения:', error);
    }
}

// Функция для обновления XP пользователя
async function updateUserXP() {
    const token = localStorage.getItem('access_token');
    if (!token) return;
    
    try {
        const response = await fetch('http://localhost:8000/api/xp/check-daily', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            
            // Обновляем отображение XP везде, где оно есть
            const pointsElements = document.querySelectorAll('.points, .points-value');
            pointsElements.forEach(el => {
                if (el.classList.contains('points')) {
                    el.textContent = `${data.points} XP`;
                } else if (el.classList.contains('points-value')) {
                    el.textContent = data.points;
                }
            });
            
            return data;
        }
    } catch (error) {
        console.error('Ошибка при обновлении XP:', error);
    }
}

// Функция для покупки вакансии
async function buyVacancy(vacancyId) {
    const token = localStorage.getItem('access_token');
    
    try {
        const response = await fetch(`http://localhost:8000/api/purchases/buy/${vacancyId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('Успешно');
            
            // Обновляем XP в интерфейсе
            updateUserXP();
            
            // Если мы на странице профиля, обновляем список занятий
            if (window.location.pathname.includes('profile.html')) {
                await renderAllLessons();
            }
            
            return true;
        } else {
            alert(`❌ ${data.detail || 'Ошибка при покупке'}`);
            return false;
        }
    } catch (error) {
        console.error('🔥 Ошибка при покупке:', error);
        alert('❌ Не удалось подключиться к серверу');
        return false;
    }
}

// Инициализация обработчиков событий на странице занятия
function initEventHandlers() {
    const cancelBtn = document.getElementById('cancelLessonBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', async function() {
            if (!confirm('Вы уверены, что хотите отменить это занятие?')) return;
            
            const urlParams = new URLSearchParams(window.location.search);
            const purchaseId = urlParams.get('lesson');
            const token = localStorage.getItem('access_token');
            
            try {
                const response = await fetch(`http://localhost:8000/api/purchases/lesson/${purchaseId}/status?status=cancelled`, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
                
                if (response.ok) {
                    alert('Занятие отменено');
                    window.location.reload();
                } else {
                    alert('Ошибка при отмене занятия');
                }
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Не удалось подключиться к серверу');
            }
        });
    }
    
    const saveNotesBtn = document.querySelector('.btn-save-notes');
    if (saveNotesBtn) {
        saveNotesBtn.addEventListener('click', function() {
            const textarea = document.querySelector('.notes-textarea');
            if (textarea && textarea.value.trim()) {
                localStorage.setItem(`lesson_notes_${new URLSearchParams(window.location.search).get('lesson')}`, textarea.value);
                alert('Заметки сохранены');
            }
        });
        
        // Загружаем сохраненные заметки
        const textarea = document.querySelector('.notes-textarea');
        if (textarea) {
            const savedNotes = localStorage.getItem(`lesson_notes_${new URLSearchParams(window.location.search).get('lesson')}`);
            if (savedNotes) {
                textarea.value = savedNotes;
            }
        }
    }

    const joinBtn = document.getElementById('joinLessonBtn');
    if (joinBtn) {
        joinBtn.addEventListener('click', () => {
            if (joinBtn.disabled) return;
            const urlParams = new URLSearchParams(window.location.search);
            const purchaseId = urlParams.get('lesson');
            const role = urlParams.get('role') || 'student';
            if (!purchaseId) return;
            window.location.href = `/chat.html?lesson=${encodeURIComponent(purchaseId)}&role=${encodeURIComponent(role)}`;
        });
    }

    const contactTeacherBtn = document.getElementById('contactTeacherBtn');
    if (contactTeacherBtn) {
        contactTeacherBtn.addEventListener('click', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const purchaseId = urlParams.get('lesson');
            const role = urlParams.get('role') || 'student';
            if (!purchaseId) return;
            window.location.href = `/chat.html?lesson=${encodeURIComponent(purchaseId)}&role=${encodeURIComponent(role)}`;
        });
    }
}

// Запускаем при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('lesson.html') && window.location.search) {
        console.log('📄 Загружена страница занятия');
        loadLessonDetails();
        initEventHandlers();
    } else if (window.location.pathname.includes('profile.html')) {
        console.log('📄 Загружена страница профиля');
        // Небольшая задержка, чтобы убедиться, что все загрузилось
        setTimeout(() => {
            renderAllLessons();
            initLessonFilters();
            testTeacherLessons(); // Для отладки
        }, 500);
    }
});

export { 
    loadMyLessons, 
    loadMyTaughtLessons, 
    renderAllLessons, 
    buyVacancy,
    updateUserXP,
    initLessonFilters  
};
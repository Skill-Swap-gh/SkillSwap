import { openPurchaseModal } from "./modal-purchase.js";

const IMAGE_BY_KEYWORDS = [
    { keywords: ['алгебр'], file: 'algebra.png' },
    { keywords: ['геометр'], file: 'geometry.png' },
    { keywords: ['физик'], file: 'fizika.png' },
    { keywords: ['хим'], file: 'himiya.png' },
    { keywords: ['биолог'], file: 'biologiya.png' },
    { keywords: ['англий'], file: 'english.png' },
    { keywords: ['русск'], file: 'russian.png' },
    { keywords: ['литератур'], file: 'literature.png' },
    { keywords: ['истор'], file: 'history.png' },
    { keywords: ['географ'], file: 'geography.png' },
    { keywords: ['обществ'], file: 'obshestvo.png' },
    { keywords: ['музык'], file: 'music.png' },
    { keywords: ['рисован'], file: 'risovanie.png' },
    { keywords: ['шахмат'], file: 'chess.png' },
    { keywords: ['эконом'], file: 'economy.png' },
    { keywords: ['информат'], file: 'informatics.png' },
    { keywords: ['python'], file: 'python.png' },
    { keywords: ['javascript'], file: 'javascript.png' },
    { keywords: ['html', 'css'], file: 'htmlcss.png' },
    { keywords: ['программ', 'web-разработ', 'frontend', 'backend'], file: 'programming.png' },
];

const FILTER_KEYWORDS = {
    'Все': [],
    'Программирование': ['программ', 'python', 'javascript', 'html', 'css', 'web-разработ', 'frontend', 'backend'],
    'Python': ['python'],
    'JavaScript': ['javascript'],
    'HTML/CSS': ['html', 'css'],
    'Алгебра': ['алгебр'],
    'Геометрия': ['геометр'],
    'Физика': ['физик'],
    'Химия': ['хим'],
    'Биология': ['биолог'],
    'Русский язык': ['русск'],
    'Литература': ['литератур'],
    'История': ['истор'],
    'География': ['географ'],
    'Обществознание': ['обществ'],
    'Английский язык': ['англий'],
    'Музыка': ['музык'],
    'Рисование': ['рисован'],
    'Шахматы': ['шахмат'],
    'Экономика': ['эконом'],
    'Информатика': ['информат'],
    'Математика': ['математ', 'алгебр', 'геометр'],
};

let catalogVacancies = [];
let activeFilter = 'Все';
let searchQuery = '';

document.addEventListener('DOMContentLoaded', async function() {
    initFilters();
    initSearch();
    await loadPurchaseModal();
    await loadCatalogVacancies();
});

function normalizeText(value) {
    return (value || '').toString().toLowerCase().replace(/ё/g, 'е');
}

function getVacancyImage(vacancy) {
    const text = normalizeText([vacancy.title, vacancy.description, vacancy.author?.username].filter(Boolean).join(' '));
    const match = IMAGE_BY_KEYWORDS.find(item => item.keywords.some(keyword => text.includes(keyword)));
    return match ? match.file : 'foto.png';
}

function matchesFilter(vacancy) {
    if (activeFilter === 'Все') return true;
    const keywords = FILTER_KEYWORDS[activeFilter] || [normalizeText(activeFilter)];
    const text = normalizeText([vacancy.title, vacancy.description, vacancy.author?.username].filter(Boolean).join(' '));
    return keywords.some(keyword => text.includes(normalizeText(keyword)));
}

function matchesSearch(vacancy) {
    if (!searchQuery.trim()) return true;
    const text = normalizeText([vacancy.title, vacancy.description, vacancy.author?.username, vacancy.formatl].filter(Boolean).join(' '));
    return text.includes(normalizeText(searchQuery));
}

function getFilteredVacancies() {
    return catalogVacancies.filter(vacancy => matchesFilter(vacancy) && matchesSearch(vacancy));
}

function renderVacancies() {
    const container = document.getElementById('empty-state-vacancies');
    if (!container) return;

    const filtered = getFilteredVacancies();
    container.innerHTML = '';

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-icon"></div>
            <p class="empty-state-text">По выбранным фильтрам ничего не найдено</p>
        `;
        return;
    }

    filtered.forEach(vacancy => {
        const card = document.createElement('div');
        card.className = 'item-category';
        card.dataset.vacancyId = vacancy.id;
        card.dataset.filter = vacancy.title;

        const authorName = vacancy.author?.username || 'SkillSwap';
        const imageName = getVacancyImage(vacancy);

        card.innerHTML = `
            <div class="img-item-school">
                <img src="/static/images/${imageName}" alt="${vacancy.title}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <div class="opt-item-school">
                <p class="st-p-main">${vacancy.title}</p>
                <span class="st-spam">автор: <span class="st-p-mini">${authorName}</span></span>
                <span class="st-spam">Описание: <span class="st-p-mini">${vacancy.description}</span></span>
                <span class="st-spam">Тип занятий: <span class="st-p-mini">${vacancy.formatl === 'online' ? 'Онлайн' : 'Офлайн'}</span></span>
                <span class="st-spam">Цена: <span class="st-p-mini3">${vacancy.price}</span></span>
                <button class="btn-primary btn-interested" data-vacancy-id="${vacancy.id}">Интересно</button>
                <button class="btn-primary btn-buy-catalog" data-vacancy-id="${vacancy.id}">Купить</button>
            </div>`;

        const btnInterested = card.querySelector('.btn-interested');
        if (btnInterested) {
            btnInterested.addEventListener('click', function() {
                openPurchaseModal({
                    vacancyId: vacancy.id,
                    title: vacancy.title,
                    description: vacancy.description,
                    format: vacancy.formatl,
                    price: vacancy.price
                });
            });
        }

        const buyBtn = card.querySelector('.btn-buy-catalog');
        if (buyBtn) {
            buyBtn.addEventListener('click', async function() {
                const vacancyId = this.dataset.vacancyId;
                const token = localStorage.getItem('access_token');

                if (!token) {
                    alert('❌ Необходимо авторизоваться');
                    const authModal3 = document.getElementById('authModal3');
                    if (authModal3) authModal3.style.display = 'block';
                    return;
                }

                try {
                    const response = await fetch(`/api/purchases/buy/${vacancyId}`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        }
                    });

                    const data = await response.json();

                    if (response.ok) {
                        alert('Успешно');
                        const pointsElements = document.querySelectorAll('.points, .points-value');
                        pointsElements.forEach(el => {
                            if (el.classList.contains('points')) {
                                el.textContent = `${data.remaining_points} XP`;
                            } else if (el.classList.contains('points-value')) {
                                el.textContent = data.remaining_points;
                            }
                        });
                    } else {
                        alert(`❌ Ошибка: ${data.detail || 'Неизвестная ошибка'}`);
                    }
                } catch (error) {
                    console.error('Ошибка покупки:', error);
                    alert('❌ Не удалось подключиться к серверу');
                }
            });
        }

        container.appendChild(card);
    });
}

function initFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(button => button.classList.remove('active-filter'));
            this.classList.add('active-filter');
            activeFilter = this.dataset.filter || this.textContent.trim();
            renderVacancies();
        });
    });
}

function initSearch() {
    const searchInput = document.querySelector('.search-input');
    if (!searchInput) return;

    searchInput.addEventListener('input', function() {
        searchQuery = this.value;
        renderVacancies();
    });
}

async function loadCatalogVacancies() {
    try {
        const response = await fetch('/api/vacancies/catalog_cards', { method: 'GET' });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        catalogVacancies = await response.json();
        renderVacancies();
    } catch (error) {
        console.error('Ошибка запроса /catalog_cards:', error);
        const container = document.getElementById('empty-state-vacancies');
        if (container) {
            container.innerHTML = '<p class="empty-state-text">Не удалось загрузить каталог</p>';
        }
    }
}

async function loadPurchaseModal() {
    try {
        const response = await fetch('/modal-purchase.html');
        const data = await response.text();

        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = data;
        document.body.appendChild(modalContainer);
    } catch (error) {
        console.error('Ошибка загрузки модального окна:', error);
    }
}

import { profile_activate } from '/static/scripts.js';

const apiBase = '';
let currentContext = null;
let currentMessages = [];
let selectedFiles = [];
let refreshTimer = null;

function getToken() {
    return localStorage.getItem('access_token');
}

async function apiFetch(url, options = {}) {
    const token = getToken();
    if (!token) {
        window.location.href = '/';
        throw new Error('No token');
    }

    const headers = options.headers ? { ...options.headers } : {};
    if (!(options.body instanceof FormData)) {
        headers['Content-Type'] = headers['Content-Type'] || 'application/json';
    }
    headers['Authorization'] = `Bearer ${token}`;

    const response = await fetch(url, { ...options, headers });
    if (response.status === 401) {
        window.location.href = '/';
        throw new Error('Unauthorized');
    }
    return response;
}

function escapeHtml(text = '') {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatTime(isoString) {
    try {
        return new Intl.DateTimeFormat('ru-RU', {
            hour: '2-digit',
            minute: '2-digit',
        }).format(new Date(isoString));
    } catch {
        return '';
    }
}

function formatDateLabel(isoString) {
    try {
        return new Intl.DateTimeFormat('ru-RU', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
        }).format(new Date(isoString));
    } catch {
        return 'Сегодня';
    }
}

function fileIconByType(kind, mimeType = '', name = '') {
    if (kind === 'image' || mimeType.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(name)) return '🖼️';
    if (/pdf$/i.test(name) || mimeType === 'application/pdf') return '📕';
    if (/docx?$/i.test(name) || mimeType.includes('word')) return '📘';
    return '📎';
}

function isImageAttachment(attachment) {
    return attachment.file_kind === 'image' || attachment.mime_type.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(attachment.file_name);
}

function renderAttachmentsPreview() {
    const preview = document.getElementById('attachmentsPreview');
    if (!preview) return;

    preview.innerHTML = '';
    selectedFiles.forEach((file, index) => {
        const item = document.createElement('div');
        item.className = 'attachment-preview-item';

        if (file.type.startsWith('image/')) {
            const img = document.createElement('img');
            img.className = 'preview-image';
            img.alt = file.name;
            img.src = URL.createObjectURL(file);
            item.appendChild(img);
        } else {
            const wrapper = document.createElement('div');
            wrapper.className = 'preview-file';
            wrapper.innerHTML = `
                <div class="file-preview-icon">${fileIconByType('', file.type, file.name)}</div>
                <div class="file-preview-name">${escapeHtml(file.name)}</div>
            `;
            item.appendChild(wrapper);
        }

        const removeBtn = document.createElement('button');
        removeBtn.className = 'btn-remove-attachment';
        removeBtn.type = 'button';
        removeBtn.textContent = '×';
        removeBtn.addEventListener('click', () => {
            selectedFiles.splice(index, 1);
            renderAttachmentsPreview();
        });
        item.appendChild(removeBtn);

        preview.appendChild(item);
    });
}

function renderDateSeparator(label) {
    const el = document.createElement('div');
    el.className = 'message-date';
    el.innerHTML = `<span>${escapeHtml(label)}</span>`;
    return el;
}

function createAttachmentNode(attachment) {
    const wrap = document.createElement('div');
    wrap.className = 'message-attachment';

    if (isImageAttachment(attachment)) {
        wrap.innerHTML = `<a href="${attachment.file_url}" target="_blank" rel="noopener"><img class="attachment-image" src="${attachment.file_url}" alt="${escapeHtml(attachment.file_name)}"></a>`;
        return wrap;
    }

    wrap.innerHTML = `
        <a class="attachment-file" href="${attachment.file_url}" target="_blank" rel="noopener">
            <span class="file-icon">${fileIconByType(attachment.file_kind, attachment.mime_type, attachment.file_name)}</span>
            <span class="file-info">
                <div class="file-name">${escapeHtml(attachment.file_name)}</div>
                <div class="file-size">${(attachment.file_size / (1024 * 1024)).toFixed(1)} МБ</div>
            </span>
        </a>
    `;
    return wrap;
}

function renderMessages(messages = []) {
    const list = document.getElementById('messagesList');
    if (!list) return;

    list.innerHTML = '';
    let lastDate = '';

    messages.forEach((message) => {
        const messageDate = new Date(message.created_at);
        const dateLabel = formatDateLabel(message.created_at);
        if (dateLabel !== lastDate) {
            list.appendChild(renderDateSeparator(dateLabel));
            lastDate = dateLabel;
        }

        const wrapper = document.createElement('div');
        wrapper.className = `message ${message.is_current_user ? 'outgoing' : 'incoming'}`;

        const sender = document.createElement('div');
        sender.className = 'message-sender';
        sender.textContent = message.is_current_user ? 'Вы' : message.sender_name;

        const content = document.createElement('div');
        content.className = 'message-content';

        if (message.text) {
            const text = document.createElement('div');
            text.className = 'message-text';
            text.textContent = message.text;
            content.appendChild(text);
        }

        if (message.attachments && message.attachments.length) {
            const attachments = document.createElement('div');
            attachments.className = 'message-attachments';
            message.attachments.forEach((attachment) => attachments.appendChild(createAttachmentNode(attachment)));
            content.appendChild(attachments);
        }

        const meta = document.createElement('div');
        meta.className = 'message-meta';
        meta.innerHTML = `<span class="message-time">${formatTime(message.created_at)}</span>`;
        content.appendChild(meta);

        wrapper.appendChild(sender);
        wrapper.appendChild(content);
        list.appendChild(wrapper);
    });

    const container = document.getElementById('messagesContainer');
    if (container) {
        container.scrollTop = container.scrollHeight;
    }
}

function updateSidebar(context) {
    const title = document.getElementById('lessonTitle');
    const status = document.getElementById('lessonStatus');
    const peer = document.getElementById('lessonPeer');
    const peerLabel = document.getElementById('peerLabel');
    const date = document.getElementById('lessonDate');
    const price = document.getElementById('lessonPrice');
    const chatTitle = document.getElementById('chatTitle');
    const chatSubtitle = document.getElementById('chatSubtitle');

    const lesson = context.lesson;
    if (title) title.textContent = lesson.title || 'Занятие';
    if (status) {
        status.textContent = lesson.statusText || 'Запланировано';
        status.className = `lesson-status status-${lesson.status || 'planned'}`;
    }
    if (peer) peer.textContent = context.peer.username;
    if (peerLabel) peerLabel.textContent = context.role === 'student' ? 'С кем:' : 'С кем:';
    if (date) date.textContent = lesson.date || 'Не назначена';
    if (price) price.textContent = `${lesson.price || 0} XP`;
    if (chatTitle) chatTitle.textContent = `Чат: ${lesson.title || 'Занятие'}`;
    if (chatSubtitle) chatSubtitle.textContent = context.role === 'student' ? `С ${context.peer.username}` : `С ${context.peer.username}`;
}

async function loadChat() {
    const urlParams = new URLSearchParams(window.location.search);
    const purchaseId = urlParams.get('lesson');
    if (!purchaseId) {
        window.location.href = '/profile.html';
        return;
    }

    const response = await apiFetch(`/api/chats/${purchaseId}/messages`);
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.detail || 'Не удалось загрузить чат');
    }

    const data = await response.json();
    currentContext = data.context;
    currentMessages = data.messages || [];
    updateSidebar(currentContext);
    renderMessages(currentMessages);

    const cancelBtn = document.getElementById('btnCancelLesson');
    if (cancelBtn) {
        cancelBtn.style.display = currentContext.can_write ? 'inline-flex' : 'none';
    }
}

async function refreshMessages(silent = true) {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const purchaseId = urlParams.get('lesson');
        if (!purchaseId) return;
        const response = await apiFetch(`/api/chats/${purchaseId}/messages`);
        if (!response.ok) return;
        const data = await response.json();
        currentContext = data.context;
        currentMessages = data.messages || [];
        updateSidebar(currentContext);
        renderMessages(currentMessages);
    } catch (error) {
        if (!silent) console.error(error);
    }
}

function resetComposer() {
    selectedFiles = [];
    const input = document.getElementById('messageInput');
    if (input) input.value = '';
    renderAttachmentsPreview();
}

async function sendMessage() {
    const input = document.getElementById('messageInput');
    const text = (input?.value || '').trim();
    const urlParams = new URLSearchParams(window.location.search);
    const purchaseId = urlParams.get('lesson');
    if (!purchaseId) return;
    if (!text && selectedFiles.length === 0) return;

    const formData = new FormData();
    formData.append('text', text);
    selectedFiles.forEach((file) => formData.append('files', file));

    const sendBtn = document.getElementById('btnSend');
    if (sendBtn) sendBtn.disabled = true;

    try {
        const response = await apiFetch(`/api/chats/${purchaseId}/messages`, {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.detail || 'Не удалось отправить сообщение');
        }

        currentMessages.push(data.message);
        renderMessages(currentMessages);
        resetComposer();
    } catch (error) {
        alert(error.message || 'Не удалось отправить сообщение');
    } finally {
        if (sendBtn) sendBtn.disabled = false;
    }
}

function initComposer() {
    const fileInput = document.getElementById('fileInput');
    const btnAttach = document.getElementById('btnAttach');
    const btnSend = document.getElementById('btnSend');
    const messageInput = document.getElementById('messageInput');
    const attachModal = document.getElementById('attachModal');

    if (btnAttach && fileInput) {
        btnAttach.addEventListener('click', () => fileInput.click());
    }

    if (fileInput) {
        fileInput.addEventListener('change', () => {
            const files = Array.from(fileInput.files || []);
            const nextFiles = [...selectedFiles, ...files].slice(0, 10);
            const tooLarge = nextFiles.find((file) => file.size > 15 * 1024 * 1024);
            if (tooLarge) {
                alert(`Файл ${tooLarge.name} превышает 15 МБ`);
                fileInput.value = '';
                return;
            }
            selectedFiles = nextFiles;
            fileInput.value = '';
            renderAttachmentsPreview();
        });
    }

    if (btnSend) btnSend.addEventListener('click', sendMessage);

    if (messageInput) {
        messageInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        });

        messageInput.addEventListener('input', () => {
            messageInput.style.height = 'auto';
            messageInput.style.height = `${Math.min(messageInput.scrollHeight, 120)}px`;
        });
    }

    if (attachModal) {
        attachModal.querySelectorAll('[data-close-modal]').forEach((btn) => {
            btn.addEventListener('click', () => {
                attachModal.style.display = 'none';
            });
        });

        attachModal.addEventListener('click', (event) => {
            if (event.target === attachModal) {
                attachModal.style.display = 'none';
            }
        });

        attachModal.querySelectorAll('.attach-option').forEach((btn) => {
            btn.addEventListener('click', () => {
                fileInput?.click();
                attachModal.style.display = 'none';
            });
        });
    }
}

function initSidebarButtons() {
    const detailsBtn = document.getElementById('btnDetails');
    const cancelBtn = document.getElementById('btnCancelLesson');

    if (detailsBtn) {
        detailsBtn.addEventListener('click', () => {
            if (currentContext?.lesson) {
                const lesson = currentContext.lesson;
                alert(`
${lesson.title}

${lesson.description}

Статус: ${lesson.statusText}
Дата: ${lesson.date}
Стоимость: ${lesson.price} XP`);
            }
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', async () => {
            const lesson = currentContext?.lesson;
            if (!lesson || lesson.status === 'cancelled') return;
            if (!confirm('Отменить занятие?')) return;

            const token = getToken();
            const response = await fetch(`/api/purchases/lesson/${lesson.id}/status?status=cancelled`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            });
            if (response.ok) {
                await refreshMessages(false);
                alert('Занятие отменено');
            } else {
                const data = await response.json().catch(() => ({}));
                alert(data.detail || 'Не удалось отменить занятие');
            }
        });
    }
}

async function initChatPage() {
    await profile_activate();
    await loadChat();
    initComposer();
    initSidebarButtons();

    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(() => refreshMessages(true), 4000);

    const container = document.getElementById('messagesContainer');
    if (container) {
        container.addEventListener('scroll', () => {
            const nearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 120;
            container.dataset.nearBottom = String(nearBottom);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initChatPage().catch((error) => {
        console.error(error);
        alert(error.message || 'Не удалось загрузить чат');
    });
});

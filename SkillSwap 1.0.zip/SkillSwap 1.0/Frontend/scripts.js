
function isUserLoggedIn() {
    const token = localStorage.getItem('access_token');
    if (!token) {
        return false;
    }
    
    try {
        const payload = parseJwt(token);

        if (!payload) {
            console.log('Невалидный токен (payload is null)');
            localStorage.removeItem('access_token');
            return false;
        }

        if (!payload.exp) {
            console.log('Токен без поля exp');
            return false;
        }

        const currentTime = Math.floor(Date.now() / 1000);
        
        if (payload.exp < currentTime) {
            localStorage.removeItem('access_token');
            return false;
        }
        
        return true

    } catch (error) {
        console.error('Ошибка проверки авторизации:', error);
        return false;
    }
}



export function profile_activate() {
    if (isUserLoggedIn()) {
        const HeaderActions = document.getElementById("header-actions-id");
        
        // Показываем заглушку XP, потом обновим
        HeaderActions.innerHTML = `
            <a href="/profile.html?tab=lessons" class="nav-link">Мои занятия</a>
            <span class="points">- XP</span>
            <button class="icon-btn bell-btn" id="notificationsBtn" type="button">🔔<span class="notification-badge" id="notificationsBadge" hidden>0</span></button>
            <a href="/profile.html"><button class="icon-btn profile-btn" id="profileHeaderBtn" type="button">👤</button></a>
        `;
        
        startAutomaticTokenRefresh();
        learnCards();
        teachCards();
        updateHeaderAvatar();
        
        // Обновляем XP при загрузке страницы
        updateUserXP();
        
        // Запускаем периодическую проверку XP (каждые 10 минут)
        setInterval(updateUserXP, 10 * 60 * 1000);
    } else {
        const HeaderActions = document.getElementById("header-actions-id");
        if (HeaderActions) {
            HeaderActions.innerHTML = `<button class="btn-primary" id="log-in-header-actions">Войти</button>
                    <button class="btn-primary" id = "req-in-header-actions">Зарегистрироваться</button>
                    <button class="icon-btn bell-btn" id="notificationsBtn" type="button">🔔<span class="notification-badge" id="notificationsBadge" hidden>0</span></button>`;
        }
    }
}


// Добавить после функции profile_activate

// Функция для получения и отображения XP пользователя

async function updateHeaderAvatar() {
    const token = localStorage.getItem('access_token');
    if (!token) return;

    try {
        const response = await fetch('http://localhost:8000/ProfileLoad/profile', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) return;
        const profile = await response.json();
        const profileBtn = document.getElementById('profileHeaderBtn');
        if (!profileBtn || !profile.avatar_url) return;

        profileBtn.textContent = '';
        profileBtn.style.backgroundImage = `url(${profile.avatar_url})`;
        profileBtn.style.backgroundSize = 'cover';
        profileBtn.style.backgroundPosition = 'center';
        profileBtn.style.borderRadius = '50%';
        profileBtn.style.overflow = 'hidden';
    } catch (error) {
        console.error('Ошибка загрузки аватара:', error);
    }
}

export async function updateUserXP() {
    const token = localStorage.getItem('access_token');
    if (!token) return;
    
    try {
        const response = await fetch('http://localhost:8000/api/xp/check-daily', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            
            // Обновляем отображение XP везде, где оно есть
            const pointsElements = document.querySelectorAll('.points, .points-value');
            pointsElements.forEach(el => {
                if (el.classList.contains('points')) {
                    el.textContent = `${data.points} XP`;
                } else if (el.classList.contains('points-value')) {
                    el.textContent = data.points;
                }
            });
            
            // Если XP были только что начислены, показываем уведомление
            if (data.xp_added) {
                showNotification('🎉 Вы получили 20 XP за ежедневный вход!');
            }
            
            return data;
        }
    } catch (error) {
        console.error('Ошибка при обновлении XP:', error);
    }
}

// Функция для показа уведомлений
function showNotification(message) {
    // Проверяем, есть ли уже контейнер для уведомлений
    let notificationContainer = document.querySelector('.notification-container');
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        notificationContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
        `;
        document.body.appendChild(notificationContainer);
    }
    
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        background: linear-gradient(135deg, #93aaf8 0%, #814cfc 100%);
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideIn 0.3s ease;
        cursor: pointer;
    `;
    notification.textContent = message;
    
    notificationContainer.appendChild(notification);
    
    // Удаляем уведомление через 5 секунд
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
    
    // Добавляем стили анимации, если их нет
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}




function parseJwt(token) {
    try {
        const base64 = token.split('.')[1]
            .replace(/-/g, '+')
            .replace(/_/g, '/');
        const decoded = new TextDecoder().decode(
            Uint8Array.from(atob(base64), c => c.charCodeAt(0))
        );
        return JSON.parse(decoded);
    } catch (e) {
        return null;
    }
}



function getTokenExpiration(token) {
    const payload = parseJwt(token);
    if (!payload) return null; 
    return payload.exp || null;
}

function isTokenExpired(token) {
    const exp = getTokenExpiration(token);
    if (!exp) return true;
    const currentTime = Math.floor(Date.now() / 1000);
    return exp < currentTime;
}

async function refreshAccessToken() {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (!refreshToken) {
        console.log('Refresh token отсутствует');
        return false;
    }
    if (isTokenExpired(refreshToken)) {
        console.log('Refresh token истёк - выход');
        performLogout();
        return false;
    }
    
    try {
        const response = await fetch('http://localhost:8000/auth/refresh', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ refresh_token: refreshToken })
        });
        
        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('access_token', data.access_token);
            console.log('Access token обновлён');
            return true;
        } else {
            console.error('Ошибка обновления токена:', response.status);
            performLogout();
            return false;
        }
    } catch (error) {
        console.error('Ошибка запроса /refresh:', error);
        performLogout();
        return false;
    }
}


let tokenRefreshInterval = null;
async function startAutomaticTokenRefresh() {
    tokenRefreshInterval = setInterval(async () => {
        const accessToken = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');
        
        if (!accessToken || !refreshToken) {
            console.log('Токены отсутствуют, останавливаем обновление');
            return;
        }
        if (isTokenExpired(refreshToken)) {
            console.log('Refresh token истёк — автоматический выход');
            performLogout();
            return;
        }
        const accessExp = getTokenExpiration(accessToken);
        const currentTime = Math.floor(Date.now() / 1000);
        const timeUntilExpiry = accessExp - currentTime;
        
        console.log(`До истечения токена: ${timeUntilExpiry} секунд`);
        
        if (timeUntilExpiry <= 30) {
            console.log('Access token истекает — обновление...');
            await refreshAccessToken();
        }
    }, 10000); 
}

export async function learnCards() {
    const WantLearnText = document.getElementById('want-learn')
    const learnCardsBlock = document.getElementById('learn-cards-block');

    if (!WantLearnText || !learnCardsBlock) {
        return; 
    }

    const token = localStorage.getItem('access_token');
    if (!token) {
        console.error('Токен отсутствует');
        return false;
    }

    try {
        const response = await fetch('http://localhost:8000/api/vacancies/mycards_learn', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });
        
        if (response.ok) {
            const data = await response.json();
            
            if (WantLearnText) {
                WantLearnText.style.display = "none";
            }
            
            if (learnCardsBlock) {  
                learnCardsBlock.innerHTML = '';
            
                if (data.length === 0) {
                    learnCardsBlock.innerHTML = '<p class="no-cards">У вас пока нет вакансий</p>';
                    return data;
                }
                
                for (let i = 0; i < data.length; i++) {
                    const vacancy = data[i];
                    
                    const card = document.createElement('div');
                    card.className = 'skill-card';
                    card.dataset.vacancyId = vacancy.id;
                    
                    card.innerHTML = `
                        <div class="skill-header">
                            <span class="skill-title">${escapeHtml(vacancy.title)}</span>
                            <span class="skill-price">${vacancy.price} XP</span>
                        </div>
                        <div class="skill-description">${escapeHtml(vacancy.description)}</div>
                        <div class="skill-actions">
                            <button class="btn-delete-skill" data-vacancy-id="${vacancy.id}">Удалить</button>
                        </div>
                    `;
                    
                    // Добавляем обработчик для кнопки удаления
                    const deleteBtn = card.querySelector('.btn-delete-skill');
                    deleteBtn.addEventListener('click', async function() {
                        const vacancyId = this.dataset.vacancyId;
                        await deleteVacancy(vacancyId);
                    });
                    
                    learnCardsBlock.appendChild(card);
                }
            }
            return data;
        } else {
            WantLearnText.style.display = "none";
            console.error('Ошибка вывода карточек "Хочу научиться"', response.status);
            return false;
        }
    } catch (error) {
        if (WantLearnText) {
            WantLearnText.style.display = "none"; 
        }
        console.error('Ошибка запроса /mycards_learn:', error);
        return false;
    }
}

export async function teachCards() {
    const WantTeachText = document.getElementById('want-teach')
    const TeachCardsBlock = document.getElementById('teach-cards-block');

    if (!WantTeachText || !TeachCardsBlock) {
        return; 
    }

    const token = localStorage.getItem('access_token');
    if (!token) {
        console.error('Токен отсутствует');
        return false;
    }

    try {
        const response = await fetch('http://localhost:8000/api/vacancies/mycards_teach', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });
        
        if (response.ok) {
            const data = await response.json();
            if (WantTeachText) {
                WantTeachText.style.display = "none";
            }
            
            if (TeachCardsBlock) {
                TeachCardsBlock.innerHTML = '';
                
                if (data.length === 0) {
                    TeachCardsBlock.innerHTML = '<p class="no-cards">У вас пока нет вакансий</p>';
                    return data;
                }
                
                for (let i = 0; i < data.length; i++) {
                    const vacancy = data[i];
                    
                    const card = document.createElement('div');
                    card.className = 'skill-card';
                    card.dataset.vacancyId = vacancy.id;
                    
                    card.innerHTML = `
                        <div class="skill-header">
                            <span class="skill-title">${escapeHtml(vacancy.title)}</span>
                            <span class="skill-price">${vacancy.price} XP</span>
                        </div>
                        <div class="skill-description">${escapeHtml(vacancy.description)}</div>
                        <div class="skill-actions">
                            <button class="btn-delete-skill" data-vacancy-id="${vacancy.id}">Удалить</button>
                        </div>
                    `;
                    
                    // Добавляем обработчик для кнопки удаления
                    const deleteBtn = card.querySelector('.btn-delete-skill');
                    deleteBtn.addEventListener('click', async function() {
                        const vacancyId = this.dataset.vacancyId;
                        await deleteVacancy(vacancyId);
                    });
                    
                    TeachCardsBlock.appendChild(card);
                }
            }
            return data;
        } else {
            WantTeachText.style.display = "none";
            console.error('Ошибка вывода карточек "Могу научить"', response.status);
            return false;
        }
    } catch (error) {
        if (WantTeachText) {  
            WantTeachText.style.display = "none";
        }
        console.error('Ошибка запроса /mycards_teach:', error);
        return false;
    }
}



function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}


async function stopAutomaticTokenRefresh() {
    if (tokenRefreshInterval) {
        clearInterval(tokenRefreshInterval);
        tokenRefreshInterval = null;
    }
}


async function performLogout(){
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    stopAutomaticTokenRefresh()

    const headerActions = document.getElementById("header-actions-id");
    if (headerActions) {
        headerActions.innerHTML = `<button class="btn-primary" id="log-in-header-actions">Войти</button>
                    <button class="btn-primary" id = "req-in-header-actions">Зарегистрироваться</button>
                    <button class="icon-btn bell-btn" id="notificationsBtn" type="button">🔔<span class="notification-badge" id="notificationsBadge" hidden>0</span></button>`;
    }
    
    alert('Ваша сессия истекла. Войдите снова.');
    window.location.href = '/';
    
}









// Функция для удаления вакансии
export async function deleteVacancy(vacancyId) {
    const token = localStorage.getItem('access_token');
    
    if (!token) {
        alert('Необходимо авторизоваться');
        return false;
    }
    
    if (!confirm('Вы уверены, что хотите удалить этот навык?')) {
        return false;
    }
    
    try {
        const response = await fetch(`http://localhost:8000/api/vacancies/${vacancyId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.status === 204) {
            alert('Навык успешно удален');
            await learnCards();
            await teachCards();
            return true;
        } else if (response.status === 403) {
            const error = await response.json();
            alert(error.detail || 'У вас нет прав на удаление этой карточки');
            return false;
        } else if (response.status === 404) {
            alert('Карточка не найдена');
            return false;
        } else {
            const error = await response.json();
            alert(error.detail || 'Произошла ошибка при удалении');
            return false;
        }
    } catch (error) {
        console.error('Ошибка при удалении вакансии:', error);
        alert('Не удалось подключиться к серверу');
        return false;
    }
}








document.addEventListener('DOMContentLoaded', () => {
    profile_activate();
});

export { isUserLoggedIn, performLogout, refreshAccessToken };
import { learnCards, teachCards } from "./scripts.js";

// Инициализация функционала навыков профиля
document.addEventListener('DOMContentLoaded', function() {
    fetch('/profile-skills-modals.html')
        .then(response => response.text())
        .then(data => {
            const modalContainer = document.createElement('div');
            modalContainer.innerHTML = data;
            document.body.appendChild(modalContainer);
            
            initSkillsModals();
            initSkillFilters();
        })
        .catch(error => console.error('Ошибка выгрузки окна', error));
});

// Инициализация модальных окон
function initSkillsModals() {
    const teachModal = document.getElementById('teachModal');
    const learnModal = document.getElementById('learnModal');
    const closeButtons = document.querySelectorAll('.skills-close');
    const addTeachBtn = document.getElementById('addTeachBtn');
    const addLearnBtn = document.getElementById('addLearnBtn');

    if (addTeachBtn && teachModal) {
        addTeachBtn.addEventListener('click', () => {
            teachModal.style.display = 'block';
            resetForm('teachForm');
        });
    }

    if (addLearnBtn && learnModal) {
        addLearnBtn.addEventListener('click', () => {
            learnModal.style.display = 'block';
            resetForm('learnForm');
        });
    }

    closeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.skills-modal');
            if (modal) modal.style.display = 'none';
        });
    });

    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('skills-modal')) {
            event.target.style.display = 'none';
        }
    });

    const teachForm = document.getElementById('teachForm');
    const learnForm = document.getElementById('learnForm');

    if (teachForm) {
        teachForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSkillSubmit(this, 'teach');
        });
    }

    if (learnForm) {
        learnForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSkillSubmit(this, 'learn');
        });
    }
}

function initSkillFilters() {
    const filterButtons = document.querySelectorAll('.skill-filter-btn');
    
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const parent = this.closest('.skills-filter-buttons');
            parent.querySelectorAll('.skill-filter-btn').forEach(b => {
                b.classList.remove('active');
            });
            this.classList.add('active');
        });
    });
}

async function handleSkillSubmit(form, type) {
    const formData = new FormData(form);
    const selectedSkill = form.querySelector('.skill-filter-btn.active');
    
    if (!selectedSkill) {
        alert('Пожалуйста, выберите предмет');
        return;
    }

    const skillData = {
        title: selectedSkill.textContent,
        formatl: formData.get('format'),
        description: formData.get('description'),
        price: parseInt(formData.get('price')) || 0,
        type: type
    };

    if (!skillData.description.trim()) {
        alert('Пожалуйста, добавьте описание навыка');
        return;
    }

    console.log('Данные для отправки на сервер:', skillData);
    try {
        const response = await fetch('http://localhost:8000/api/vacancies/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Authorization": "Bearer " + localStorage.getItem('access_token')
            },
            body: JSON.stringify(skillData)
        });
        if (response.ok) {
            const result = await response.json();
            console.log('Вакансия создана:', result);
            await learnCards();
            await teachCards();
            alert('Вакансия успешно создана!');
        } else {
            console.error('Ошибка:', await response.text());
        }
    } catch (error) {
        console.error('Ошибка запроса:', error);
        return false;
    }
    
    const modal = form.closest('.skills-modal');
    if (modal) modal.style.display = 'none';
    
    form.reset();
    resetSkillFilters(form);
}

function resetSkillFilters(form) {
    const filterButtons = form.querySelectorAll('.skill-filter-btn');
    filterButtons.forEach(btn => {
        btn.classList.remove('active');
    });
}

function resetForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.reset();
        resetSkillFilters(form);
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
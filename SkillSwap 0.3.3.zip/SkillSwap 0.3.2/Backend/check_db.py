from sqlalchemy.orm import Session
from dataBase.db import SessionLocal, engine
from dataBase.models import Base, User


db = SessionLocal()


users = db.query(User).all()

print("Пользователи в БД:")
print("-" * 80)
for user in users:
    print(f"ID: {user.id}")
    print(f"Username: {user.username}")
    print(f"Email: {user.email}")
    print(f"Password Hash: {user.password_hash[:50]}...")
    print("-" * 80)

db.close()

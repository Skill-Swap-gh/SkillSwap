from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=8)
    
class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    
class UserLogin(BaseModel):
    email: EmailStr
    password: str
    
    
class ProfileDataResponse(BaseModel):
    username: Optional[str] = None
    email: Optional[str] = None
    ClassRoom: Optional[str] = None
    ClassRoomChar: Optional[str] = None
    School: Optional[str] = None
    phone: Optional[str] = None
    about_me: Optional[str] = None
    points: Optional[int] = None


class ProfileDataUpdate(BaseModel):
    username: Optional[str]
    ClassRoom: Optional[str]
    ClassRoomChar: Optional[str]
    School: Optional[str]
    phone: Optional[str]
    about_me: Optional[str]
    email: Optional[str]
    
    

class VacancyCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=100)
    formatl: str = Field(..., pattern="^(online|offline)$")
    description: str = Field(..., min_length=0)
    price: int = Field(..., gt=0)
    type : str
    
    
class UserPublic(BaseModel):
    username: str
    class Config:
        from_attributes = True    

    
class VacancyResponse(BaseModel):
    id : int
    title: str
    formatl: str
    user_id: int
    description: str
    price: int
    author : UserPublic
    type: str
    class Config:
        from_attributes = True
        
        
    
class ThisVacancyResponse(BaseModel):
    title: str
    formatl: str
    description: str
    price: int

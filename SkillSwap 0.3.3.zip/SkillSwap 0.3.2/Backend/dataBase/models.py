from sqlalchemy import Column, Integer, String, Text, ForeignKey
from dataBase.db import Base
from sqlalchemy.orm import relationship

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    
    ClassRoom = Column(String, default="Не указано")
    ClassRoomChar = Column(String, default="Не указано")
    School = Column(String, default="Не указано")
    phone = Column(String, default="Не указано")
    about_me = Column(String, default="Не указано")
    points = Column(Integer, default=0)

    vacancies = relationship("Vacancy", back_populates="author")

class Vacancy(Base):
    __tablename__ = "vacancies"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    formatl = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    description = Column(String(200), nullable=False)
    price = Column(Integer, nullable=False)
    type = Column(String, nullable=False)

    author = relationship("User", back_populates="vacancies")
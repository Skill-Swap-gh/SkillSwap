from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm, HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from dataBase.db import get_db
from dataBase.models import User
from models.schemas import UserRegister, UserResponse, UserLogin, ProfileDataResponse, ProfileDataUpdate
from security.security import hash_password, verify_password, needs_rehash
from security.jwt_handler import create_access_token, create_refresh_token, verify_token
from dependencies import is_user_logged_in


router = APIRouter(prefix="/ProfileLoad", tags=["Загрузка данных"])
security = HTTPBearer()


@router.get("/profile", response_model= ProfileDataResponse)
async def get_user_profile(creditials : HTTPAuthorizationCredentials = Depends(security), db : Session = Depends(get_db)):
    token = creditials.credentials
    payload = verify_token(token, token_type="access")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Пользователь не найден"
        )
    return ProfileDataResponse(
        username=user.username,
        email=user.email,
        ClassRoom=user.ClassRoom,
        ClassRoomChar=user.ClassRoomChar,
        School=user.School,
        phone=user.phone,
        about_me=user.about_me,
        points=user.points
    )

    
@router.post("/profileUpdate", response_model=ProfileDataResponse)
async def update_user_profile(
    data: ProfileDataUpdate,
    creditials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    token = creditials.credentials
    payload = verify_token(token, token_type="access")
    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()
    
    if user is None:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    
    for field, value in data.dict(exclude_unset=True).items():
        if value is not None and value != "":
            setattr(user, field, value)
    
    db.commit()
    db.refresh(user)
    return ProfileDataResponse(
        username=user.username,
        email=user.email,
        ClassRoom=user.ClassRoom,
        ClassRoomChar=user.ClassRoomChar,
        School=user.School,
        phone=user.phone,
        about_me=user.about_me,
        points=user.points
    )


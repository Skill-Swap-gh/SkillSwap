import { openPurchaseModal } from "./modal-purchase.js";

document.addEventListener('DOMContentLoaded', function() {
    initFilters();
    get_vacanciec_for_catalog();
    loadPurchaseModal(); 
});
async function initFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                this.classList.toggle('active-filter');
            });
        });
    }
}

async function get_vacanciec_for_catalog() {
    try {
        const EmptStateVacancies = document.getElementById("empty-state-vacancies");
        const response = await fetch('http://localhost:8000/api/vacancies/catalog_cards', {
            method: 'GET'
        });
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.length === 0) {
                EmptStateVacancies.innerHTML = `
                    <div class="empty-icon">
                    </div>
                    <p class="empty-state-text">На данный момент в нашей системе нет доступных навыков</p>
                `;
                return;
            }
            
            EmptStateVacancies.innerHTML = ''; // Очищаем контейнер
            
            for (let i = 0; i < data.length; i++) {
                const vacancy = data[i];
                const card = document.createElement('div');
                card.className = 'item-category';
                card.dataset.vacancyId = vacancy.id;
                card.dataset.skillTitle = vacancy.title;
                card.dataset.price = vacancy.price;
                card.dataset.sellerId = vacancy.author?.id;
                card.dataset.sellerName = vacancy.author?.username;
                
                card.innerHTML = `
                    <div class="img-item-school"></div>
                    <div class="opt-item-school">
                        <p class="st-p-main">${vacancy.title}</p>
                        <span class="st-span">автор: <span class="st-p-mini">${vacancy.author?.username || 'Неизвестно'}</span></span>
                        <span class="st-span2">Описание: <span class="st-p-mini">${vacancy.description}</span></span> 
                        <span class="st-span2">Тип занятий: <span class="st-p-mini">${vacancy.formatl}</span></span>
                        <span class="st-span3">Цена: <span class="st-p-mini3">${vacancy.price}</span>XP</span>
                        <button class="btn-primary btn-interested" 
                                data-vacancy-id="${vacancy.id}"
                                data-skill-title="${vacancy.title}"
                                data-price="${vacancy.price}"
                                data-seller-id="${vacancy.author?.id}"
                                data-seller-name="${vacancy.author?.username}">
                            Интересно
                        </button>
                    </div>
                `;
                
                const btnInterested = card.querySelector('.btn-interested');
                
                if (btnInterested) {
                    btnInterested.addEventListener('click', function() {
                        const skillData = {
                            title: this.dataset.skillTitle,
                            description: vacancy.description,
                            format: vacancy.formatl,
                            price: this.dataset.price,
                            sellerId: this.dataset.sellerId,
                            sellerName: this.dataset.sellerName,
                            skillId: this.dataset.vacancyId
                        };
                        
                        // Открываем модальное окно покупки
                        openPurchaseModal(skillData);
                        
                        // Сохраняем данные для использования в модальном окне
                        window.currentPurchaseData = skillData;
                    });
                }
                
                EmptStateVacancies.appendChild(card);
            }
        }
    } catch(error) {
        console.error('Ошибка запроса /catalog_cards:', error);
        return false;
    }
}




async function loadPurchaseModal() {
    try {
        const response = await fetch('/modal-purchase.html');
        const data = await response.text();
        
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = data;
        document.body.appendChild(modalContainer);
        
        console.log('Модальное окно загружено');
    } catch (error) {
        console.error('Ошибка загрузки модального окна:', error);
    }
}





function isUserLoggedIn() {
    const token = localStorage.getItem('access_token');
    if (!token) {
        return false;
    }
    
    try {
        const payload = parseJwt(token);

        if (!payload) {
            console.log('Невалидный токен (payload is null)');
            localStorage.removeItem('access_token');
            return false;
        }

        if (!payload.exp) {
            console.log('Токен без поля exp');
            return false;
        }

        const currentTime = Math.floor(Date.now() / 1000);
        
        if (payload.exp < currentTime) {
            localStorage.removeItem('access_token');
            return false;
        }
        
        return true

    } catch (error) {
        console.error('Ошибка проверки авторизации:', error);
        return false;
    }
}



function parseJwt(token) {
    try {
        const base64 = token.split('.')[1]
            .replace(/-/g, '+')
            .replace(/_/g, '/');
        const decoded = new TextDecoder().decode(
            Uint8Array.from(atob(base64), c => c.charCodeAt(0))
        );
        return JSON.parse(decoded);
    } catch (e) {
        return null;
    }
}



function getTokenExpiration(token) {
    const payload = parseJwt(token);
    if (!payload) return null; 
    return payload.exp || null;
}

function isTokenExpired(token) {
    const exp = getTokenExpiration(token);
    if (!exp) return true;
    const currentTime = Math.floor(Date.now() / 1000);
    return exp < currentTime;
}

async function refreshAccessToken() {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (!refreshToken) {
        console.log('Refresh token отсутствует');
        return false;
    }
    if (isTokenExpired(refreshToken)) {
        console.log('Refresh token истёк - выход');
        performLogout();
        return false;
    }
    
    try {
        const response = await fetch('http://localhost:8000/auth/refresh', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ refresh_token: refreshToken })
        });
        
        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('access_token', data.access_token);
            console.log('Access token обновлён');
            return true;
        } else {
            console.error('Ошибка обновления токена:', response.status);
            performLogout();
            return false;
        }
    } catch (error) {
        console.error('Ошибка запроса /refresh:', error);
        performLogout();
        return false;
    }
}


let tokenRefreshInterval = null;
async function startAutomaticTokenRefresh() {
    tokenRefreshInterval = setInterval(async () => {
        const accessToken = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');
        
        if (!accessToken || !refreshToken) {
            console.log('Токены отсутствуют, останавливаем обновление');
            return;
        }
        if (isTokenExpired(refreshToken)) {
            console.log('Refresh token истёк — автоматический выход');
            performLogout();
            return;
        }
        const accessExp = getTokenExpiration(accessToken);
        const currentTime = Math.floor(Date.now() / 1000);
        const timeUntilExpiry = accessExp - currentTime;
        
        console.log(`До истечения токена: ${timeUntilExpiry} секунд`);
        
        if (timeUntilExpiry <= 30) {
            console.log('Access token истекает — обновление...');
            await refreshAccessToken();
        }
    }, 10000); 
}

export async function learnCards() {
    const WantLearnText = document.getElementById('want-learn')
    const learnCardsBlock = document.getElementById('learn-cards-block');

    if (!WantLearnText || !learnCardsBlock) {
        return; 
    }

    const token = localStorage.getItem('access_token');
    if (!token) {
        console.error('Токен отсутствует');
        return false;
    }

    try {
        const response = await fetch('http://localhost:8000/api/vacancies/mycards_learn', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });
        
        if (response.ok) {
            const data = await response.json();
            
            if (WantLearnText) {
                WantLearnText.style.display = "none";
            }
            
            if (learnCardsBlock) {  
                learnCardsBlock.innerHTML = '';
            
            if (data.length === 0) {
                learnCardsBlock.innerHTML = '<p class="no-cards">У вас пока нет вакансий</p>';
                return data;
            }
            
            for (let i = 0; i < data.length; i++) {
                const vacancy = data[i];
                
                const card = document.createElement('div');
                card.className = 'skill-card';
                card.dataset.vacancyId = vacancy.id;
                
                card.innerHTML = `
                    <div class="skill-header">
                        <span class="skill-title">${escapeHtml(vacancy.title)}</span>
                        <span class="skill-price">${vacancy.price} XP</span>
                    </div>
                    <div class="skill-description">${escapeHtml(vacancy.description)}</div>
                    <div class="skill-actions">
                        <button class="btn-delete-skill" data-vacancy-id="${vacancy.id}">Удалить</button>
                    </div>
                `;
                learnCardsBlock.appendChild(card);
            }
            }
            return data;
        } else {
            WantLearnText.style.display = "none";
            console.error('Ошибка вывода карточек "Хочу научиться"', response.status);
            return false;
        }
    } catch (error) {
        if (WantLearnText) {
            WantLearnText.style.display = "none"; 
        }
        console.error('Ошибка запроса /mycards_learn:', error);
        return false;
    }
}

export async function teachCards() {
    const WantTeachText = document.getElementById('want-teach')
    const TeachCardsBlock = document.getElementById('teach-cards-block');

    if (!WantTeachText || !TeachCardsBlock) {
        return; 
    }

    const token = localStorage.getItem('access_token');
    if (!token) {
        console.error('Токен отсутствует');
        return false;
    }

    try {
        const response = await fetch('http://localhost:8000/api/vacancies/mycards_teach', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });
        
        if (response.ok) {
            const data = await response.json();
            if (WantTeachText) {
                WantTeachText.style.display = "none";
            }
            
            if (TeachCardsBlock) {
                TeachCardsBlock.innerHTML = '';
            
            if (data.length === 0) {
                TeachCardsBlock.innerHTML = '<p class="no-cards">У вас пока нет вакансий</p>';
                return data;
            }
            
            for (let i = 0; i < data.length; i++) {
                const vacancy = data[i];
                
                const card = document.createElement('div');
                card.className = 'skill-card';
                card.dataset.vacancyId = vacancy.id;
                
                card.innerHTML = `
                    <div class="skill-header">
                        <span class="skill-title">${escapeHtml(vacancy.title)}</span>
                        <span class="skill-price">${vacancy.price} XP</span>
                    </div>
                    <div class="skill-description">${escapeHtml(vacancy.description)}</div>
                    <div class="skill-actions">
                        <button class="btn-delete-skill" data-vacancy-id="${vacancy.id}">Удалить</button>
                    </div>
                `;
                TeachCardsBlock.appendChild(card);
            }
            return data;
        } else {
            WantTeachText.style.display = "none";
            console.error('Ошибка вывода карточек "Хочу научиться"', response.status);
            return false;
        }
    }} catch (error) {
        if (WantTeachText) {  
            WantTeachText.style.display = "none";
        }
        console.error('Ошибка запроса /mycards_learn:', error);
        return false;
    }
}




function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}


async function stopAutomaticTokenRefresh() {
    if (tokenRefreshInterval) {
        clearInterval(tokenRefreshInterval);
        tokenRefreshInterval = null;
    }
}


async function performLogout(){
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    stopAutomaticTokenRefresh()

    const headerActions = document.getElementById("header-actions-id");
    if (headerActions) {
        headerActions.innerHTML = `<button class="btn-primary">Войти</button>
                    <button class="btn-primary" id = "req-in-header-actions">Зарегистрироваться</button>`;
    }
    
    alert('Ваша сессия истекла. Войдите снова.');
    window.location.href = '/';
    
}


// Загрузка модального окна уведомлений
async function loadNotificationModal() {
    try {
        const response = await fetch('/notification-modal.html');
        if (response.ok) {
            const data = await response.text();
            const container = document.createElement('div');
            container.innerHTML = data;
            document.body.appendChild(container);
        }
    } catch (error) {
        console.error('Ошибка загрузки модального окна уведомлений:', error);
    }
}

// Обновленная функция profile_activate
export async function profile_activate() {
    if (isUserLoggedIn()) {
        const HeaderActions = document.getElementById("header-actions-id");

        if (HeaderActions) {
            HeaderActions.innerHTML = `
                <a href="" class="nav-link">Мои занятия</a>
                <span class="points">${getUserPoints()} XP</span>
                <button class="notification-bell icon-btn">🔔</button>
                <a href="/profile.html"><button class="icon-btn profile-btn">👤</button></a>
            `;

            // Загружаем модальное окно уведомлений
            await loadNotificationModal();
            
            // Загружаем модуль уведомлений
            await import('./notification.js');
            await import('./user-context.js');
        }

        startAutomaticTokenRefresh();
        await learnCards();
        await teachCards();
    } else {
        const HeaderActions = document.getElementById("header-actions-id");
        if (HeaderActions) {
            HeaderActions.innerHTML = `
                <button class="btn-primary" id="log-in-header-actions">Войти</button>
                <button class="btn-primary" id="req-in-header-actions">Зарегистрироваться</button>
            `;
        }
    }
}

// Новая функция для получения очков пользователя
function getUserPoints() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.points || 0;
}







document.addEventListener('DOMContentLoaded', () => {
    profile_activate();
});

export { isUserLoggedIn, performLogout, refreshAccessToken };
// Контекст пользователя и динамические значения

class UserContext {
    constructor() {
        this.currentUser = null;
        this.dynamicValues = {
            notificationTemplates: {
                purchase_request: "Пользователь {{buyerName}} хочет купить у вас ваш {{skillTitle}}.",
                purchase_accepted: "Вашу покупку одобрили! Загляните в ваши занятия!",
                purchase_rejected: "Вашу покупку отменили."
            }
        };
        this.init();
    }

    async init() {
        await this.loadCurrentUser();
        this.injectDynamicValues();
    }

    async loadCurrentUser() {
        try {
            const token = localStorage.getItem('access_token');
            if (!token) return;

            const response = await fetch('http://localhost:8000/api/user/me', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                this.currentUser = await response.json();
                localStorage.setItem('user', JSON.stringify(this.currentUser));
            }
        } catch (error) {
            console.error('Ошибка загрузки данных пользователя:', error);
            // Восстанавливаем из localStorage
            const savedUser = localStorage.getItem('user');
            if (savedUser) {
                this.currentUser = JSON.parse(savedUser);
            }
        }
    }

    injectDynamicValues() {
        // Обновляем имя пользователя в шапке
        const userNameElements = document.querySelectorAll('#userName, .user-name');
        if (userNameElements.length > 0 && this.currentUser?.username) {
            userNameElements.forEach(el => {
                el.textContent = this.currentUser.username;
            });
        }

        // Обновляем очки в шапке
        const pointsElements = document.querySelectorAll('.points, .points-value');
        if (pointsElements.length > 0 && this.currentUser?.points) {
            pointsElements.forEach(el => {
                el.textContent = `${this.currentUser.points} XP`;
            });
        }
    }

    getCurrentUser() {
        return this.currentUser || JSON.parse(localStorage.getItem('user') || '{}');
    }

    getUserId() {
        return this.currentUser?.id || 'unknown';
    }

    getUserName() {
        return this.currentUser?.username || 'Пользователь';
    }

    getUserPoints() {
        return this.currentUser?.points || 0;
    }

    createPurchaseNotification(buyerName, skillTitle) {
        const template = this.dynamicValues.notificationTemplates.purchase_request;
        return template
            .replace("{{buyerName}}", buyerName)
            .replace("{{skillTitle}}", skillTitle);
    }
}

// Глобальный экземпляр
window.userContext = new UserContext();

// Экспорт функций для использования в других модулях
export function getCurrentUser() {
    return window.userContext?.getCurrentUser() || {};
}

export function getUserId() {
    return window.userContext?.getUserId() || 'unknown';
}

export function getUserName() {
    return window.userContext?.getUserName() || 'Пользователь';
}

export function createPurchaseNotification(buyerName, skillTitle) {
    if (window.userContext) {
        return window.userContext.createPurchaseNotification(buyerName, skillTitle);
    }
    return `Пользователь ${buyerName} хочет купить у вас ваш ${skillTitle}.`;
}
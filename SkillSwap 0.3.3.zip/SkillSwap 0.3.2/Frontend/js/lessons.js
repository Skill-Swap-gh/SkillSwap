// Управление занятиями
import { getCurrentUser } from './user-context.js';

class LessonsManager {
    constructor() {
        this.lessons = [];
        this.init();
    }

    async init() {
        await this.loadLessons();
        this.setupFilters();
    }

    async loadLessons() {
        try {
            const token = localStorage.getItem('access_token');
            if (!token) return;

            const response = await fetch('http://localhost:8000/api/lessons', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.lessons = data.lessons || [];
                this.renderLessons('all');
            }
        } catch (error) {
            console.error('Ошибка загрузки занятий:', error);
        }
    }

    setupFilters() {
        const filterBtns = document.querySelectorAll('.filter-btn');
        if (filterBtns) {
            filterBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const filter = btn.textContent.toLowerCase();
                    this.renderLessons(filter);
                    
                    // Обновляем активную кнопку
                    filterBtns.forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                });
            });
        }
    }

    renderLessons(filter = 'all') {
        const container = document.getElementById('lessonsContainer') || 
                         document.querySelector('.lessons-content');
        
        if (!container) return;

        let filteredLessons = this.lessons;
        
        if (filter === 'запланированные') {
            filteredLessons = this.lessons.filter(l => l.status === 'запланировано');
        } else if (filter === 'завершенные') {
            filteredLessons = this.lessons.filter(l => l.status === 'завершено');
        } else if (filter === 'отмененные') {
            filteredLessons = this.lessons.filter(l => l.status === 'отменено');
        }

        if (filteredLessons.length === 0) {
            container.innerHTML = `
                <div class="empty-lessons">
                    <p>У вас пока нет занятий</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filteredLessons.map(lesson => this.createLessonCard(lesson)).join('');
    }

    createLessonCard(lesson) {
        const statusClass = this.getStatusClass(lesson.status);
        const chatButton = lesson.with_chat_button ? 
            `<button class="btn-chat" 
                    data-lesson-id="${lesson.id}"
                    data-peer-id="${lesson.peer_id}"
                    onclick="window.location.href='/chat.html?lessonId=${lesson.id}&peerId=${lesson.peer_id}'">
                Перейти к занятию
            </button>` : '';

        return `
            <div class="lesson-card" data-lesson-id="${lesson.id}">
                <div class="lesson-header">
                    <h4 class="lesson-title">${lesson.title}</h4>
                    <span class="lesson-status ${statusClass}">${lesson.status}</span>
                </div>
                
                <div class="lesson-content">
                    <p class="lesson-description">${lesson.description}</p>
                    
                    <div class="lesson-info">
                        <div class="info-item">
                            <span class="info-label">Участник:</span>
                            <span class="info-value">${lesson.peer_name || 'Не указан'}</span>
                        </div>
                        
                        ${lesson.scheduled_time ? `
                        <div class="info-item">
                            <span class="info-label">Дата:</span>
                            <span class="info-value">${this.formatDate(lesson.scheduled_time)}</span>
                        </div>` : ''}
                        
                        ${lesson.price ? `
                        <div class="info-item">
                            <span class="info-label">Стоимость:</span>
                            <span class="info-value">${lesson.price} XP</span>
                        </div>` : ''}
                    </div>
                </div>
                
                <div class="lesson-actions">
                    ${chatButton}
                    
                    <button class="btn-details" onclick="viewLessonDetails('${lesson.id}')">
                        Подробнее
                    </button>
                </div>
            </div>
        `;
    }

    addToMyLessons(skillId, title, description, status = 'запланировано', withChatButton = true) {
        const newLesson = {
            id: `lesson_${Date.now()}`,
            skill_id: skillId,
            title: title,
            description: description || 'Описание навыка',
            status: status,
            with_chat_button: withChatButton,
            created_at: new Date().toISOString(),
            peer_name: 'Участник занятия'
        };

        this.lessons.unshift(newLesson);
        this.renderLessons('all');
        
        // Показываем уведомление
        alert(`Занятие "${title}" добавлено в ваш список!`);
    }

    getStatusClass(status) {
        switch(status) {
            case 'запланировано':
                return 'status-planned';
            case 'завершено':
                return 'status-completed';
            case 'отменено':
                return 'status-cancelled';
            default:
                return 'status-default';
        }
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            day: 'numeric',
            month: 'long',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}

// Глобальная функция для вызова из других модулей
window.addToMyLessons = function(skillId, title, description, status, withChatButton) {
    if (window.lessonsManager) {
        window.lessonsManager.addToMyLessons(skillId, title, description, status, withChatButton);
    }
};

// Создаем глобальный экземпляр
window.lessonsManager = new LessonsManager();

// CSS для занятий (добавить в profile.css или отдельный файл)
const lessonsStyles = `
.lesson-card {
    background: white;
    border: 1px solid #e5e5e5;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: transform 0.2s, box-shadow 0.2s;
}

.lesson-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
}

.lesson-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.lesson-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a1a1a;
    margin: 0;
    flex: 1;
}

.lesson-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    margin-left: 12px;
}

.status-planned {
    background: #e8f5e9;
    color: #2e7d32;
}

.status-completed {
    background: #e3f2fd;
    color: #1565c0;
}

.status-cancelled {
    background: #ffebee;
    color: #c62828;
}

.status-default {
    background: #f5f5f5;
    color: #666;
}

.lesson-description {
    color: #666;
    font-size: 14px;
    line-height: 1.5;
    margin-bottom: 16px;
}

.lesson-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}

.info-item {
    display: flex;
    flex-direction: column;
}

.info-label {
    font-size: 12px;
    color: #999;
    margin-bottom: 4px;
}

.info-value {
    font-size: 14px;
    color: #1a1a1a;
    font-weight: 500;
}

.lesson-actions {
    display: flex;
    gap: 12px;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
}

.btn-chat {
    background: linear-gradient(135deg, #93aaf8 0%, #814cfc 100%);
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    flex: 1;
}

.btn-chat:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.3);
}

.btn-details {
    background: white;
    color: #666;
    border: 1px solid #e5e5e5;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
}

.btn-details:hover {
    background: #f5f5f5;
    border-color: #7c3aed;
    color: #7c3aed;
}
`;

// Добавляем стили на страницу
const styleSheet = document.createElement('style');
styleSheet.textContent = lessonsStyles;
document.head.appendChild(styleSheet);

export { LessonsManager };
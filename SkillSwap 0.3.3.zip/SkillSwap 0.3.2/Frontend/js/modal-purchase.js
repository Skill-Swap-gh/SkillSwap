// Инициализация модального окна покупки

    const purchaseModal = document.getElementById('purchaseModal');
    const closeBtn = document.querySelector('.purchase-close');

    
    // Функция для открытия модального окна
    export function openModal() {
        if (purchaseModal) {
            purchaseModal.style.display = 'block';
            document.body.style.overflow = 'hidden'; // Блокируем прокрутку фона
        }
    }
    
    // Функция для закрытия модального окна
    export function closeModal() {
        if (purchaseModal) {
            purchaseModal.style.display = 'none';
            document.body.style.overflow = ''; 
        }
    }
    
    // Демо-кнопка для открытия

    // Закрытие
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    
    // Обработчики для кнопок в модальном окне
    const buyBtn = document.querySelector('.btn-buy');
    const exchangeBtn = document.querySelector('.btn-exchange');
    
    if (buyBtn) {
        buyBtn.addEventListener('click', function() {
            const xpAmount = document.querySelector('.xp-amount').textContent;
            alert(`Покупка совершена за ${xpAmount} XP!`);
            closeModal();
        });
    }
    
    if (exchangeBtn) {
        exchangeBtn.addEventListener('click', function() {
            alert('Функция "Предложить обмен" будет реализована позже');
        });
    }


// Функция для открытия модального окна с данными о навыке (для интеграции)
export function openPurchaseModal(skillData) {
    const purchaseModal = document.getElementById('purchaseModal');
    
    if (!purchaseModal) {
        console.error('Модальное окно покупки не найдено');
        return;
    }
    
    // Заполнение данных о навыке
    const skillTitle = purchaseModal.querySelector('.skill-title');
    const skillDescription = purchaseModal.querySelector('.skill-description');
    const skillFormat = purchaseModal.querySelector('.format-value');
    const skillPrice = purchaseModal.querySelector('.price-value');
    const xpAmount = purchaseModal.querySelector('.xp-amount');
    
    if (skillTitle) skillTitle.textContent = skillData.title || 'Название навыка';
    if (skillDescription) skillDescription.textContent = skillData.description || 'Описание навыка';
    if (skillFormat) skillFormat.textContent = skillData.format || 'Онлайн';
    if (skillPrice) skillPrice.textContent = `${skillData.price || 0} XP`;
    if (xpAmount) xpAmount.textContent = skillData.price || 0;
    
    // Показываем модальное окно
    purchaseModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}


document.addEventListener('click', function(e) {
    if (e.target.closest('[class*="purchase-close"]') && e.target.closest('#purchaseModal')) {
        const modal = document.getElementById('purchaseModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }
});




// Обработчик кнопки покупки
async function handlePurchase() {
    const buyBtn = document.querySelector('.btn-buy');
    
    if (buyBtn) {
        buyBtn.addEventListener('click', async function() {
            const purchaseData = window.currentPurchaseData;
            if (!purchaseData) return;
            
            const xpAmount = document.querySelector('.xp-amount').textContent;
            
            try {
                // Отправляем запрос на покупку
                const token = localStorage.getItem('access_token');
                const response = await fetch('http://localhost:8000/api/purchase/request', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        skill_id: purchaseData.skillId,
                        skill_title: purchaseData.title,
                        price: purchaseData.price,
                        seller_id: purchaseData.sellerId
                    })
                });
                
                if (response.ok) {
                    const data = await response.json();
                    
                    alert(`Покупка совершена за ${xpAmount} XP!`);
                    
                    // Создаем тестовое уведомление для продавца
                    if (window.notificationSystem) {
                        const currentUser = JSON.parse(localStorage.getItem('user') || '{}');
                        
                        const notification = {
                            id: Date.now(),
                            type: "purchase_request",
                            message: `Пользователь ${currentUser.username || 'Покупатель'} хочет купить у вас ваш ${purchaseData.title}.`,
                            skill_id: purchaseData.skillId,
                            skill_title: purchaseData.title,
                            from_user_id: currentUser.id,
                            from_user_name: currentUser.username,
                            buttons: ["accept", "reject"]
                        };
                        
                        window.notificationSystem.addTestNotification(notification);
                    }
                    
                    closeModal();
                } else {
                    alert('Ошибка при покупке');
                }
            } catch (error) {
                console.error('Ошибка покупки:', error);
                alert('Ошибка при покупке');
            }
        });
    }
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', handlePurchase);
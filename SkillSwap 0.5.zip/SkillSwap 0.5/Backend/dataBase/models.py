from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Boolean
from dataBase.db import Base
from sqlalchemy.orm import relationship
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    
    ClassRoom = Column(String, default="Не указано")
    ClassRoomChar = Column(String, default="Не указано")
    School = Column(String, default="Не указано")
    phone = Column(String, default="Не указано")
    about_me = Column(String, default="Не указано")
    points = Column(Integer, default=100) 
    last_xp_claim = Column(DateTime, default=datetime.now)
    
    vacancies = relationship("Vacancy", back_populates="author")
    purchased_lessons = relationship("PurchasedLesson", back_populates="user")

class Vacancy(Base):
    __tablename__ = "vacancies"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    formatl = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    description = Column(String(200), nullable=False)
    price = Column(Integer, nullable=False)
    type = Column(String, nullable=False)

    author = relationship("User", back_populates="vacancies")
    purchased_by = relationship("PurchasedLesson", back_populates="vacancy")

class PurchasedLesson(Base):
    __tablename__ = "purchased_lessons"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    vacancy_id = Column(Integer, ForeignKey("vacancies.id"), nullable=False)
    purchase_date = Column(DateTime, default=datetime.now)
    lesson_date = Column(DateTime, nullable=True)
    status = Column(String, default="planned")
    notes = Column(String, default="")
    
    user = relationship("User", back_populates="purchased_lessons")
    vacancy = relationship("Vacancy", back_populates="purchased_by")
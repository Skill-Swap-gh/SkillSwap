from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
import mimetypes

from auth import router as router_auth
from ProfileLoad import router as router_ProfLoad
from vacancies import router as router_vacancies
from xp_system import router as router_xp
from purchases import router as router_purchases

from dataBase.db import engine, Base
from dataBase.models import User, Vacancy, PurchasedLesson

app = FastAPI()

mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')
mimetypes.add_type('text/html', '.html')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR.parent / "Frontend"

app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

app.include_router(router_auth)
app.include_router(router_ProfLoad)
app.include_router(router_vacancies)
app.include_router(router_xp)
app.include_router(router_purchases)

@app.get("/")
async def root():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/catalog.html")
async def catalog_page():
    return FileResponse(FRONTEND_DIR / "catalog.html")

@app.get("/modals.html")
async def modals_page():
    return FileResponse(FRONTEND_DIR / "modals.html")

@app.get("/modal-purchase.html")
async def modal_purchase_page():
    return FileResponse(FRONTEND_DIR / "modal-purchase.html")

@app.get("/profile-skills-modals.html")
async def profile_skills_modals():
    return FileResponse(FRONTEND_DIR / "profile-skills-modals.html")

@app.get("/profile-skills-cards.html")
async def profile_skills_cards():
    return FileResponse(FRONTEND_DIR / "profile-skills-cards.html")

@app.get("/profile.html")
async def profile_page():
    return FileResponse(FRONTEND_DIR / "profile.html")

@app.get("/lesson.html")
async def lesson_page():
    return FileResponse(FRONTEND_DIR / "lesson.html")

@app.get("/favicon.ico")
async def favicon():
    favicon_path = FRONTEND_DIR / "images" / "favicon.ico"
    if favicon_path.exists():
        return FileResponse(favicon_path)
    else:
        return Response(status_code=204)
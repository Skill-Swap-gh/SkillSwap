from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, joinedload
from typing import List, Optional
from datetime import datetime

from dataBase.db import get_db
from dataBase.models import User, Vacancy, PurchasedLesson
from dependencies import get_current_user
from pydantic import BaseModel

router = APIRouter(prefix="/api/purchases", tags=["purchases"])

class PurchasedLessonResponse(BaseModel):
    id: int
    title: str
    subject: str
    teacher: str
    teacherInitials: str
    student: Optional[str] = None  
    studentInitials: Optional[str] = None  
    description: str
    status: str
    statusText: str
    date: str
    duration: str = "60 минут"
    format: str
    price: int
    rating: float = 4.8
    lessonsCount: int = 0
    vacancy_id: int
    teacher_id: int
    student_id: Optional[int] = None 
    
    class Config:
        from_attributes = True

@router.post("/buy/{vacancy_id}")
async def buy_vacancy(
    vacancy_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    print(f"=== ПОПЫТКА ПОКУПКИ ===")
    print(f"User ID: {current_user.id}, User points: {current_user.points}")
    print(f"Vacancy ID: {vacancy_id}")
    
    try:
        vacancy = db.query(Vacancy).filter(Vacancy.id == vacancy_id).first()
        
        if not vacancy:
            print(f"Вакансия {vacancy_id} не найдена")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Вакансия не найдена"
            )
        
        print(f"Найдена вакансия: {vacancy.title}, цена: {vacancy.price}, автор: {vacancy.user_id}")
        
        if vacancy.user_id == current_user.id:
            print("Попытка купить свою вакансию")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Нельзя купить собственное предложение"
            )
        
        if current_user.points < vacancy.price:
            print(f"Недостаточно XP: {current_user.points} < {vacancy.price}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Недостаточно XP. Нужно {vacancy.price}, у вас {current_user.points}"
            )
        
        existing_purchase = db.query(PurchasedLesson).filter(
            PurchasedLesson.user_id == current_user.id,
            PurchasedLesson.vacancy_id == vacancy_id
        ).first()
        
        if existing_purchase:
            print(f"Вакансия уже куплена, purchase_id: {existing_purchase.id}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Вы уже купили это занятие"
            )
        teacher = db.query(User).filter(User.id == vacancy.user_id).first()
        if teacher:
            teacher.points += vacancy.price
            print(f"✅ Учителю {teacher.username} начислено {vacancy.price} XP")
        

        current_user.points -= vacancy.price
        print(f"У ученика списано {vacancy.price} XP. Новый баланс: {current_user.points}")
        

        new_purchase = PurchasedLesson(
            user_id=current_user.id,
            vacancy_id=vacancy_id,
            status="planned"
        )
        
        db.add(new_purchase)
        db.commit()
        db.refresh(new_purchase)
        
        print(f"✅ Покупка успешна! ID покупки: {new_purchase.id}")
        
        return {
            "success": True,
            "message": f"Занятие успешно куплено за {vacancy.price} XP",
            "remaining_points": current_user.points,
            "purchase_id": new_purchase.id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"!!! ОШИБКА: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Внутренняя ошибка сервера: {str(e)}"
        )

@router.get("/my-lessons", response_model=List[PurchasedLessonResponse])
async def get_my_lessons(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    purchases = db.query(PurchasedLesson).options(
        joinedload(PurchasedLesson.vacancy).joinedload(Vacancy.author)
    ).filter(
        PurchasedLesson.user_id == current_user.id
    ).all()
    
    result = []
    for purchase in purchases:
        vacancy = purchase.vacancy
        author = vacancy.author
        
        initials = "".join([word[0].upper() for word in author.username.split()[:2]])
        if not initials:
            initials = author.username[:2].upper()
        
        status_text = {
            "planned": "Запланировано",
            "completed": "Завершено",
            "cancelled": "Отменено"
        }.get(purchase.status, "Запланировано")
        
        date_str = purchase.lesson_date.strftime("%d %B %Y, %H:%M") if purchase.lesson_date else "Дата не назначена"
        
        result.append(PurchasedLessonResponse(
            id=purchase.id,
            title=vacancy.title,
            subject=vacancy.title,
            teacher=author.username,
            teacherInitials=initials,
            description=vacancy.description,
            status=purchase.status,
            statusText=status_text,
            date=date_str,
            format="Онлайн" if vacancy.formatl == "online" else "Офлайн",
            price=vacancy.price,
            rating=4.8,
            lessonsCount=0,
            vacancy_id=vacancy.id,
            teacher_id=author.id
        ))
    
    return result

@router.put("/lesson/{purchase_id}/status")
async def update_lesson_status(
    purchase_id: int,
    status: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if status not in ["planned", "completed", "cancelled"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Недопустимый статус"
        )
    
    purchase = db.query(PurchasedLesson).filter(
        PurchasedLesson.id == purchase_id,
        PurchasedLesson.user_id == current_user.id
    ).first()
    
    if not purchase:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Занятие не найдено"
        )
    
    purchase.status = status
    db.commit()
    
    return {"success": True, "message": f"Статус изменен на {status}"}

@router.get("/my-taught-lessons", response_model=List[PurchasedLessonResponse])
async def get_my_taught_lessons(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    print(f"Запрос занятий для учителя ID: {current_user.id}, имя: {current_user.username}")
    
    purchases = db.query(PurchasedLesson).options(
        joinedload(PurchasedLesson.vacancy),
        joinedload(PurchasedLesson.user)
    ).join(
        Vacancy, PurchasedLesson.vacancy_id == Vacancy.id
    ).filter(
        Vacancy.user_id == current_user.id
    ).all()
    
    print(f"Найдено покупок: {len(purchases)}")
    
    result = []
    for purchase in purchases:
        vacancy = purchase.vacancy
        buyer = purchase.user
        
        print(f"  - Покупка ID: {purchase.id}, вакансия: {vacancy.title}, покупатель: {buyer.username}")
        
        buyer_initials = "".join([word[0].upper() for word in buyer.username.split()[:2]])
        if not buyer_initials:
            buyer_initials = buyer.username[:2].upper()
        
        teacher_initials = "".join([word[0].upper() for word in current_user.username.split()[:2]])
        if not teacher_initials:
            teacher_initials = current_user.username[:2].upper()
        
        status_text = {
            "planned": "Запланировано",
            "completed": "Завершено",
            "cancelled": "Отменено"
        }.get(purchase.status, "Запланировано")
        
        date_str = purchase.lesson_date.strftime("%d %B %Y, %H:%M") if purchase.lesson_date else "Дата не назначена"
        
        result.append(PurchasedLessonResponse(
            id=purchase.id,
            title=vacancy.title,
            subject=vacancy.title,
            teacher=current_user.username,
            teacherInitials=teacher_initials,
            student=buyer.username,
            studentInitials=buyer_initials,
            description=vacancy.description,
            status=purchase.status,
            statusText=status_text,
            date=date_str,
            format="Онлайн" if vacancy.formatl == "online" else "Офлайн",
            price=vacancy.price,
            rating=4.8,
            lessonsCount=0,
            vacancy_id=vacancy.id,
            teacher_id=current_user.id,
            student_id=buyer.id
        ))
    
    print(f"Возвращаем {len(result)} занятий для учителя")
    return result
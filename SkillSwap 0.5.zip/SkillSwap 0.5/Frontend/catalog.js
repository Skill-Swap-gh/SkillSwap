import { openPurchaseModal } from "./modal-purchase.js";

document.addEventListener('DOMContentLoaded', function() {
    initFilters();
    get_vacanciec_for_catalog();
    loadPurchaseModal(); 
});

async function initFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(function(btn) {
            btn.addEventListener('click', function() {
                this.classList.toggle('active-filter');
            });
        });
    }
}

async function get_vacanciec_for_catalog(){
    try{
        const EmptStateVacancies = document.getElementById("empty-state-vacancies");
        const response = await fetch('http://localhost:8000/api/vacancies/catalog_cards', {
                method: 'GET'
            });
            if (response.ok) {
                const data = await response.json();
                console.log('📦 Получены вакансии:', data);
                
                if (data.length === 0) {
                    EmptStateVacancies.innerHTML = `
                        <div class="empty-icon">
                        </div>
                        <p class="empty-state-text">На данный момент в нашей системе нет доступных навыков</p>
                    `;
                    return;
                }  
                
                for (let i = 0; i < data.length; i++){
                    const vacancy = data[i];
                    const card = document.createElement('div');
                    card.className = 'item-category';
                    card.dataset.vacancyId = vacancy.id;
                    
                    card.innerHTML =
                        `<div class="img-item-school">
                            <img src="/static/images/foto.png" alt="foto" style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div class="opt-item-school">
                            <p class="st-p-main">${vacancy.title}</p>
                            <span class="st-spam">автор: <span class="st-p-mini">${vacancy.author.username}</span></span>
                            <span class="st-spam">Описание: <span class="st-p-mini">${vacancy.description}</span></span>
                            <span class="st-spam">Тип занятий: <span class="st-p-mini">${vacancy.format1}</span></span>
                            <span class="st-spam">Цена: <span class="st-p-mini3">${vacancy.price}</span></span>
                            <button class="btn-primary btn-interested" data-vacancy-id="${vacancy.id}">Интересно</button>
                            <button class="btn-primary btn-buy-catalog" data-vacancy-id="${vacancy.id}">Купить</button>
                        </div>`;
                    
                    // Обработчик для кнопки "Интересно"
                    const btnInterested = card.querySelector('.btn-interested');
                    if (btnInterested) {
                        btnInterested.addEventListener('click', function() {
                            console.log('👆 Нажата кнопка "Интересно" для вакансии:', vacancy.id);
                            openPurchaseModal({
                                vacancyId: vacancy.id,
                                title: vacancy.title,
                                description: vacancy.description,
                                format: vacancy.formatl,
                                price: vacancy.price
                            });
                        });
                    }
                    
                    // 🔥 НОВАЯ КНОПКА "Купить" с правильным стилем
                    const buyBtn = card.querySelector('.btn-buy-catalog');
                    if (buyBtn) {
                        buyBtn.addEventListener('click', async function() {
                            const vacancyId = this.dataset.vacancyId;
                            const token = localStorage.getItem('access_token');
                            
                            console.log('💰 Покупка вакансии ID:', vacancyId);
                            
                            if (!token) {
                                alert('❌ Необходимо авторизоваться');
                                const authModal3 = document.getElementById('authModal3');
                                if (authModal3) authModal3.style.display = 'block';
                                return;
                            }
                            
                            try {
                                console.log('📤 Отправка запроса...');
                                const response = await fetch(`http://localhost:8000/api/purchases/buy/${vacancyId}`, {
                                    method: 'POST',
                                    headers: {
                                        'Authorization': `Bearer ${token}`,
                                        'Content-Type': 'application/json'
                                    }
                                });
                                
                                console.log('📥 Статус ответа:', response.status);
                                const data = await response.json();
                                console.log('📦 Ответ сервера:', data);
                                
                                if (response.ok) {
                                    alert(`✅ Успех! ${data.message}`);
                                    
                                    // Обновляем XP
                                    const pointsElements = document.querySelectorAll('.points, .points-value');
                                    pointsElements.forEach(el => {
                                        if (el.classList.contains('points')) {
                                            el.textContent = `${data.remaining_points} XP`;
                                        } else if (el.classList.contains('points-value')) {
                                            el.textContent = data.remaining_points;
                                        }
                                    });
                                } else {
                                    alert(`❌ Ошибка: ${data.detail || 'Неизвестная ошибка'}`);
                                }
                                
                            } catch (error) {
                                console.error('🔥 Ошибка:', error);
                                alert('❌ Не удалось подключиться к серверу');
                            }
                        });
                    }
                    
                    EmptStateVacancies.appendChild(card);
                }
            }

        } catch(error){
            console.error('Ошибка запроса /catalog_cards:', error);
            return false;
        }
}

async function loadPurchaseModal() {
    try {
        const response = await fetch('/modal-purchase.html');
        const data = await response.text();
        
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = data;
        document.body.appendChild(modalContainer);
        
        console.log('Модальное окно загружено');
    } catch (error) {
        console.error('Ошибка загрузки модального окна:', error);
    }
}
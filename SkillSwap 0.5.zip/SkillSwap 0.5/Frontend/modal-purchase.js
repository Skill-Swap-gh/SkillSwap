// Инициализация модального окна покупки

// Функция для закрытия модального окна
function closeModal() {
    const purchaseModal = document.getElementById('purchaseModal');
    if (purchaseModal) {
        purchaseModal.style.display = 'none';
        document.body.style.overflow = '';
    }
}

// Функция для открытия модального окна с данными о навыке
export function openPurchaseModal(skillData) {
    console.log('📢 openPurchaseModal вызван с данными:', skillData);
    
    const purchaseModal = document.getElementById('purchaseModal');
    
    if (!purchaseModal) {
        console.error('❌ Модальное окно покупки не найдено в DOM');
        return;
    }
    
    // Сохраняем ID вакансии
    purchaseModal.dataset.vacancyId = skillData.vacancyId;
    console.log('✅ ID вакансии сохранен:', skillData.vacancyId);
    
    // Заполняем данные
    const skillTitle = purchaseModal.querySelector('.skill-title');
    const skillDescription = purchaseModal.querySelector('.skill-description');
    const skillFormat = purchaseModal.querySelector('.format-value');
    const skillPrice = purchaseModal.querySelector('.price-value');
    const xpAmount = purchaseModal.querySelector('.xp-amount');
    
    if (skillTitle) skillTitle.textContent = skillData.title || 'Название навыка';
    if (skillDescription) skillDescription.textContent = skillData.description || 'Описание навыка';
    
    const format = skillData.format || 'online';
    if (skillFormat) skillFormat.textContent = format === 'online' ? 'Онлайн' : 'Офлайн';
    
    if (skillPrice) skillPrice.textContent = `${skillData.price || 0} XP`;
    if (xpAmount) xpAmount.textContent = skillData.price || 0;
    
    // Показываем модальное окно
    purchaseModal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // УБЕДИМСЯ, что обработчик на кнопке есть
    ensureBuyButtonHandler();
}

// Функция, которая гарантированно добавляет обработчик на кнопку
function ensureBuyButtonHandler() {
    const purchaseModal = document.getElementById('purchaseModal');
    if (!purchaseModal) return;
    
    const buyBtn = purchaseModal.querySelector('.btn-buy');
    if (!buyBtn) {
        console.error('❌ Кнопка .btn-buy не найдена в модальном окне');
        return;
    }
    
    console.log('🔧 Добавляем обработчик на кнопку "Купить"');
    
    // Удаляем все старые обработчики (простой способ - заменить кнопку)
    const newBuyBtn = buyBtn.cloneNode(true);
    buyBtn.parentNode.replaceChild(newBuyBtn, buyBtn);
    
    // Добавляем новый обработчик
    newBuyBtn.addEventListener('click', async function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        console.log('🖱️ Кнопка "Купить" нажата!');
        
        const vacancyId = purchaseModal.dataset.vacancyId;
        const token = localStorage.getItem('access_token');
        
        console.log('📦 Данные для покупки:', { vacancyId, token: token ? 'есть' : 'нет' });
        
        if (!vacancyId) {
            alert('❌ Ошибка: ID вакансии не найден');
            return;
        }
        
        if (!token) {
            alert('🔐 Необходимо авторизоваться');
            const authModal3 = document.getElementById('authModal3');
            if (authModal3) authModal3.style.display = 'block';
            closeModal();
            return;
        }
        
        try {
            console.log('📤 Отправка запроса на покупку...');
            const response = await fetch(`http://localhost:8000/api/purchases/buy/${vacancyId}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            console.log('📥 Статус ответа:', response.status);
            
            const responseData = await response.json();
            console.log('📦 Ответ сервера:', responseData);
            
            if (response.ok) {
                alert(`✅ ${responseData.message}`);
                
                // Обновляем XP в интерфейсе
                const pointsElements = document.querySelectorAll('.points, .points-value');
                pointsElements.forEach(el => {
                    if (el.classList.contains('points')) {
                        el.textContent = `${responseData.remaining_points} XP`;
                    } else if (el.classList.contains('points-value')) {
                        el.textContent = responseData.remaining_points;
                    }
                });
                
                closeModal();
            } else {
                alert(`❌ ${responseData.detail || 'Ошибка при покупке'}`);
            }
        } catch (error) {
            console.error('🔥 Ошибка при покупке:', error);
            alert('❌ Не удалось подключиться к серверу');
        }
    });
    
    console.log('✅ Обработчик успешно добавлен');
}

// Инициализация при загрузке страницы
function initModal() {
    console.log('🔍 Инициализация модального окна...');
    
    const purchaseModal = document.getElementById('purchaseModal');
    if (!purchaseModal) {
        console.log('⏳ Модальное окно еще не загружено, пробуем через 500мс');
        setTimeout(initModal, 500);
        return;
    }
    
    console.log('✅ Модальное окно найдено');
    
    // Обработчик для закрытия по крестику
    const closeBtn = purchaseModal.querySelector('.purchase-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }
    
    // Закрытие по клику вне окна
    window.addEventListener('click', function(e) {
        if (e.target === purchaseModal) {
            closeModal();
        }
    });
    
    // Добавляем обработчик на кнопку при инициализации
    ensureBuyButtonHandler();
}

// Запускаем инициализацию
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initModal);
} else {
    initModal();
}

// Периодически проверяем наличие обработчика (на всякий случай)
setInterval(ensureBuyButtonHandler, 2000);